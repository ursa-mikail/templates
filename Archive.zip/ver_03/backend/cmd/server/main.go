package main

import (
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/searchpulse/backend/internal/db"
	"github.com/searchpulse/backend/internal/enctrie"
	"github.com/searchpulse/backend/internal/handlers"
	"github.com/searchpulse/backend/internal/keys"
	"github.com/searchpulse/backend/internal/outbox"
)

func main() {
	dsn := os.Getenv("DATABASE_URL")
	if dsn == "" {
		dsn = "postgres://searchpulse:searchpulse@localhost:5432/searchpulse?sslmode=disable"
	}

	database, err := db.Connect(dsn)
	if err != nil {
		log.Fatalf("db: %v", err)
	}
	defer database.Close()
	log.Println("✅ connected to postgres (single instance — source tables + encrypted trie tables)")

	// ── Key store: envelope-encrypted root keys, one per rotation epoch ──────
	kekHex := os.Getenv("MASTER_KEK_HEX")
	if kekHex == "" {
		// Local-dev-only fallback so `docker compose up` works out of the box.
		// Every real deployment MUST set MASTER_KEK_HEX from a secrets
		// manager / KMS — never bake it into an image or compose file.
		// Generate a real one with: openssl rand -hex 32
		kekHex = "00000000000000000000000000000000000000000000000000000000000000aa"
		log.Println("⚠️  MASTER_KEK_HEX not set — using an insecure development default. Do not use this in production.")
	}
	keyStore, err := keys.NewStore(database, kekHex)
	if err != nil {
		log.Fatalf("keys: %v", err)
	}
	if err := keyStore.Bootstrap(); err != nil {
		log.Fatalf("keys bootstrap: %v", err)
	}
	log.Printf("🔑 key store ready, current epoch = %d", keyStore.Current().Number)

	// ── Encrypted trie: build it if it doesn't exist yet. There is no cache
	// to "warm" — every read is a live query against enctrie_nodes, so all
	// that's needed at boot is to make sure the table has rows in it.
	encStore := enctrie.New(database, keyStore)
	cur := keyStore.Current()
	n, err := encStore.NodeCount(cur.Number)
	if err != nil {
		log.Fatalf("enctrie node count: %v", err)
	}
	if n == 0 {
		log.Println("🧱 no trie nodes found for current epoch — running full rebuild")
		built, elapsed, err := encStore.FullRebuild(cur.Number)
		if err != nil {
			log.Fatalf("enctrie rebuild: %v", err)
		}
		log.Printf("🧱 built %d encrypted nodes in %s (epoch %d) — written directly to Postgres", built, elapsed, cur.Number)
	} else {
		log.Printf("🧱 found %d encrypted nodes already in Postgres (epoch %d) — nothing to build", n, cur.Number)
	}

	// ── Encrypted records: same idea, for the exact-match retrieval store
	// that answers "the user picked a suggestion — get the full thing."
	rn, err := encStore.RecordCount(cur.Number)
	if err != nil {
		log.Fatalf("enctrie record count: %v", err)
	}
	if rn == 0 {
		log.Println("📦 no records found for current epoch — running full rebuild")
		built, elapsed, err := encStore.FullRebuildRecords(cur.Number)
		if err != nil {
			log.Fatalf("enctrie records rebuild: %v", err)
		}
		log.Printf("📦 built %d encrypted records in %s (epoch %d) — written directly to Postgres", built, elapsed, cur.Number)
	} else {
		log.Printf("📦 found %d encrypted records already in Postgres (epoch %d) — nothing to build", rn, cur.Number)
	}

	// ── Outbox processor: keeps the trie in sync with live data changes ──────
	proc := outbox.NewProcessor(dsn, database, encStore, keyStore)
	go proc.Run()

	// ── Epoch pruner: deletes retired key material once grace windows lapse.
	// Deleting an enctrie_key_epochs row cascades (ON DELETE CASCADE) to
	// delete every one of that epoch's enctrie_nodes rows in Postgres —
	// there is no separate in-memory copy that also needs dropping.
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			retired, err := keyStore.PruneExpired()
			if err != nil {
				log.Printf("key pruner: %v", err)
				continue
			}
			for _, epoch := range retired {
				log.Printf("🗑️  epoch %d retired: key material and node ciphertext permanently deleted from Postgres", epoch)
			}
		}
	}()

	apiKeys := strings.Split(os.Getenv("API_KEYS"), ",")

	h := handlers.New(database, keyStore, encStore, apiKeys)

	mux := http.NewServeMux()
	// Public, unauthenticated reads.
	mux.HandleFunc("GET /api/health", h.Health)
	mux.HandleFunc("GET /api/suggest", h.Suggest)
	mux.HandleFunc("GET /api/search", h.Search)
	mux.HandleFunc("GET /api/enc-suggest", h.EncSuggest)
	mux.HandleFunc("GET /api/enc-record", h.EncRecord)
	mux.HandleFunc("GET /api/bench", h.Bench)
	mux.HandleFunc("GET /api/bench/rebuild", h.BenchRebuild)
	mux.HandleFunc("GET /api/bench/incremental", h.BenchIncremental)
	mux.HandleFunc("GET /api/bench/rotate", h.BenchRotate)
	mux.HandleFunc("GET /api/data/schema", h.DataSchema)
	mux.HandleFunc("GET /api/data/recent", h.DataRecent)

	// Sensitive: key issuance + admin actions. Gated by RequireAPIKey — see
	// its doc comment for what a real deployment must add on top.
	mux.HandleFunc("GET /api/enc-key", h.RequireAPIKey(h.EncKey))
	mux.HandleFunc("POST /api/admin/rebuild", h.RequireAPIKey(h.AdminRebuild))
	mux.HandleFunc("POST /api/admin/rotate", h.RequireAPIKey(h.AdminRotate))
	mux.HandleFunc("POST /api/data/{kind}", h.RequireAPIKey(h.DataCreate))
	mux.HandleFunc("DELETE /api/data/{kind}/{id}", h.RequireAPIKey(h.DataDelete))

	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}
	log.Printf("🚀 listening on :%s", port)
	if err := http.ListenAndServe(":"+port, cors(mux)); err != nil {
		log.Fatalf("server: %v", err)
	}
}

func cors(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, X-API-Key")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
