// Package outbox keeps the encrypted trie in sync with the plaintext source
// tables without a full rebuild on every write.
//
// Flow:
//
//	Postgres trigger (companies/products/trends/innovations/bench_keywords)
//	  → INSERT INTO enctrie_outbox (...)
//	  → pg_notify('enctrie_changes', outbox_row_id)
//	      → Go: pq.Listener wakes up immediately
//	          → drain(): SELECT unprocessed rows, group by keyword change,
//	                     call enctrie.Store.UpdateKeyword for every
//	                     currently-valid epoch, mark rows processed
//
// A ticker also calls drain() every few seconds as a fallback, in case a
// NOTIFY is ever missed (e.g. this process was down when it fired —
// Postgres does not queue notifications for offline listeners, but the
// outbox *rows* persist, so the poll always catches up).
package outbox

import (
	"database/sql"
	"log"
	"time"

	"github.com/lib/pq"
	"github.com/searchpulse/backend/internal/enctrie"
	"github.com/searchpulse/backend/internal/keys"
)

const channel = "enctrie_changes"

type Processor struct {
	dsn      string
	db       *sql.DB
	store    *enctrie.Store
	keyStore *keys.Store
	poll     time.Duration
}

func NewProcessor(dsn string, db *sql.DB, store *enctrie.Store, ks *keys.Store) *Processor {
	return &Processor{dsn: dsn, db: db, store: store, keyStore: ks, poll: 5 * time.Second}
}

// Run blocks until the process exits. Call it in a goroutine.
func (p *Processor) Run() {
	listener := pq.NewListener(p.dsn, 2*time.Second, 30*time.Second, func(ev pq.ListenerEventType, err error) {
		if err != nil {
			log.Printf("outbox: listener event error: %v", err)
		}
	})
	defer listener.Close()

	if err := listener.Listen(channel); err != nil {
		log.Printf("outbox: LISTEN failed, falling back to polling only: %v", err)
	}

	ticker := time.NewTicker(p.poll)
	defer ticker.Stop()

	// Catch up on anything that queued before we started listening.
	if n, err := p.drain(); err != nil {
		log.Printf("outbox: initial drain failed: %v", err)
	} else if n > 0 {
		log.Printf("outbox: initial drain applied %d change(s)", n)
	}

	for {
		select {
		case n := <-listener.Notify:
			_ = n // payload is just the outbox row id; we re-query anyway
			if applied, err := p.drain(); err != nil {
				log.Printf("outbox: drain after notify failed: %v", err)
			} else if applied > 0 {
				log.Printf("outbox: applied %d change(s) via NOTIFY", applied)
			}
		case <-ticker.C:
			if applied, err := p.drain(); err != nil {
				log.Printf("outbox: poll drain failed: %v", err)
			} else if applied > 0 {
				log.Printf("outbox: applied %d change(s) via poll", applied)
			}
		}
	}
}

type change struct {
	id         int64
	keyword    sql.NullString
	oldKeyword sql.NullString
}

// drain applies every unprocessed outbox row to every currently-valid key
// epoch (active + any epoch still in its rotation grace window), so reads
// against either epoch stay correct while a rotation is in flight.
func (p *Processor) drain() (int, error) {
	rows, err := p.db.Query(`
		SELECT id, keyword, old_keyword FROM enctrie_outbox
		WHERE processed_at IS NULL
		ORDER BY id ASC
		LIMIT 500`)
	if err != nil {
		return 0, err
	}
	var changes []change
	for rows.Next() {
		var c change
		if err := rows.Scan(&c.id, &c.keyword, &c.oldKeyword); err != nil {
			rows.Close()
			return 0, err
		}
		changes = append(changes, c)
	}
	rows.Close()

	if len(changes) == 0 {
		return 0, nil
	}

	validEpochs := p.keyStore.ValidEpochs()
	ids := make([]int64, 0, len(changes))

	for _, c := range changes {
		newText, oldText := "", ""
		if c.keyword.Valid {
			newText = c.keyword.String
		}
		if c.oldKeyword.Valid {
			oldText = c.oldKeyword.String
		}
		for _, e := range validEpochs {
			if _, _, err := p.store.UpdateKeyword(e.Number, oldText, newText); err != nil {
				log.Printf("outbox: UpdateKeyword epoch=%d old=%q new=%q: %v", e.Number, oldText, newText, err)
			}
			if _, _, err := p.store.UpdateRecordKeyword(e.Number, oldText, newText); err != nil {
				log.Printf("outbox: UpdateRecordKeyword epoch=%d old=%q new=%q: %v", e.Number, oldText, newText, err)
			}
		}
		ids = append(ids, c.id)
	}

	if _, err := p.db.Exec(`UPDATE enctrie_outbox SET processed_at = now() WHERE id = ANY($1)`, pq.Array(ids)); err != nil {
		return 0, err
	}
	return len(changes), nil
}
