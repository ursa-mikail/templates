// Package enctrie, records.go — the "retrieval" half of the encrypted
// search pipeline. enctrie.go (prefix nodes) answers "what might this be,
// as the user types" with a small suggestion list. This file answers "the
// user picked one — get me the actual thing" with the same rich payload
// /api/search already returns for the plain path: description, metadata,
// tags. See SEARCHABLE_ENCRYPTION.md for the full search-to-retrieval
// pipeline on both paths.
package enctrie

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/lib/pq"
	"github.com/searchpulse/backend/internal/keys"
	"github.com/searchpulse/backend/internal/models"
)

const recordRotateBatchSize = 500

// recordSQL is the same shape of query handlers.search() runs, but with an
// EXACT (case-insensitive) match instead of a substring ILIKE scan, since
// a record is only ever retrieved by its full, precise indexed text.
// Score is fixed at 1.0: there is no fuzzy ranking involved in an exact
// trapdoor lookup, only "is this the thing or not."
const recordSQL = `
	SELECT id, kind, title, subtitle, description, badge, meta, tags FROM (
		SELECT c.id AS id, 'company' AS kind, c.name AS title,
			COALESCE(c.sector,'') || ' · ' || COALESCE(c.country,'') AS subtitle,
			COALESCE(c.description,'') AS description,
			CASE WHEN c.is_public THEN 'PUBLIC' || CASE WHEN c.ticker IS NOT NULL THEN ' · ' || c.ticker ELSE '' END ELSE 'PRIVATE' END AS badge,
			json_build_array(
				json_build_object('label','Founded','value',COALESCE(c.founded_year::text,'N/A')),
				json_build_object('label','Employees','value',COALESCE(c.employee_count::text,'N/A')),
				json_build_object('label','Market Cap','value',CASE WHEN c.market_cap_billion IS NOT NULL THEN '$'||c.market_cap_billion::text||'B' ELSE 'Private' END)
			)::text AS meta,
			'[]'::text AS tags
		FROM companies c WHERE lower(c.name) = lower($1)
		UNION ALL
		SELECT p.id, 'product', p.name,
			COALESCE(p.category,'') || ' · ' || COALESCE(c.name,''),
			COALESCE(p.description,''), COALESCE(p.version,''),
			json_build_array(
				json_build_object('label','Launched','value',COALESCE(p.launch_year::text,'N/A')),
				json_build_object('label','Rating','value',CASE WHEN p.rating IS NOT NULL THEN p.rating::text||'/5' ELSE 'N/A' END),
				json_build_object('label','MAU','value',CASE WHEN p.monthly_active_users_million IS NOT NULL THEN p.monthly_active_users_million::text||'M' ELSE 'N/A' END)
			)::text,
			COALESCE(array_to_json(p.tags)::text,'[]')
		FROM products p LEFT JOIN companies c ON c.id = p.company_id
		WHERE lower(p.name) = lower($1)
		UNION ALL
		SELECT i.id, 'innovation', i.title,
			COALESCE(i.field,'') || ' · ' || COALESCE(i.institution,''),
			COALESCE(i.abstract,''), i.year::text,
			json_build_array(
				json_build_object('label','Citations','value',COALESCE(i.citations::text,'0')),
				json_build_object('label','Impact','value',COALESCE(i.impact_score::text,'N/A')),
				json_build_object('label','arXiv','value',COALESCE(i.arxiv_id,'N/A'))
			)::text,
			'[]'::text
		FROM innovations i WHERE lower(i.title) = lower($1)
		UNION ALL
		SELECT t.id, 'trend', t.name,
			COALESCE(t.category,'') || ' · ' || COALESCE(t.adoption_stage,''),
			COALESCE(t.description,''), 'MOMENTUM '||t.momentum_score::text,
			json_build_array(
				json_build_object('label','Emerged','value',COALESCE(t.year_emerged::text,'N/A')),
				json_build_object('label','Stage','value',COALESCE(t.adoption_stage,'N/A')),
				json_build_object('label','Score','value',t.momentum_score::text||'/100')
			)::text,
			COALESCE(array_to_json(t.related_tags)::text,'[]')
		FROM trends t WHERE lower(t.name) = lower($1)
	) combined`

func scanRecords(rows *sql.Rows) ([]models.SearchResult, error) {
	var out []models.SearchResult
	for rows.Next() {
		var r models.SearchResult
		var meta, tags string
		if err := rows.Scan(&r.ID, &r.Kind, &r.Title, &r.Subtitle, &r.Description, &r.Badge, &meta, &tags); err != nil {
			return nil, err
		}
		r.Score = 1.0 // exact match — no fuzzy ranking applies
		if err := json.Unmarshal([]byte(meta), &r.Meta); err != nil {
			r.Meta = []models.MetaItem{}
		}
		if tags != "" && tags != "[]" {
			_ = json.Unmarshal([]byte(tags), &r.Tags)
		}
		out = append(out, r)
	}
	return out, nil
}

func (s *Store) recordsForKeywordTx(tx *sql.Tx, keyword string) ([]models.SearchResult, error) {
	rows, err := tx.Query(recordSQL, keyword)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	return scanRecords(rows)
}

// RecordCount is a live COUNT(*) against Postgres, same spirit as NodeCount.
func (s *Store) RecordCount(epoch int) (int, error) {
	var n int
	err := s.db.QueryRow(`SELECT count(*) FROM enctrie_records WHERE epoch = $1`, epoch).Scan(&n)
	return n, err
}

// FullRebuildRecords walks every DISTINCT exact keyword across all four
// source tables and writes one encrypted record row per keyword,
// containing every full result that shares that exact text (mirroring how
// enctrie.go's prefix nodes aggregate multiple keywords sharing a prefix).
func (s *Store) FullRebuildRecords(epoch int) (recordCount int, elapsed time.Duration, err error) {
	start := time.Now()

	e, ok := s.keys.ByEpoch(epoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown epoch %d", epoch)
	}

	keywordRows, err := s.db.Query(`
		SELECT DISTINCT lower(text) FROM (
			SELECT name AS text FROM companies
			UNION ALL SELECT name FROM products
			UNION ALL SELECT name FROM trends
			UNION ALL SELECT title FROM innovations
		) t`)
	if err != nil {
		return 0, 0, fmt.Errorf("load distinct keywords: %w", err)
	}
	var keywords []string
	for keywordRows.Next() {
		var kw string
		if keywordRows.Scan(&kw) == nil {
			keywords = append(keywords, kw)
		}
	}
	keywordRows.Close()

	tx, err := s.db.Begin()
	if err != nil {
		return 0, 0, err
	}
	defer tx.Rollback() //nolint:errcheck

	if _, err = tx.Exec(`DELETE FROM enctrie_records WHERE epoch = $1`, epoch); err != nil {
		return 0, 0, fmt.Errorf("clear old records: %w", err)
	}
	stmt, err := tx.Prepare(`
		INSERT INTO enctrie_records (epoch, trapdoor, keyword, ciphertext, updated_at)
		VALUES ($1,$2,$3,$4,now())
		ON CONFLICT (epoch, trapdoor) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, updated_at = now()`)
	if err != nil {
		return 0, 0, err
	}
	defer stmt.Close()

	count := 0
	for _, kw := range keywords {
		results, qErr := s.recordsForKeywordTx(tx, kw)
		if qErr != nil || len(results) == 0 {
			continue
		}
		ct, encErr := encryptRecords(e.RootKey, epoch, kw, results)
		if encErr != nil {
			continue
		}
		td := keys.DeriveRecordTrapdoor(e.RootKey, epoch, kw)
		if _, err = stmt.Exec(epoch, td, kw, ct); err != nil {
			return 0, 0, fmt.Errorf("insert record %q: %w", kw, err)
		}
		count++
	}

	if err = tx.Commit(); err != nil {
		return 0, 0, err
	}
	return count, time.Since(start), nil
}

// UpdateRecordKeyword re-derives the encrypted record(s) for the old and
// new exact text after a single keyword changed — O(1) Postgres work
// (two exact-match lookups) instead of the full-table rebuild above.
func (s *Store) UpdateRecordKeyword(epoch int, oldText, newText string) (touched int, elapsed time.Duration, err error) {
	start := time.Now()
	e, ok := s.keys.ByEpoch(epoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown epoch %d", epoch)
	}

	texts := map[string]bool{}
	for _, t := range []string{oldText, newText} {
		t = strings.ToLower(strings.TrimSpace(t))
		if t != "" {
			texts[t] = true
		}
	}
	if len(texts) == 0 {
		return 0, time.Since(start), nil
	}

	tx, err := s.db.Begin()
	if err != nil {
		return 0, 0, err
	}
	defer tx.Rollback() //nolint:errcheck

	upsert, err := tx.Prepare(`
		INSERT INTO enctrie_records (epoch, trapdoor, keyword, ciphertext, updated_at)
		VALUES ($1,$2,$3,$4,now())
		ON CONFLICT (epoch, trapdoor) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, updated_at = now()`)
	if err != nil {
		return 0, 0, err
	}
	defer upsert.Close()
	del, err := tx.Prepare(`DELETE FROM enctrie_records WHERE epoch = $1 AND trapdoor = $2`)
	if err != nil {
		return 0, 0, err
	}
	defer del.Close()

	// Deterministic order for the same lock-ordering reason as
	// enctrie.go's UpdateKeyword (see the deadlock note in
	// SEARCHABLE_ENCRYPTION.md).
	sorted := make([]string, 0, len(texts))
	for t := range texts {
		sorted = append(sorted, t)
	}
	sortStrings(sorted)

	n := 0
	for _, kw := range sorted {
		results, qErr := s.recordsForKeywordTx(tx, kw)
		td := keys.DeriveRecordTrapdoor(e.RootKey, epoch, kw)
		if qErr != nil || len(results) == 0 {
			if _, delErr := del.Exec(epoch, td); delErr != nil {
				return 0, 0, delErr
			}
			n++
			continue
		}
		ct, encErr := encryptRecords(e.RootKey, epoch, kw, results)
		if encErr != nil {
			return 0, 0, encErr
		}
		if _, err = upsert.Exec(epoch, td, kw, ct); err != nil {
			return 0, 0, err
		}
		n++
	}

	if err = tx.Commit(); err != nil {
		return 0, 0, err
	}
	return n, time.Since(start), nil
}

// RotateReencryptRecords mirrors RotateReencrypt for the records table:
// streams ciphertext out of Postgres in batches, decrypts with the old
// epoch's key, re-encrypts with the new one, never re-touches the
// plaintext source tables.
func (s *Store) RotateReencryptRecords(oldEpoch, newEpoch int) (recordCount int, elapsed time.Duration, err error) {
	start := time.Now()
	oldE, ok := s.keys.ByEpoch(oldEpoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown old epoch %d", oldEpoch)
	}
	newE, ok := s.keys.ByEpoch(newEpoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown new epoch %d", newEpoch)
	}

	rows, err := s.db.Query(`SELECT keyword, ciphertext FROM enctrie_records WHERE epoch = $1 ORDER BY keyword`, oldEpoch)
	if err != nil {
		return 0, 0, fmt.Errorf("stream old epoch records: %w", err)
	}
	defer rows.Close()

	type reenc struct {
		trapdoor, keyword string
		ct                []byte
	}
	batch := make([]reenc, 0, recordRotateBatchSize)
	total := 0

	flush := func() error {
		if len(batch) == 0 {
			return nil
		}
		tx, txErr := s.db.Begin()
		if txErr != nil {
			return txErr
		}
		defer tx.Rollback() //nolint:errcheck
		stmt, prepErr := tx.Prepare(`
			INSERT INTO enctrie_records (epoch, trapdoor, keyword, ciphertext, updated_at)
			VALUES ($1,$2,$3,$4,now())
			ON CONFLICT (epoch, trapdoor) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, updated_at = now()`)
		if prepErr != nil {
			return prepErr
		}
		defer stmt.Close()
		for _, r := range batch {
			if _, execErr := stmt.Exec(newEpoch, r.trapdoor, r.keyword, r.ct); execErr != nil {
				return execErr
			}
		}
		if commitErr := tx.Commit(); commitErr != nil {
			return commitErr
		}
		total += len(batch)
		batch = batch[:0]
		return nil
	}

	for rows.Next() {
		var keyword string
		var ct []byte
		if scanErr := rows.Scan(&keyword, &ct); scanErr != nil {
			return 0, 0, scanErr
		}
		oldKey := keys.DeriveRecordKey(oldE.RootKey, oldEpoch, keyword)
		plain, decErr := aesGCMDecrypt(oldKey, ct)
		if decErr != nil {
			log.Printf("enctrie: rotate-records skip keyword %q: decrypt failed: %v", keyword, decErr)
			continue
		}
		newKey := keys.DeriveRecordKey(newE.RootKey, newEpoch, keyword)
		newCt, encErr := aesGCMEncrypt(newKey, plain)
		if encErr != nil {
			return 0, 0, encErr
		}
		newTd := keys.DeriveRecordTrapdoor(newE.RootKey, newEpoch, keyword)
		batch = append(batch, reenc{trapdoor: newTd, keyword: keyword, ct: newCt})
		if len(batch) >= recordRotateBatchSize {
			if flushErr := flush(); flushErr != nil {
				return 0, 0, flushErr
			}
		}
	}
	if rowsErr := rows.Err(); rowsErr != nil {
		return 0, 0, rowsErr
	}
	if flushErr := flush(); flushErr != nil {
		return 0, 0, flushErr
	}
	return total, time.Since(start), nil
}

// QueryRecord answers a client's retrieval request with a live Postgres
// read against enctrie_records — same no-cache design as Query() in
// enctrie.go.
func (s *Store) QueryRecord(epoch int, trapdoor, recordKeyHex string, validEpochs []int) ([]models.SearchResult, bool, error) {
	recordKey, err := hexDecode32(recordKeyHex)
	if err != nil {
		return nil, false, nil
	}

	var ct []byte
	var found bool

	if epoch != 0 {
		row := s.db.QueryRow(`SELECT ciphertext FROM enctrie_records WHERE epoch = $1 AND trapdoor = $2`, epoch, trapdoor)
		if scanErr := row.Scan(&ct); scanErr == nil {
			found = true
		} else if scanErr != sql.ErrNoRows {
			return nil, false, scanErr
		}
	} else {
		row := s.db.QueryRow(`
			SELECT ciphertext FROM enctrie_records
			WHERE trapdoor = $1 AND epoch = ANY($2)
			ORDER BY epoch DESC LIMIT 1`, trapdoor, pq.Array(validEpochs))
		if scanErr := row.Scan(&ct); scanErr == nil {
			found = true
		} else if scanErr != sql.ErrNoRows {
			return nil, false, scanErr
		}
	}

	if !found {
		return nil, false, nil
	}

	plain, decErr := aesGCMDecrypt(recordKey, ct)
	if decErr != nil {
		return nil, false, nil
	}
	var results []models.SearchResult
	if jsonErr := json.Unmarshal(plain, &results); jsonErr != nil {
		return nil, false, nil
	}
	return results, true, nil
}

func encryptRecords(rootKey []byte, epoch int, keyword string, results []models.SearchResult) ([]byte, error) {
	plain, err := json.Marshal(results)
	if err != nil {
		return nil, err
	}
	recordKey := keys.DeriveRecordKey(rootKey, epoch, keyword)
	return aesGCMEncrypt(recordKey, plain)
}

// sortStrings: trivial insertion sort, plenty for the tiny (≤2-element)
// sets this is ever called with. Avoids a second "sort" import alias
// concern alongside enctrie.go in the same package.
func sortStrings(ss []string) {
	for i := 1; i < len(ss); i++ {
		for j := i; j > 0 && ss[j-1] > ss[j]; j-- {
			ss[j-1], ss[j] = ss[j], ss[j-1]
		}
	}
}
