// Package enctrie is the production encrypted trie.
//
// THERE IS NO IN-MEMORY CACHE. This is the point of this version. Every
// single call to Query() below issues a real SQL query against Postgres —
// the same database, over the same driver, through the same connection
// pool as the plain-text /api/suggest path. Nothing about the encrypted
// path is "free" or "already computed and sitting in RAM." The only thing
// that's precomputed is the *shape* of the data (the trie's nodes were
// derived and encrypted ahead of time, by FullRebuild/UpdateKeyword/
// RotateReencrypt) — where that precomputed data lives is Postgres, same
// as everything else in this system.
//
// DATA STRUCTURE, PRECISELY:
//
// A textbook trie is a tree of nodes, one per character, linked by child
// pointers ('c' -> 'l' -> 'a' -> 'u' -> 'd' -> 'e'). This system does not
// use that representation, because a query always already has the
// *complete* prefix string the user typed and wants exactly one node: the
// aggregated suggestion list for that whole prefix. So instead of a
// pointer-chasing tree, the trie is stored as ONE POSTGRES TABLE:
//
//	enctrie_nodes(epoch, trapdoor, prefix, ciphertext)
//	PRIMARY KEY (epoch, trapdoor)      ← B-tree index, O(log n) point lookup
//
// Every prefix of every keyword gets exactly one row. Looking up a prefix
// is a single indexed point-lookup by primary key — conceptually identical
// to `SELECT * FROM products WHERE id = $1`, just on a table keyed by a
// cryptographic trapdoor instead of a serial integer. This is still
// logically "a trie" (it indexes every prefix of every keyword), it is
// simply materialized as rows in a table instead of pointers in RAM.
//
// WHY THIS IS A FAIR COMPARISON AGAINST /api/suggest, AND THE ORIGINAL ONE
// WASN'T: /api/suggest does `... WHERE name ILIKE $1` — a pattern-match
// scan (accelerated by a GIN trigram index, but still a multi-row,
// multi-table scan) against Postgres, over the wire, every request. This
// package's Query() does `... WHERE epoch = $1 AND trapdoor = $2` — an
// exact-match point lookup (a single B-tree descent) against Postgres,
// over the wire, every request. Both hit disk-backed Postgres. Both pay
// the same connection-pool and network round-trip costs. The only
// difference is query *complexity*: exact-match point lookup on an
// indexed key vs. pattern-match scan across a UNION of four tables. That
// is a legitimate, honest thing to benchmark, and it's what
// /api/bench now measures.
package enctrie

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"sort"
	"strings"
	"time"

	"github.com/lib/pq"
	"github.com/searchpulse/backend/internal/keys"
)

// Suggestion is one autocomplete result.
type Suggestion struct {
	Text     string `json:"text"`
	Kind     string `json:"kind"`
	Subtitle string `json:"subtitle"`
}

type nodePayload struct {
	Suggestions []Suggestion `json:"s"`
}

// maxSuggestionsPerNode bounds how many results any single prefix node
// carries — keeps ciphertext payloads small and predictable.
const maxSuggestionsPerNode = 8

// rotateBatchSize bounds how many rows RotateReencrypt holds in memory at
// once while streaming through an old epoch's nodes. This is NOT a cache —
// it is a transient batch buffer for a bulk write, exactly like any ETL
// job that pages through a result set; nothing here is consulted to
// answer a read request.
const rotateBatchSize = 500

// ── Store ─────────────────────────────────────────────────────────────────

type Store struct {
	db   *sql.DB
	keys *keys.Store
}

func New(db *sql.DB, ks *keys.Store) *Store {
	return &Store{db: db, keys: ks}
}

// NodeCount is a live COUNT(*) against Postgres — not a cached number.
func (s *Store) NodeCount(epoch int) (int, error) {
	var n int
	err := s.db.QueryRow(`SELECT count(*) FROM enctrie_nodes WHERE epoch = $1`, epoch).Scan(&n)
	return n, err
}

// FullRebuild reads every keyword from all five source tables (companies,
// products, trends, innovations, bench_keywords), builds the prefix map in
// memory just long enough to encrypt and write it out (unavoidable for any
// bulk write — Postgres's own COPY/INSERT path does the same), encrypts
// every node under `epoch`'s root key, and persists the result to
// enctrie_nodes. This is the expensive, O(total keyword length) operation;
// it runs at first boot and can be re-run on a schedule as a safety net,
// but steady-state freshness is handled far more cheaply by UpdateKeyword.
func (s *Store) FullRebuild(epoch int) (nodeCount int, elapsed time.Duration, err error) {
	start := time.Now()

	e, ok := s.keys.ByEpoch(epoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown epoch %d", epoch)
	}

	keywords, err := s.loadAllKeywords()
	if err != nil {
		return 0, 0, fmt.Errorf("load keywords: %w", err)
	}

	prefixMap := buildPrefixMap(keywords)

	tx, err := s.db.Begin()
	if err != nil {
		return 0, 0, err
	}
	defer tx.Rollback() //nolint:errcheck

	if _, err = tx.Exec(`DELETE FROM enctrie_nodes WHERE epoch = $1`, epoch); err != nil {
		return 0, 0, fmt.Errorf("clear old nodes: %w", err)
	}

	stmt, err := tx.Prepare(`
		INSERT INTO enctrie_nodes (epoch, trapdoor, prefix, ciphertext, updated_at)
		VALUES ($1, $2, $3, $4, now())
		ON CONFLICT (epoch, trapdoor) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, updated_at = now()`)
	if err != nil {
		return 0, 0, err
	}
	defer stmt.Close()

	count := 0
	// Same reasoning as UpdateKeyword: insert in a deterministic order so a
	// rebuild running concurrently with an incremental update (or another
	// rebuild) can't lock overlapping rows in a different order and
	// deadlock. Every writer in this package locks enctrie_nodes rows in
	// prefix-sorted order.
	prefixes := make([]string, 0, len(prefixMap))
	for p := range prefixMap {
		prefixes = append(prefixes, p)
	}
	sort.Strings(prefixes)

	for _, prefix := range prefixes {
		ct, td, encErr := encryptNode(e.RootKey, epoch, prefix, prefixMap[prefix])
		if encErr != nil {
			continue
		}
		if _, err = stmt.Exec(epoch, td, prefix, ct); err != nil {
			return 0, 0, fmt.Errorf("insert node %q: %w", prefix, err)
		}
		count++
	}

	if err = tx.Commit(); err != nil {
		return 0, 0, err
	}
	return count, time.Since(start), nil
}

// UpdateKeyword performs an incremental update after a single keyword
// changed in a source table (insert / update / delete). It only touches
// the prefixes of oldText and newText — O(len(oldText)+len(newText)) node
// re-derivations — instead of the O(total nodes) cost of FullRebuild, and
// writes the result straight to Postgres. There is nothing to update in
// RAM: the next read for any of these prefixes will simply see the new
// row via a normal indexed SELECT.
//
// Because a prefix node aggregates suggestions from *every* keyword that
// shares it (e.g. prefix "cl" collects "Claude", "Clockwork", "Cloudflare"),
// a changed keyword can't just be spliced in/out locally: this re-queries
// Postgres for the current aggregate suggestion set of each touched
// prefix, then re-encrypts just those nodes.
func (s *Store) UpdateKeyword(epoch int, oldText, newText string) (touchedPrefixes int, elapsed time.Duration, err error) {
	start := time.Now()

	e, ok := s.keys.ByEpoch(epoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown epoch %d", epoch)
	}

	touched := map[string]bool{}
	for _, kw := range []string{oldText, newText} {
		kw = strings.ToLower(strings.TrimSpace(kw))
		if kw == "" {
			continue
		}
		runes := []rune(kw)
		for i := 1; i <= len(runes); i++ {
			touched[string(runes[:i])] = true
		}
	}
	if len(touched) == 0 {
		return 0, time.Since(start), nil
	}
	// Sort so that any two transactions touching an overlapping prefix set
	// (e.g. the outbox processor and a direct caller racing on the same
	// keyword change) acquire row locks in the SAME order. Postgres's
	// INSERT ... ON CONFLICT DO UPDATE takes a lock per target row; two
	// concurrent transactions locking the same set of rows in different
	// orders is a textbook deadlock, and it is a real one here — the
	// outbox listener can fire on the very same write a caller just made.
	// A consistent lock order turns that race into a brief wait instead of
	// a deadlock.
	prefixList := make([]string, 0, len(touched))
	for p := range touched {
		prefixList = append(prefixList, p)
	}
	sort.Strings(prefixList)

	tx, err := s.db.Begin()
	if err != nil {
		return 0, 0, err
	}
	defer tx.Rollback() //nolint:errcheck

	upsert, err := tx.Prepare(`
		INSERT INTO enctrie_nodes (epoch, trapdoor, prefix, ciphertext, updated_at)
		VALUES ($1, $2, $3, $4, now())
		ON CONFLICT (epoch, trapdoor) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, updated_at = now()`)
	if err != nil {
		return 0, 0, err
	}
	defer upsert.Close()

	del, err := tx.Prepare(`DELETE FROM enctrie_nodes WHERE epoch = $1 AND trapdoor = $2`)
	if err != nil {
		return 0, 0, err
	}
	defer del.Close()

	n := 0
	for _, prefix := range prefixList {
		sugs, findErr := s.aggregateForPrefixTx(tx, prefix)
		if findErr != nil {
			return 0, 0, fmt.Errorf("aggregate prefix %q: %w", prefix, findErr)
		}
		td := keys.DeriveTrapdoor(e.RootKey, epoch, prefix)

		if len(sugs) == 0 {
			if _, err = del.Exec(epoch, td); err != nil {
				return 0, 0, err
			}
			n++
			continue
		}

		nodeKey := keys.DeriveNodeKey(e.RootKey, epoch, prefix)
		plain, _ := json.Marshal(nodePayload{Suggestions: sugs})
		ct, encErr := aesGCMEncrypt(nodeKey, plain)
		if encErr != nil {
			return 0, 0, encErr
		}
		if _, err = upsert.Exec(epoch, td, prefix, ct); err != nil {
			return 0, 0, err
		}
		n++
	}

	if err = tx.Commit(); err != nil {
		return 0, 0, err
	}
	return n, time.Since(start), nil
}

// aggregateForPrefixTx re-derives what a prefix node's plaintext contents
// should be right now, by asking Postgres for every keyword across all
// five source tables that starts with it (case-insensitive), capped at
// maxSuggestionsPerNode. Runs inside the caller's transaction so it sees a
// consistent snapshot alongside the write it's about to perform.
func (s *Store) aggregateForPrefixTx(tx *sql.Tx, prefix string) ([]Suggestion, error) {
	like := prefix + "%"
	rows, err := tx.Query(`
		SELECT text, kind, subtitle FROM (
			SELECT name AS text, 'company' AS kind,
			       COALESCE(sector,'') || ' · ' || COALESCE(country,'') AS subtitle
			FROM companies WHERE name ILIKE $1
			UNION ALL
			SELECT p.name, 'product',
			       COALESCE(p.category,'') || ' · ' || COALESCE(c.name,'')
			FROM products p LEFT JOIN companies c ON c.id = p.company_id
			WHERE p.name ILIKE $1
			UNION ALL
			SELECT name, 'trend',
			       COALESCE(category,'') || ' · ' || COALESCE(adoption_stage,'')
			FROM trends WHERE name ILIKE $1
			UNION ALL
			SELECT title, 'innovation',
			       COALESCE(field,'') || ' · ' || year::text
			FROM innovations WHERE title ILIKE $1
			UNION ALL
			SELECT text, 'bench',
			       subtitle
			FROM bench_keywords WHERE text ILIKE $1
		) t LIMIT $2`, like, maxSuggestionsPerNode)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var out []Suggestion
	seen := map[string]bool{}
	for rows.Next() {
		var sug Suggestion
		if err := rows.Scan(&sug.Text, &sug.Kind, &sug.Subtitle); err != nil {
			return nil, err
		}
		if seen[sug.Text] {
			continue
		}
		seen[sug.Text] = true
		out = append(out, sug)
	}
	return out, nil
}

// RotateReencrypt re-encrypts every node currently stored under `oldEpoch`
// into `newEpoch`, entirely inside Postgres: it streams rows out of
// enctrie_nodes for the old epoch in batches (rotateBatchSize at a time —
// a transient buffer for the bulk write, not a serving cache), decrypts
// each with the old node key, re-encrypts with the new one, and writes the
// new epoch's rows. It never re-reads the plaintext source tables, so cost
// scales with node count, not with the size of companies/products/etc.
func (s *Store) RotateReencrypt(oldEpoch, newEpoch int) (nodeCount int, elapsed time.Duration, err error) {
	start := time.Now()

	oldE, ok := s.keys.ByEpoch(oldEpoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown old epoch %d", oldEpoch)
	}
	newE, ok := s.keys.ByEpoch(newEpoch)
	if !ok {
		return 0, 0, fmt.Errorf("unknown new epoch %d", newEpoch)
	}

	rows, err := s.db.Query(`SELECT prefix, ciphertext FROM enctrie_nodes WHERE epoch = $1 ORDER BY prefix`, oldEpoch)
	if err != nil {
		return 0, 0, fmt.Errorf("stream old epoch: %w", err)
	}
	defer rows.Close()

	type reencrypted struct {
		trapdoor string
		prefix   string
		ct       []byte
	}
	batch := make([]reencrypted, 0, rotateBatchSize)
	total := 0

	flush := func() error {
		if len(batch) == 0 {
			return nil
		}
		tx, txErr := s.db.Begin()
		if txErr != nil {
			return txErr
		}
		defer tx.Rollback() //nolint:errcheck
		stmt, prepErr := tx.Prepare(`
			INSERT INTO enctrie_nodes (epoch, trapdoor, prefix, ciphertext, updated_at)
			VALUES ($1, $2, $3, $4, now())
			ON CONFLICT (epoch, trapdoor) DO UPDATE SET ciphertext = EXCLUDED.ciphertext, updated_at = now()`)
		if prepErr != nil {
			return prepErr
		}
		defer stmt.Close()
		for _, r := range batch {
			if _, execErr := stmt.Exec(newEpoch, r.trapdoor, r.prefix, r.ct); execErr != nil {
				return execErr
			}
		}
		if commitErr := tx.Commit(); commitErr != nil {
			return commitErr
		}
		total += len(batch)
		batch = batch[:0]
		return nil
	}

	for rows.Next() {
		var prefix string
		var ct []byte
		if scanErr := rows.Scan(&prefix, &ct); scanErr != nil {
			return 0, 0, scanErr
		}
		oldNodeKey := keys.DeriveNodeKey(oldE.RootKey, oldEpoch, prefix)
		plain, decErr := aesGCMDecrypt(oldNodeKey, ct)
		if decErr != nil {
			log.Printf("enctrie: rotate skip prefix %q: decrypt failed: %v", prefix, decErr)
			continue
		}
		newNodeKey := keys.DeriveNodeKey(newE.RootKey, newEpoch, prefix)
		newCt, encErr := aesGCMEncrypt(newNodeKey, plain)
		if encErr != nil {
			return 0, 0, encErr
		}
		newTd := keys.DeriveTrapdoor(newE.RootKey, newEpoch, prefix)
		batch = append(batch, reencrypted{trapdoor: newTd, prefix: prefix, ct: newCt})
		if len(batch) >= rotateBatchSize {
			if flushErr := flush(); flushErr != nil {
				return 0, 0, flushErr
			}
		}
	}
	if rowsErr := rows.Err(); rowsErr != nil {
		return 0, 0, rowsErr
	}
	if flushErr := flush(); flushErr != nil {
		return 0, 0, flushErr
	}

	return total, time.Since(start), nil
}

// Query answers a client request with a LIVE POSTGRES READ. Given a
// trapdoor and the epoch it claims to belong to (or no epoch, to search
// every currently-valid epoch), it runs an indexed SELECT against
// enctrie_nodes and decrypts whatever it gets back using the
// client-supplied node key. There is no cache anywhere in this call.
func (s *Store) Query(epoch int, trapdoor, nodeKeyHex string, validEpochs []int) ([]Suggestion, bool, error) {
	nodeKey, err := hexDecode32(nodeKeyHex)
	if err != nil {
		return nil, false, nil // malformed client input, not a server error
	}

	var ct []byte
	var found bool

	if epoch != 0 {
		// Direct PK point lookup: one B-tree descent, one row.
		row := s.db.QueryRow(`SELECT ciphertext FROM enctrie_nodes WHERE epoch = $1 AND trapdoor = $2`, epoch, trapdoor)
		if scanErr := row.Scan(&ct); scanErr == nil {
			found = true
		} else if scanErr != sql.ErrNoRows {
			return nil, false, scanErr
		}
	} else {
		// No epoch hint (e.g. client key predates a rotation): look up by
		// trapdoor across every epoch still valid, indexed via
		// idx_enctrie_nodes_trapdoor, preferring the newest match.
		row := s.db.QueryRow(`
			SELECT ciphertext FROM enctrie_nodes
			WHERE trapdoor = $1 AND epoch = ANY($2)
			ORDER BY epoch DESC LIMIT 1`, trapdoor, pq.Array(validEpochs))
		if scanErr := row.Scan(&ct); scanErr == nil {
			found = true
		} else if scanErr != sql.ErrNoRows {
			return nil, false, scanErr
		}
	}

	if !found {
		return nil, false, nil
	}

	plain, decErr := aesGCMDecrypt(nodeKey, ct)
	if decErr != nil {
		return nil, false, nil // wrong key for this ciphertext; not a server error
	}
	var payload nodePayload
	if jsonErr := json.Unmarshal(plain, &payload); jsonErr != nil {
		return nil, false, nil
	}
	return payload.Suggestions, true, nil
}

// ── keyword loading & prefix map construction ───────────────────────────────

func (s *Store) loadAllKeywords() (map[string][]Suggestion, error) {
	out := make(map[string][]Suggestion)
	rows, err := s.db.Query(`
		SELECT name, 'company' AS kind,
		       COALESCE(sector,'') || ' · ' || COALESCE(country,'') AS sub
		FROM companies
		UNION ALL
		SELECT p.name, 'product',
		       COALESCE(p.category,'') || ' · ' || COALESCE(c.name,'')
		FROM products p LEFT JOIN companies c ON c.id = p.company_id
		UNION ALL
		SELECT name, 'trend',
		       COALESCE(category,'') || ' · ' || COALESCE(adoption_stage,'')
		FROM trends
		UNION ALL
		SELECT title, 'innovation',
		       COALESCE(field,'') || ' · ' || year::text
		FROM innovations
		UNION ALL
		SELECT text, 'bench', subtitle
		FROM bench_keywords
	`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	for rows.Next() {
		var text, kind, subtitle string
		if rows.Scan(&text, &kind, &subtitle) == nil {
			key := strings.ToLower(text)
			out[key] = append(out[key], Suggestion{Text: text, Kind: kind, Subtitle: subtitle})
		}
	}
	return out, nil
}

// buildPrefixMap turns {keyword: [suggestions]} into {prefix: {text: suggestion}}
// by walking every prefix of every keyword — the plaintext "trie" build step.
// This map is held in memory only transiently, for the duration of a single
// FullRebuild call, purely to shape the batch INSERT below; it is discarded
// the moment FullRebuild returns and is never consulted by Query.
func buildPrefixMap(keywords map[string][]Suggestion) map[string]map[string]Suggestion {
	prefixMap := make(map[string]map[string]Suggestion)
	for kw, sugs := range keywords {
		runes := []rune(kw)
		for i := 1; i <= len(runes); i++ {
			prefix := string(runes[:i])
			if prefixMap[prefix] == nil {
				prefixMap[prefix] = make(map[string]Suggestion)
			}
			for _, sg := range sugs {
				if _, exists := prefixMap[prefix][sg.Text]; !exists {
					prefixMap[prefix][sg.Text] = sg
				}
			}
		}
	}
	return prefixMap
}

func encryptNode(rootKey []byte, epoch int, prefix string, sugMap map[string]Suggestion) (ct []byte, trapdoor string, err error) {
	sugs := make([]Suggestion, 0, len(sugMap))
	for _, sg := range sugMap {
		sugs = append(sugs, sg)
		if len(sugs) == maxSuggestionsPerNode {
			break
		}
	}
	plain, _ := json.Marshal(nodePayload{Suggestions: sugs})
	nodeKey := keys.DeriveNodeKey(rootKey, epoch, prefix)
	ct, err = aesGCMEncrypt(nodeKey, plain)
	if err != nil {
		return nil, "", err
	}
	trapdoor = keys.DeriveTrapdoor(rootKey, epoch, prefix)
	return ct, trapdoor, nil
}

// ── AES-256-GCM helpers ──────────────────────────────────────────────────────

func aesGCMEncrypt(key, plaintext []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize())
	if _, err := io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	return gcm.Seal(nonce, nonce, plaintext, nil), nil
}

func aesGCMDecrypt(key, ciphertext []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	ns := gcm.NonceSize()
	if len(ciphertext) < ns {
		return nil, aes.KeySizeError(len(key))
	}
	return gcm.Open(nil, ciphertext[:ns], ciphertext[ns:], nil)
}

func hexDecode32(s string) ([]byte, error) {
	b, err := hex.DecodeString(s)
	if err != nil {
		return nil, err
	}
	if len(b) != 32 {
		return nil, fmt.Errorf("expected 32-byte key, got %d", len(b))
	}
	return b, nil
}
