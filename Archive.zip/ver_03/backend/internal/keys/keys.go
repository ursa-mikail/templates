// Package keys manages the encrypted trie's key hierarchy.
//
// HIERARCHY (top to bottom):
//
//	KEK (Key-Encryption-Key)     — one per deployment, from MASTER_KEK_HEX env
//	                                var (in real production: a KMS/HSM key
//	                                that never exists as a raw file on disk).
//	  └─ root key, per epoch     — 256-bit random key generated at Rotate()
//	                                time, wrapped with AES-256-GCM under the
//	                                KEK, persisted in enctrie_key_epochs.
//	       ├─ node key, per prefix  = HMAC-SHA256(rootKey_epoch, "node:"+prefix)
//	       └─ trapdoor,   per prefix = HMAC-SHA256(rootKey_epoch, "td:"+prefix)
//
// An "epoch" is one generation of the root key. Rotating creates a new
// epoch; the old epoch is kept readable for a grace period so clients that
// cached the previous epoch's derived keys don't get a hard failure mid-
// rotation, then the old key material is deleted outright (crypto-
// shredding) — that deletion, not just "generating a new key", is what
// actually bounds the blast radius of a leaked key.
package keys

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"fmt"
	"io"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Epoch is one generation of the root key.
type Epoch struct {
	Number      int
	RootKey     []byte // 32 bytes, plaintext, in-memory only
	Status      string // "active" | "grace" | "retired"
	CreatedAt   time.Time
	RetireAfter *time.Time // set once superseded by a newer epoch
}

// Store holds all currently-known epochs in memory and persists them.
type Store struct {
	mu      sync.RWMutex
	epochs  map[int]*Epoch
	current int
	kek     []byte // 32-byte AES key wrapping every root key at rest
	db      *sql.DB
}

// NewStore builds a Store. kekHex must decode to exactly 32 bytes; treat it
// as a KMS-managed secret in real deployments, not a value baked into an
// image or checked into source control.
func NewStore(db *sql.DB, kekHex string) (*Store, error) {
	kek, err := hex.DecodeString(strings.TrimSpace(kekHex))
	if err != nil || len(kek) != 32 {
		return nil, fmt.Errorf("MASTER_KEK_HEX must be a 64-char hex string (32 bytes), got %d bytes, err=%v", len(kek), err)
	}
	return &Store{
		epochs: make(map[int]*Epoch),
		kek:    kek,
		db:     db,
	}, nil
}

// Bootstrap loads any persisted, non-retired epochs from Postgres. If none
// exist (first-ever boot), it mints epoch 1.
func (s *Store) Bootstrap() error {
	rows, err := s.db.Query(`
		SELECT epoch, wrapped_root_key, wrap_nonce, status, created_at, retire_after
		FROM enctrie_key_epochs
		WHERE status != 'retired'
		ORDER BY epoch ASC`)
	if err != nil {
		return fmt.Errorf("bootstrap query: %w", err)
	}
	defer rows.Close()

	s.mu.Lock()
	maxEpoch := 0
	for rows.Next() {
		var e Epoch
		var wrapped, nonce []byte
		var retireAfter sql.NullTime
		if err := rows.Scan(&e.Number, &wrapped, &nonce, &e.Status, &e.CreatedAt, &retireAfter); err != nil {
			s.mu.Unlock()
			return fmt.Errorf("bootstrap scan: %w", err)
		}
		root, err := s.unwrap(wrapped, nonce)
		if err != nil {
			s.mu.Unlock()
			return fmt.Errorf("bootstrap unwrap epoch %d: %w (wrong MASTER_KEK_HEX?)", e.Number, err)
		}
		e.RootKey = root
		if retireAfter.Valid {
			t := retireAfter.Time
			e.RetireAfter = &t
		}
		s.epochs[e.Number] = &e
		if e.Number > maxEpoch {
			maxEpoch = e.Number
		}
		if e.Status == "active" {
			s.current = e.Number
		}
	}
	s.mu.Unlock()

	if maxEpoch == 0 {
		return s.mintFirstEpoch()
	}
	return nil
}

func (s *Store) mintFirstEpoch() error {
	root := make([]byte, 32)
	if _, err := io.ReadFull(rand.Reader, root); err != nil {
		return fmt.Errorf("generate root key: %w", err)
	}
	wrapped, nonce, err := s.wrap(root)
	if err != nil {
		return fmt.Errorf("wrap root key: %w", err)
	}
	if _, err := s.db.Exec(`
		INSERT INTO enctrie_key_epochs (epoch, wrapped_root_key, wrap_nonce, status)
		VALUES (1, $1, $2, 'active')`, wrapped, nonce); err != nil {
		return fmt.Errorf("persist epoch 1: %w", err)
	}
	s.mu.Lock()
	s.epochs[1] = &Epoch{Number: 1, RootKey: root, Status: "active", CreatedAt: time.Now()}
	s.current = 1
	s.mu.Unlock()
	return nil
}

// Current returns today's key-issuance epoch (used for NEW derivations).
func (s *Store) Current() *Epoch {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.epochs[s.current]
}

// ByEpoch fetches a specific epoch, including ones still in their grace
// window (needed to decrypt requests built with a not-yet-expired key).
func (s *Store) ByEpoch(n int) (*Epoch, bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	e, ok := s.epochs[n]
	return e, ok
}

// ValidEpochs returns every epoch a read request may legally target
// (active first, so the common case is a single map lookup).
func (s *Store) ValidEpochs() []*Epoch {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]*Epoch, 0, len(s.epochs))
	if cur, ok := s.epochs[s.current]; ok {
		out = append(out, cur)
	}
	for n, e := range s.epochs {
		if n != s.current {
			out = append(out, e)
		}
	}
	return out
}

// Rotate mints a new epoch, marks the previous "active" epoch as "grace"
// with a deadline, and returns both so the caller (enctrie.Store) can
// re-encrypt every node under the new key. It does NOT delete old key
// material — that happens later, in PruneExpired, once the grace window
// has actually elapsed.
func (s *Store) Rotate(grace time.Duration) (newEpoch, oldEpoch *Epoch, err error) {
	root := make([]byte, 32)
	if _, err = io.ReadFull(rand.Reader, root); err != nil {
		return nil, nil, fmt.Errorf("generate root key: %w", err)
	}
	wrapped, nonce, err := s.wrap(root)
	if err != nil {
		return nil, nil, fmt.Errorf("wrap root key: %w", err)
	}

	s.mu.Lock()
	oldNum := s.current
	old := s.epochs[oldNum]
	newNum := oldNum + 1
	s.mu.Unlock()

	retireAfter := time.Now().Add(grace)

	tx, err := s.db.Begin()
	if err != nil {
		return nil, nil, err
	}
	defer tx.Rollback() //nolint:errcheck

	if _, err = tx.Exec(`
		INSERT INTO enctrie_key_epochs (epoch, wrapped_root_key, wrap_nonce, status)
		VALUES ($1, $2, $3, 'active')`, newNum, wrapped, nonce); err != nil {
		return nil, nil, fmt.Errorf("insert new epoch: %w", err)
	}
	if _, err = tx.Exec(`
		UPDATE enctrie_key_epochs SET status = 'grace', retire_after = $2
		WHERE epoch = $1`, oldNum, retireAfter); err != nil {
		return nil, nil, fmt.Errorf("demote old epoch: %w", err)
	}
	if err = tx.Commit(); err != nil {
		return nil, nil, err
	}

	ne := &Epoch{Number: newNum, RootKey: root, Status: "active", CreatedAt: time.Now()}

	s.mu.Lock()
	s.epochs[newNum] = ne
	s.current = newNum
	if old != nil {
		old.Status = "grace"
		old.RetireAfter = &retireAfter
	}
	s.mu.Unlock()

	return ne, old, nil
}

// PruneExpired retires (deletes key material for) every epoch whose grace
// window has elapsed. Deleting enctrie_key_epochs cascades to delete that
// epoch's rows in enctrie_nodes (ON DELETE CASCADE) — this is the actual
// "old data is now unrecoverable" step that rotation exists to provide.
func (s *Store) PruneExpired() ([]int, error) {
	now := time.Now()
	s.mu.Lock()
	var toRetire []int
	for n, e := range s.epochs {
		if e.Status == "grace" && e.RetireAfter != nil && now.After(*e.RetireAfter) {
			toRetire = append(toRetire, n)
		}
	}
	s.mu.Unlock()

	if len(toRetire) == 0 {
		return nil, nil
	}

	for _, n := range toRetire {
		if _, err := s.db.Exec(`DELETE FROM enctrie_key_epochs WHERE epoch = $1`, n); err != nil {
			return nil, fmt.Errorf("retire epoch %d: %w", n, err)
		}
		s.mu.Lock()
		delete(s.epochs, n)
		s.mu.Unlock()
	}
	return toRetire, nil
}

// ── envelope encryption of root keys (KEK wrapping) ─────────────────────────

func (s *Store) wrap(plainRoot []byte) (ciphertext, nonce []byte, err error) {
	block, err := aes.NewCipher(s.kek)
	if err != nil {
		return nil, nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, nil, err
	}
	nonce = make([]byte, gcm.NonceSize())
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, nil, err
	}
	return gcm.Seal(nil, nonce, plainRoot, nil), nonce, nil
}

func (s *Store) unwrap(ciphertext, nonce []byte) ([]byte, error) {
	block, err := aes.NewCipher(s.kek)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	return gcm.Open(nil, nonce, ciphertext, nil)
}

// ── per-prefix key derivation (epoch-namespaced) ────────────────────────────
//
// The epoch number is mixed into the HMAC input so that the same prefix in
// two different epochs produces completely unrelated trapdoors/keys — this
// is what makes the dual-key grace window safe: an epoch-1 trapdoor for
// "claude" and an epoch-2 trapdoor for "claude" are unlinkable to an
// observer who only sees ciphertext and trapdoors on the wire.

// DeriveTrapdoor computes the server-lookup token for a prefix in an epoch.
func DeriveTrapdoor(rootKey []byte, epoch int, prefix string) string {
	h := hmac.New(sha256.New, rootKey)
	h.Write([]byte("td:e" + strconv.Itoa(epoch) + ":" + strings.ToLower(prefix)))
	return hex.EncodeToString(h.Sum(nil))
}

// DeriveNodeKey computes the AES-256 decryption key for a prefix in an epoch.
func DeriveNodeKey(rootKey []byte, epoch int, prefix string) []byte {
	h := hmac.New(sha256.New, rootKey)
	h.Write([]byte("node:e" + strconv.Itoa(epoch) + ":" + strings.ToLower(prefix)))
	return h.Sum(nil)[:32]
}

// ── full-record retrieval (exact-match, distinct label namespace) ──────────
//
// A prefix trapdoor ("td:") and a record trapdoor ("rtd:") for the exact
// same text are unrelated 32-byte values — computing one gives no
// information about the other. This is deliberate: the two tables they
// index (enctrie_nodes, lightweight suggestion snippets; enctrie_records,
// full retrieval payloads) have different sensitivity, so leaking access
// to one must not imply access to the other.

// DeriveRecordTrapdoor computes the server-lookup token for the full,
// exact text of a keyword (not a prefix) in an epoch.
func DeriveRecordTrapdoor(rootKey []byte, epoch int, exactText string) string {
	h := hmac.New(sha256.New, rootKey)
	h.Write([]byte("rtd:e" + strconv.Itoa(epoch) + ":" + strings.ToLower(exactText)))
	return hex.EncodeToString(h.Sum(nil))
}

// DeriveRecordKey computes the AES-256 decryption key for the full record
// payload of an exact keyword in an epoch.
func DeriveRecordKey(rootKey []byte, epoch int, exactText string) []byte {
	h := hmac.New(sha256.New, rootKey)
	h.Write([]byte("rkey:e" + strconv.Itoa(epoch) + ":" + strings.ToLower(exactText)))
	return h.Sum(nil)[:32]
}
