package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"log"
	"math"
	"math/rand"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"github.com/searchpulse/backend/internal/enctrie"
	"github.com/searchpulse/backend/internal/keys"
	"github.com/searchpulse/backend/internal/models"
)

type Handler struct {
	db      *sql.DB
	keys    *keys.Store
	enc     *enctrie.Store
	apiKeys map[string]bool // populated from API_KEYS env var; see RequireAPIKey
}

func New(db *sql.DB, ks *keys.Store, enc *enctrie.Store, apiKeys []string) *Handler {
	m := make(map[string]bool, len(apiKeys))
	for _, k := range apiKeys {
		k = strings.TrimSpace(k)
		if k != "" {
			m[k] = true
		}
	}
	return &Handler{db: db, keys: ks, enc: enc, apiKeys: m}
}

// RequireAPIKey gates sensitive endpoints (key issuance, admin actions)
// behind a simple shared-secret header. This is a STAND-IN: real
// deployments should replace it with per-user session auth (OAuth/JWT),
// because a single static key here can't express "this browser session
// belongs to user X and may only derive keys scoped to X's tenant." What
// this stub does demonstrate correctly is the shape production needs: the
// key-issuance and rotation endpoints must never be publicly reachable.
func (h *Handler) RequireAPIKey(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if len(h.apiKeys) == 0 {
			// No keys configured (local dev default) — allow through, but
			// say so loudly so nobody ships this configuration by accident.
			w.Header().Set("X-Auth-Warning", "API_KEYS not configured; endpoint is unauthenticated")
			next(w, r)
			return
		}
		key := r.Header.Get("X-API-Key")
		if !h.apiKeys[key] {
			writeJSON(w, http.StatusUnauthorized, map[string]string{"error": "missing or invalid X-API-Key"})
			return
		}
		next(w, r)
	}
}

// ── Health ────────────────────────────────────────────────────────────────

func (h *Handler) Health(w http.ResponseWriter, r *http.Request) {
	if err := h.db.Ping(); err != nil {
		writeJSON(w, 503, map[string]string{"status": "unhealthy", "error": err.Error()})
		return
	}
	cur := h.keys.Current()
	epochs := []map[string]any{}
	for _, e := range h.keys.ValidEpochs() {
		n, ncErr := h.enc.NodeCount(e.Number)
		if ncErr != nil {
			log.Printf("health: node count epoch=%d: %v", e.Number, ncErr)
		}
		epochs = append(epochs, map[string]any{
			"epoch":      e.Number,
			"status":     e.Status,
			"node_count": n,
		})
	}
	writeJSON(w, 200, map[string]any{
		"status":        "healthy",
		"current_epoch": cur.Number,
		"epochs":        epochs,
	})
}

// ── Encryption key endpoint ──────────────────────────────────────────────
//
// DEMO SIMPLIFICATION THAT REMAINS, ON PURPOSE, EVEN IN THIS "PRODUCTION"
// VERSION: this still hands the raw root key to whatever browser calls it.
// Client-side derivation (the browser computing HMAC locally via Web
// Crypto) is the *correct* design — it's what keeps the server from ever
// seeing the plaintext prefix the user is typing. The part that is NOT
// production-ready is WHO is allowed to call this endpoint and WHAT they
// get: it should require an authenticated session, issue a key scoped to
// that tenant/user, embed a short expiry, and be rotated far more often
// than the trie's own encryption epoch. RequireAPIKey (above) is the
// placeholder for that; swap it for real session auth before shipping.
func (h *Handler) EncKey(w http.ResponseWriter, r *http.Request) {
	cur := h.keys.Current()
	n, err := h.enc.NodeCount(cur.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]any{
		"root_key_hex": fmt.Sprintf("%x", cur.RootKey),
		"epoch":        cur.Number,
		"node_count":   n,
		"algorithm":    "HMAC-SHA256 trapdoor · AES-256-GCM payload · epoch-namespaced",
		"expires_hint": "demo: no expiry enforced. Production: short-lived (e.g. 15 min), reissued per session.",
	})
}

// ── Encrypted suggest — client sends trapdoor + nodeKey (+ optional epoch) ──

func (h *Handler) EncSuggest(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	trapdoor := strings.TrimSpace(r.URL.Query().Get("td"))
	nodeKeyHex := strings.TrimSpace(r.URL.Query().Get("nk"))
	epochStr := strings.TrimSpace(r.URL.Query().Get("epoch"))

	if trapdoor == "" || nodeKeyHex == "" {
		writeJSON(w, 400, map[string]string{"error": "td and nk required"})
		return
	}

	epoch := 0
	if epochStr != "" {
		epoch, _ = strconv.Atoi(epochStr)
	}

	validNums := []int{}
	for _, e := range h.keys.ValidEpochs() {
		validNums = append(validNums, e.Number)
	}

	sugs, found, err := h.enc.Query(epoch, trapdoor, nodeKeyHex, validNums)
	elapsed := time.Since(start)

	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}

	if !found {
		writeJSON(w, 200, map[string]any{
			"suggestions": []enctrie.Suggestion{},
			"found":       false,
			"elapsed_us":  elapsed.Microseconds(),
		})
		return
	}

	writeJSON(w, 200, map[string]any{
		"suggestions":    sugs,
		"found":          true,
		"elapsed_us":     elapsed.Microseconds(),
		"node_encrypted": true,
		"cipher":         "AES-256-GCM",
	})
}

// ── Encrypted record retrieval — the step that was missing ────────────────
//
// EncSuggest above only ever returns lightweight autocomplete snippets
// (text/kind/subtitle) from a PREFIX lookup. Selecting a suggestion (or
// pressing Enter on one) needs to actually retrieve something — the full
// description/metadata/tags /api/search already returns for the plain
// path. This is that retrieval step, done as a SEPARATE exact-match
// lookup against enctrie_records (distinct trapdoor/key labels from the
// prefix trie — see keys.DeriveRecordTrapdoor), so it stays genuinely
// end-to-end encrypted: no fallback to a plaintext query anywhere in this
// handler. See SEARCHABLE_ENCRYPTION.md for the full pipeline diagram.
func (h *Handler) EncRecord(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	trapdoor := strings.TrimSpace(r.URL.Query().Get("td"))
	recordKeyHex := strings.TrimSpace(r.URL.Query().Get("rk"))
	epochStr := strings.TrimSpace(r.URL.Query().Get("epoch"))

	if trapdoor == "" || recordKeyHex == "" {
		writeJSON(w, 400, map[string]string{"error": "td and rk required"})
		return
	}

	epoch := 0
	if epochStr != "" {
		epoch, _ = strconv.Atoi(epochStr)
	}

	validNums := []int{}
	for _, e := range h.keys.ValidEpochs() {
		validNums = append(validNums, e.Number)
	}

	results, found, err := h.enc.QueryRecord(epoch, trapdoor, recordKeyHex, validNums)
	elapsed := time.Since(start)

	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}

	if !found {
		writeJSON(w, 200, map[string]any{
			"results":    []models.SearchResult{},
			"found":      false,
			"elapsed_us": elapsed.Microseconds(),
		})
		return
	}

	writeJSON(w, 200, map[string]any{
		"results":          results,
		"found":            true,
		"elapsed_us":       elapsed.Microseconds(),
		"record_encrypted": true,
		"cipher":           "AES-256-GCM",
	})
}

// ── Admin: manual rebuild / rotate (gated by RequireAPIKey) ─────────────────

func (h *Handler) AdminRebuild(w http.ResponseWriter, r *http.Request) {
	cur := h.keys.Current()
	n, elapsed, err := h.enc.FullRebuild(cur.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	rn, relapsed, err := h.enc.FullRebuildRecords(cur.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]any{
		"epoch":      cur.Number,
		"node_count": n, "elapsed_ms": elapsed.Milliseconds(),
		"record_count": rn, "records_elapsed_ms": relapsed.Milliseconds(),
	})
}

func (h *Handler) AdminRotate(w http.ResponseWriter, r *http.Request) {
	graceSec, _ := strconv.Atoi(r.URL.Query().Get("grace_seconds"))
	if graceSec <= 0 {
		graceSec = 86400 // 24h default in real usage
	}
	newE, oldE, err := h.keys.Rotate(time.Duration(graceSec) * time.Second)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	n, elapsed, err := h.enc.RotateReencrypt(oldE.Number, newE.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	rn, relapsed, err := h.enc.RotateReencryptRecords(oldE.Number, newE.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]any{
		"new_epoch": newE.Number, "old_epoch": oldE.Number,
		"nodes_reencrypted":                n,
		"records_reencrypted":              rn,
		"elapsed_ms":                       elapsed.Milliseconds() + relapsed.Milliseconds(),
		"old_epoch_readable_until_seconds": graceSec,
	})
}

// ── Plain suggest (unchanged from the original demo) ────────────────────────

func (h *Handler) Suggest(w http.ResponseWriter, r *http.Request) {
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if q == "" {
		writeJSON(w, 200, []models.Suggestion{})
		return
	}
	out, err := h.suggest(q)
	if err != nil {
		log.Printf("suggest q=%q err=%v", q, err)
		writeJSON(w, 200, []models.Suggestion{})
		return
	}
	writeJSON(w, 200, out)
}

func (h *Handler) suggest(q string) ([]models.Suggestion, error) {
	prefix := q + "%"
	anywhere := "%" + q + "%"
	const sqlQ = `
		SELECT text, kind, subtitle, rank FROM (
			SELECT
				name AS text, 'company' AS kind,
				COALESCE(sector, '') || ' · ' || COALESCE(country, '') AS subtitle,
				CASE WHEN name ILIKE $1 THEN 2 ELSE 1 END AS rank
			FROM companies WHERE name ILIKE $1 OR name ILIKE $2
			UNION ALL
			SELECT p.name, 'product',
				COALESCE(p.category,'') || ' · ' || COALESCE(c.name,''),
				CASE WHEN p.name ILIKE $1 THEN 2 ELSE 1 END
			FROM products p LEFT JOIN companies c ON c.id = p.company_id
			WHERE p.name ILIKE $1 OR p.name ILIKE $2
			UNION ALL
			SELECT name, 'trend',
				COALESCE(category,'') || ' · ' || COALESCE(adoption_stage,''),
				CASE WHEN name ILIKE $1 THEN 2 ELSE 1 END
			FROM trends WHERE name ILIKE $1 OR name ILIKE $2
			UNION ALL
			SELECT title, 'innovation',
				COALESCE(field,'') || ' · ' || year::text,
				CASE WHEN title ILIKE $1 THEN 2 ELSE 1 END
			FROM innovations WHERE title ILIKE $1 OR title ILIKE $2
		) t ORDER BY rank DESC, length(text) ASC LIMIT 8
	`
	rows, err := h.db.Query(sqlQ, prefix, anywhere)
	if err != nil {
		return nil, fmt.Errorf("suggest query: %w", err)
	}
	defer rows.Close()
	var out []models.Suggestion
	for rows.Next() {
		var s models.Suggestion
		var rank int
		if err := rows.Scan(&s.Text, &s.Kind, &s.Subtitle, &rank); err == nil {
			out = append(out, s)
		}
	}
	if out == nil {
		out = []models.Suggestion{}
	}
	return out, nil
}

// ── Search (unchanged) ────────────────────────────────────────────────────

func (h *Handler) Search(w http.ResponseWriter, r *http.Request) {
	q := strings.TrimSpace(r.URL.Query().Get("q"))
	if q == "" {
		writeJSON(w, 400, map[string]string{"error": "q required"})
		return
	}
	start := time.Now()
	results, err := h.search(q)
	if err != nil {
		log.Printf("search q=%q err=%v", q, err)
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, models.SearchResponse{
		Query:      q,
		Results:    results,
		TotalCount: len(results),
		ElapsedMs:  time.Since(start).Milliseconds(),
	})
}

func (h *Handler) search(q string) ([]models.SearchResult, error) {
	like := "%" + q + "%"
	const sqlQ = `
		SELECT id, kind, title, subtitle, description, badge, meta, score, tags
		FROM (
			SELECT c.id AS id, 'company' AS kind, c.name AS title,
				COALESCE(c.sector,'') || ' · ' || COALESCE(c.country,'') AS subtitle,
				COALESCE(c.description,'') AS description,
				CASE WHEN c.is_public THEN 'PUBLIC' || CASE WHEN c.ticker IS NOT NULL THEN ' · ' || c.ticker ELSE '' END ELSE 'PRIVATE' END AS badge,
				json_build_array(
					json_build_object('label','Founded','value',COALESCE(c.founded_year::text,'N/A')),
					json_build_object('label','Employees','value',COALESCE(c.employee_count::text,'N/A')),
					json_build_object('label','Market Cap','value',CASE WHEN c.market_cap_billion IS NOT NULL THEN '$'||c.market_cap_billion::text||'B' ELSE 'Private' END)
				)::text AS meta,
				GREATEST(similarity(c.name,$1), ts_rank(c.search_vector,websearch_to_tsquery('english',$1))) AS score,
				'[]'::text AS tags
			FROM companies c
			WHERE c.name ILIKE $2 OR c.description ILIKE $2 OR c.search_vector @@ websearch_to_tsquery('english',$1)
			UNION ALL
			SELECT p.id, 'product', p.name,
				COALESCE(p.category,'') || ' · ' || COALESCE(c.name,''),
				COALESCE(p.description,''), COALESCE(p.version,''),
				json_build_array(
					json_build_object('label','Launched','value',COALESCE(p.launch_year::text,'N/A')),
					json_build_object('label','Rating','value',CASE WHEN p.rating IS NOT NULL THEN p.rating::text||'/5' ELSE 'N/A' END),
					json_build_object('label','MAU','value',CASE WHEN p.monthly_active_users_million IS NOT NULL THEN p.monthly_active_users_million::text||'M' ELSE 'N/A' END)
				)::text,
				GREATEST(similarity(p.name,$1),ts_rank(p.search_vector,websearch_to_tsquery('english',$1))),
				COALESCE(array_to_json(p.tags)::text,'[]')
			FROM products p LEFT JOIN companies c ON c.id=p.company_id
			WHERE p.name ILIKE $2 OR p.description ILIKE $2 OR array_to_string(p.tags,' ') ILIKE $2 OR p.search_vector @@ websearch_to_tsquery('english',$1)
			UNION ALL
			SELECT i.id, 'innovation', i.title,
				COALESCE(i.field,'') || ' · ' || COALESCE(i.institution,''),
				COALESCE(i.abstract,''), i.year::text,
				json_build_array(
					json_build_object('label','Citations','value',COALESCE(i.citations::text,'0')),
					json_build_object('label','Impact','value',COALESCE(i.impact_score::text,'N/A')),
					json_build_object('label','arXiv','value',COALESCE(i.arxiv_id,'N/A'))
				)::text,
				GREATEST(similarity(i.title,$1),ts_rank(i.search_vector,websearch_to_tsquery('english',$1))),
				'[]'::text
			FROM innovations i
			WHERE i.title ILIKE $2 OR i.abstract ILIKE $2 OR i.search_vector @@ websearch_to_tsquery('english',$1)
			UNION ALL
			SELECT t.id, 'trend', t.name,
				COALESCE(t.category,'') || ' · ' || COALESCE(t.adoption_stage,''),
				COALESCE(t.description,''), 'MOMENTUM '||t.momentum_score::text,
				json_build_array(
					json_build_object('label','Emerged','value',COALESCE(t.year_emerged::text,'N/A')),
					json_build_object('label','Stage','value',COALESCE(t.adoption_stage,'N/A')),
					json_build_object('label','Score','value',t.momentum_score::text||'/100')
				)::text,
				GREATEST(similarity(t.name,$1),ts_rank(t.search_vector,websearch_to_tsquery('english',$1))),
				COALESCE(array_to_json(t.related_tags)::text,'[]')
			FROM trends t
			WHERE t.name ILIKE $2 OR t.description ILIKE $2 OR array_to_string(t.related_tags,' ') ILIKE $2 OR t.search_vector @@ websearch_to_tsquery('english',$1)
		) combined ORDER BY score DESC LIMIT 20
	`
	rows, err := h.db.Query(sqlQ, q, like)
	if err != nil {
		return nil, fmt.Errorf("search query: %w", err)
	}
	defer rows.Close()
	var out []models.SearchResult
	for rows.Next() {
		var r models.SearchResult
		var meta, tags string
		if err := rows.Scan(&r.ID, &r.Kind, &r.Title, &r.Subtitle, &r.Description, &r.Badge, &meta, &r.Score, &tags); err != nil {
			log.Printf("scan: %v", err)
			continue
		}
		if err := json.Unmarshal([]byte(meta), &r.Meta); err != nil {
			r.Meta = []models.MetaItem{}
		}
		if tags != "" && tags != "[]" {
			json.Unmarshal([]byte(tags), &r.Tags)
		}
		out = append(out, r)
	}
	if out == nil {
		out = []models.SearchResult{}
	}
	return out, nil
}

// ── Benchmarks ───────────────────────────────────────────────────────────
//
// IMPORTANT — these measurements are NOT comparable 1:1. They measure
// different operations with different cost models:
//
//   plain / encrypted (Bench)  → cost PER KEYSTROKE, steady state
//   rebuild (BenchRebuild)     → one-time (or scheduled) cost, amortized
//                                 over every query served until the next
//                                 rebuild
//   incremental (BenchIncremental) → cost paid once PER DATA CHANGE, off
//                                 the read path entirely (async, via the
//                                 outbox)
//   rotate (BenchRotate)       → cost paid once PER ROTATION (a scheduled
//                                 security operation, not a per-request or
//                                 per-write cost)
//
// Every endpoint below returns which bucket it belongs to explicitly so
// the numbers can't be mixed together into a misleading headline ratio.

type BenchResult struct {
	Mode    string  `json:"mode"`
	Queries int     `json:"queries"`
	Samples []int64 `json:"samples"`
	P50     int64   `json:"p50"`
	P90     int64   `json:"p90"`
	P95     int64   `json:"p95"`
	P99     int64   `json:"p99"`
	Min     int64   `json:"min"`
	Max     int64   `json:"max"`
	Mean    float64 `json:"mean"`
	StdDev  float64 `json:"std_dev"`
}

// Bench compares per-keystroke read latency: plain Postgres ILIKE (scan
// across a UNION of 4 tables, GIN-trigram-accelerated) vs. the encrypted
// trie's Postgres point lookup (indexed exact match on enctrie_nodes's
// primary key). BOTH PATHS HIT POSTGRES on every single call — there is no
// in-memory shortcut on either side. The difference measured here is
// query complexity, not "database vs. no database."
func (h *Handler) Bench(w http.ResponseWriter, r *http.Request) {
	n, _ := strconv.Atoi(r.URL.Query().Get("n"))
	if n < 10 || n > 500 {
		n = 100
	}
	prefixes := []string{
		"a", "r", "ru", "go", "py", "ts", "ml", "ai", "ra", "db",
		"ru", "kub", "ter", "rus", "ten", "pyto", "go ", "open", "vec", "tr",
		"att", "bert", "llo", "stab", "diff", "lora", "flas", "clip", "gpt", "llm",
	}

	cur := h.keys.Current()
	validNums := []int{}
	for _, e := range h.keys.ValidEpochs() {
		validNums = append(validNums, e.Number)
	}

	var plainSamples, encSamples []int64
	for i := 0; i < n; i++ {
		q := prefixes[i%len(prefixes)]

		t0 := time.Now()
		h.suggest(q) //nolint:errcheck
		plainSamples = append(plainSamples, time.Since(t0).Microseconds())

		td := keys.DeriveTrapdoor(cur.RootKey, cur.Number, q)
		nk := fmt.Sprintf("%x", keys.DeriveNodeKey(cur.RootKey, cur.Number, q))
		t1 := time.Now()
		h.enc.Query(cur.Number, td, nk, validNums) //nolint:errcheck
		encSamples = append(encSamples, time.Since(t1).Microseconds())
	}

	writeJSON(w, 200, map[string]any{
		"category":  "per-keystroke read latency — BOTH paths hit Postgres on every call",
		"n":         n,
		"plain":     calcStats("plain", plainSamples),
		"encrypted": calcStats("encrypted", encSamples),
		"caveat": "Both sides run a live SQL query against the same Postgres instance: " +
			"'plain' does a pattern-match ILIKE scan (GIN-trigram-accelerated) across a " +
			"UNION of 4 tables; 'encrypted' does an exact-match point lookup on " +
			"enctrie_nodes's primary key (epoch, trapdoor). Neither side uses an " +
			"in-memory cache. The gap you see is query complexity (scan vs. point " +
			"lookup), not 'database vs. no database'. Building/maintaining the " +
			"encrypted side has its own cost, measured separately by " +
			"/api/bench/rebuild, /api/bench/incremental, and /api/bench/rotate. " +
			"See ARCHITECTURE.md.",
	})
}

// BenchRebuild times a full trie rebuild from the source tables — the
// one-time/scheduled cost that "pays for" all the fast reads afterward.
func (h *Handler) BenchRebuild(w http.ResponseWriter, r *http.Request) {
	cur := h.keys.Current()
	n, elapsed, err := h.enc.FullRebuild(cur.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	rn, relapsed, err := h.enc.FullRebuildRecords(cur.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]any{
		"category":           "full rebuild (one-time / scheduled cost)",
		"epoch":              cur.Number,
		"node_count":         n,
		"elapsed_ms":         elapsed.Milliseconds(),
		"record_count":       rn,
		"records_elapsed_ms": relapsed.Milliseconds(),
		"note": "node_count/elapsed_ms is the prefix-suggestion trie (enctrie_nodes); " +
			"record_count/records_elapsed_ms is the exact-match retrieval store " +
			"(enctrie_records) — see SEARCHABLE_ENCRYPTION.md.",
	})
}

// BenchIncremental measures the cost of adding, then updating, then
// deleting a synthetic keyword in the dedicated bench_keywords table, and
// how long the resulting incremental trie update takes. It does not touch
// real seed data.
func (h *Handler) BenchIncremental(w http.ResponseWriter, r *http.Request) {
	cur := h.keys.Current()
	suffix := rand.Intn(1_000_000)
	word := fmt.Sprintf("BenchKeyword%06d", suffix)
	updated := word + "Updated"

	steps := []map[string]any{}

	// INSERT
	t0 := time.Now()
	var id int
	if err := h.db.QueryRow(
		`INSERT INTO bench_keywords (text, kind, subtitle) VALUES ($1,'bench','synthetic · churn test') RETURNING id`,
		word).Scan(&id); err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	insertMs := time.Since(t0).Milliseconds()

	t1 := time.Now()
	touched, elapsed, err := h.enc.UpdateKeyword(cur.Number, "", word)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	steps = append(steps, map[string]any{
		"step": "insert", "pg_write_ms": insertMs,
		"trie_update_us": elapsed.Microseconds(), "prefixes_touched": touched,
		"total_direct_ms": time.Since(t1).Milliseconds() + insertMs,
	})

	// UPDATE
	t2 := time.Now()
	if _, err := h.db.Exec(`UPDATE bench_keywords SET text=$1 WHERE id=$2`, updated, id); err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	updateMs := time.Since(t2).Milliseconds()
	t3 := time.Now()
	touched2, elapsed2, err := h.enc.UpdateKeyword(cur.Number, word, updated)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	steps = append(steps, map[string]any{
		"step": "update", "pg_write_ms": updateMs,
		"trie_update_us": elapsed2.Microseconds(), "prefixes_touched": touched2,
		"total_direct_ms": time.Since(t3).Milliseconds() + updateMs,
	})

	// DELETE
	t4 := time.Now()
	if _, err := h.db.Exec(`DELETE FROM bench_keywords WHERE id=$1`, id); err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	deleteMs := time.Since(t4).Milliseconds()
	t5 := time.Now()
	touched3, elapsed3, err := h.enc.UpdateKeyword(cur.Number, updated, "")
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	steps = append(steps, map[string]any{
		"step": "delete", "pg_write_ms": deleteMs,
		"trie_update_us": elapsed3.Microseconds(), "prefixes_touched": touched3,
		"total_direct_ms": time.Since(t5).Milliseconds() + deleteMs,
	})

	writeJSON(w, 200, map[string]any{
		"category": "incremental update (cost paid once per data change, off the read path)",
		"note":     "trie_update_* times are direct calls (what the outbox processor itself pays). Postgres triggers + LISTEN/NOTIFY add a small additional propagation delay in the fully async path.",
		"steps":    steps,
	})
}

// BenchRotate performs a real key rotation (new epoch + re-encrypt every
// node) and reports timing. grace_seconds controls how long the outgoing
// epoch stays readable before its key material is deleted.
func (h *Handler) BenchRotate(w http.ResponseWriter, r *http.Request) {
	graceSec, _ := strconv.Atoi(r.URL.Query().Get("grace_seconds"))
	if graceSec <= 0 {
		graceSec = 10 // short default so the demo can show pruning happen
	}
	newE, oldE, err := h.keys.Rotate(time.Duration(graceSec) * time.Second)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	n, elapsed, err := h.enc.RotateReencrypt(oldE.Number, newE.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	rn, relapsed, err := h.enc.RotateReencryptRecords(oldE.Number, newE.Number)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	writeJSON(w, 200, map[string]any{
		"category":                         "key rotation (scheduled security operation, not a per-request cost)",
		"new_epoch":                        newE.Number,
		"old_epoch":                        oldE.Number,
		"nodes_reencrypted":                n,
		"records_reencrypted":              rn,
		"elapsed_ms":                       elapsed.Milliseconds() + relapsed.Milliseconds(),
		"old_epoch_readable_until_seconds": graceSec,
		"note":                             "Rotates BOTH the prefix-suggestion trie (enctrie_nodes) and the exact-match retrieval store (enctrie_records). Both epochs are queryable during the grace window (dual-key read). After grace_seconds elapses, a background pruner deletes the old epoch's key material and rows in both tables permanently — see keys.Store.PruneExpired.",
	})
}

func calcStats(mode string, samples []int64) BenchResult {
	if len(samples) == 0 {
		return BenchResult{Mode: mode}
	}
	sorted := make([]int64, len(samples))
	copy(sorted, samples)
	sort.Slice(sorted, func(i, j int) bool { return sorted[i] < sorted[j] })

	var sum float64
	for _, v := range sorted {
		sum += float64(v)
	}
	mean := sum / float64(len(sorted))

	var variance float64
	for _, v := range sorted {
		d := float64(v) - mean
		variance += d * d
	}
	variance /= float64(len(sorted))

	pct := func(p float64) int64 {
		idx := int(math.Ceil(p/100*float64(len(sorted)))) - 1
		if idx < 0 {
			idx = 0
		}
		if idx >= len(sorted) {
			idx = len(sorted) - 1
		}
		return sorted[idx]
	}

	return BenchResult{
		Mode:    mode,
		Queries: len(samples),
		Samples: samples,
		P50:     pct(50),
		P90:     pct(90),
		P95:     pct(95),
		P99:     pct(99),
		Min:     sorted[0],
		Max:     sorted[len(sorted)-1],
		Mean:    mean,
		StdDev:  math.Sqrt(variance),
	}
}

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}
