package handlers

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/lib/pq"
)

// ── Guided data-entry: schema description ───────────────────────────────────
//
// This exists to answer "where do I add data, and what does it actually
// create?" directly in the product, not just in a doc. GET /api/data/schema
// returns a machine-readable description of every content type this system
// indexes, which field is the one that becomes searchable text (the field
// that gets walked into trie prefixes), and a plain-English explanation of
// the full pipeline a write triggers.

type FieldSpec struct {
	Name        string   `json:"name"`
	Label       string   `json:"label"`
	Type        string   `json:"type"` // "text" | "textarea" | "number" | "checkbox" | "tags" | "select"
	Required    bool     `json:"required"`
	Placeholder string   `json:"placeholder,omitempty"`
	Help        string   `json:"help,omitempty"`
	Options     []string `json:"options,omitempty"` // for type "select"
}

type KindSpec struct {
	Kind        string      `json:"kind"`        // "company" | "product" | "trend" | "innovation"
	Label       string      `json:"label"`       // "Company"
	Table       string      `json:"table"`       // "companies"
	TitleField  string      `json:"title_field"` // which field becomes the searchable/indexed text
	Fields      []FieldSpec `json:"fields"`
	Explanation string      `json:"explanation"`
}

func dataKindSpecs() []KindSpec {
	return []KindSpec{
		{
			Kind: "company", Label: "Company", Table: "companies", TitleField: "name",
			Explanation: "companies.name is the text that gets indexed. Every prefix of it " +
				"(\"c\", \"cl\", \"cla\"… for \"Claude\") becomes one row in enctrie_nodes.",
			Fields: []FieldSpec{
				{Name: "name", Label: "Company name", Type: "text", Required: true, Placeholder: "e.g. Anthropic"},
				{Name: "ticker", Label: "Stock ticker", Type: "text", Placeholder: "e.g. NVDA (leave blank if private)"},
				{Name: "sector", Label: "Sector", Type: "text", Placeholder: "e.g. Artificial Intelligence"},
				{Name: "country", Label: "Country", Type: "text", Placeholder: "e.g. United States"},
				{Name: "founded_year", Label: "Founded year", Type: "number", Placeholder: "e.g. 2021"},
				{Name: "market_cap_billion", Label: "Market cap ($B)", Type: "number", Help: "leave blank if private"},
				{Name: "employee_count", Label: "Employees", Type: "number"},
				{Name: "website", Label: "Website", Type: "text", Placeholder: "e.g. anthropic.com"},
				{Name: "is_public", Label: "Publicly traded", Type: "checkbox"},
				{Name: "description", Label: "Description", Type: "textarea"},
			},
		},
		{
			Kind: "product", Label: "Product / Technology", Table: "products", TitleField: "name",
			Explanation: "products.name is the text that gets indexed the same way companies.name " +
				"does. Optionally link it to a company by name (looked up server-side).",
			Fields: []FieldSpec{
				{Name: "name", Label: "Product name", Type: "text", Required: true, Placeholder: "e.g. Claude"},
				{Name: "company_name", Label: "Company (optional)", Type: "text", Placeholder: "e.g. Anthropic", Help: "matched by name against existing companies; leave blank if none"},
				{Name: "category", Label: "Category", Type: "text", Placeholder: "e.g. Language Model"},
				{Name: "launch_year", Label: "Launch year", Type: "number"},
				{Name: "version", Label: "Version", Type: "text", Placeholder: "e.g. v5"},
				{Name: "rating", Label: "Rating (0-5)", Type: "number"},
				{Name: "monthly_active_users_million", Label: "MAU (millions)", Type: "number"},
				{Name: "tags", Label: "Tags", Type: "tags", Placeholder: "comma-separated, e.g. llm, chat, api"},
				{Name: "description", Label: "Description", Type: "textarea"},
			},
		},
		{
			Kind: "trend", Label: "Tech Trend", Table: "trends", TitleField: "name",
			Explanation: "trends.name is the text that gets indexed, exactly like companies.name.",
			Fields: []FieldSpec{
				{Name: "name", Label: "Trend name", Type: "text", Required: true, Placeholder: "e.g. Agentic Coding"},
				{Name: "category", Label: "Category", Type: "text", Placeholder: "e.g. Developer Tools"},
				{Name: "momentum_score", Label: "Momentum score (0-100)", Type: "number"},
				{Name: "year_emerged", Label: "Year emerged", Type: "number"},
				{Name: "adoption_stage", Label: "Adoption stage", Type: "select",
					Options: []string{"emerging", "growing", "mainstream", "declining"}},
				{Name: "related_tags", Label: "Related tags", Type: "tags", Placeholder: "comma-separated"},
				{Name: "description", Label: "Description", Type: "textarea"},
			},
		},
		{
			Kind: "innovation", Label: "Research / Innovation", Table: "innovations", TitleField: "title",
			Explanation: "innovations.title is the text that gets indexed — same mechanism, " +
				"different column name (title instead of name).",
			Fields: []FieldSpec{
				{Name: "title", Label: "Title", Type: "text", Required: true, Placeholder: "e.g. Constitutional AI"},
				{Name: "institution", Label: "Institution", Type: "text", Placeholder: "e.g. Anthropic"},
				{Name: "year", Label: "Year", Type: "number"},
				{Name: "field", Label: "Field", Type: "text", Placeholder: "e.g. AI Safety"},
				{Name: "citations", Label: "Citations", Type: "number"},
				{Name: "impact_score", Label: "Impact score", Type: "number"},
				{Name: "arxiv_id", Label: "arXiv ID", Type: "text", Placeholder: "e.g. 2212.08073"},
				{Name: "authors", Label: "Authors", Type: "tags", Placeholder: "comma-separated"},
				{Name: "abstract", Label: "Abstract", Type: "textarea"},
			},
		},
	}
}

func (h *Handler) DataSchema(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, 200, map[string]any{
		"kinds": dataKindSpecs(),
		"how_it_works": []string{
			"1. Your submission is a plain SQL INSERT into one of four source tables " +
				"(companies, products, trends, innovations) — the exact same tables /api/search and " +
				"/api/suggest already query live.",
			"2. A Postgres trigger on that table fires automatically and writes one row into " +
				"enctrie_outbox recording the new keyword.",
			"3. This request ALSO calls the same incremental-update code path directly (the same one " +
				"the outbox uses) so the new item is searchable in BOTH tabs immediately, without waiting.",
			"4. That code walks every prefix of the new text (\"c\", \"cl\", \"cla\"… for \"Claude\") and, " +
				"for each one, re-derives the AES-256-GCM-encrypted node and UPSERTs it into enctrie_nodes " +
				"— the same table every /api/enc-suggest read queries. No full rebuild, no cache to warm.",
			"5. The response below reports exactly how long each of those steps took, for real, on this " +
				"request — try adding something and searching for it in both tabs right after.",
		},
	})
}

// ── Guided data-entry: create ────────────────────────────────────────────────

type dataCreateResult struct {
	ID              int    `json:"id"`
	Kind            string `json:"kind"`
	IndexedText     string `json:"indexed_text"`
	PgWriteMs       int64  `json:"pg_write_ms"`
	TrieUpdateUs    int64  `json:"trie_update_us"`
	PrefixesTouched int    `json:"prefixes_touched"`
	TryPrefix       string `json:"try_prefix"` // suggested short prefix to test-search
}

func (h *Handler) DataCreate(w http.ResponseWriter, r *http.Request) {
	kind := r.PathValue("kind")

	var (
		id          int
		indexedText string
		pgWriteMs   int64
		err         error
	)

	t0 := time.Now()
	switch kind {
	case "company":
		id, indexedText, err = h.createCompany(r)
	case "product":
		id, indexedText, err = h.createProduct(r)
	case "trend":
		id, indexedText, err = h.createTrend(r)
	case "innovation":
		id, indexedText, err = h.createInnovation(r)
	default:
		writeJSON(w, 400, map[string]string{"error": "unknown kind: " + kind + " (want company|product|trend|innovation)"})
		return
	}
	pgWriteMs = time.Since(t0).Milliseconds()

	if err != nil {
		writeJSON(w, 400, map[string]string{"error": err.Error()})
		return
	}

	cur := h.keys.Current()
	touched, elapsed, updErr := h.enc.UpdateKeyword(cur.Number, "", indexedText)
	// Also update the exact-match retrieval store so the new item can be
	// fully retrieved (not just suggested) the moment this returns —
	// mirrors UpdateKeyword above but for enctrie_records instead of
	// enctrie_nodes. Best-effort: a prefix-suggestion failure already
	// falls back to the outbox catching up shortly; same here.
	h.enc.UpdateRecordKeyword(cur.Number, "", indexedText) //nolint:errcheck
	if updErr != nil {
		// The plaintext write already succeeded and is live for /api/search
		// and /api/suggest; the encrypted trie will still catch up shortly
		// via the outbox even if this synchronous fast-path failed.
		writeJSON(w, 200, dataCreateResult{
			ID: id, Kind: kind, IndexedText: indexedText, PgWriteMs: pgWriteMs,
			TrieUpdateUs: -1, PrefixesTouched: 0,
			TryPrefix: shortPrefix(indexedText),
		})
		return
	}

	writeJSON(w, 200, dataCreateResult{
		ID: id, Kind: kind, IndexedText: indexedText, PgWriteMs: pgWriteMs,
		TrieUpdateUs: elapsed.Microseconds(), PrefixesTouched: touched,
		TryPrefix: shortPrefix(indexedText),
	})
}

func shortPrefix(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	runes := []rune(s)
	n := 3
	if len(runes) < n {
		n = len(runes)
	}
	return string(runes[:n])
}

func (h *Handler) createCompany(r *http.Request) (int, string, error) {
	var in struct {
		Name             string   `json:"name"`
		Ticker           *string  `json:"ticker"`
		Sector           *string  `json:"sector"`
		Country          *string  `json:"country"`
		FoundedYear      *int     `json:"founded_year"`
		MarketCapBillion *float64 `json:"market_cap_billion"`
		EmployeeCount    *int     `json:"employee_count"`
		Website          *string  `json:"website"`
		IsPublic         bool     `json:"is_public"`
		Description      *string  `json:"description"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		return 0, "", fmt.Errorf("invalid JSON: %w", err)
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return 0, "", fmt.Errorf("name is required")
	}
	var id int
	err := h.db.QueryRow(`
		INSERT INTO companies (name, ticker, sector, country, founded_year, market_cap_billion, employee_count, website, is_public, description)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
		in.Name, in.Ticker, in.Sector, in.Country, in.FoundedYear, in.MarketCapBillion,
		in.EmployeeCount, in.Website, in.IsPublic, in.Description,
	).Scan(&id)
	if err != nil {
		return 0, "", fmt.Errorf("insert company: %w", err)
	}
	return id, in.Name, nil
}

func (h *Handler) createProduct(r *http.Request) (int, string, error) {
	var in struct {
		Name        string   `json:"name"`
		CompanyName *string  `json:"company_name"`
		Category    *string  `json:"category"`
		LaunchYear  *int     `json:"launch_year"`
		Version     *string  `json:"version"`
		Rating      *float64 `json:"rating"`
		MAUMillion  *float64 `json:"monthly_active_users_million"`
		Tags        string   `json:"tags"` // comma-separated from the guided form
		Description *string  `json:"description"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		return 0, "", fmt.Errorf("invalid JSON: %w", err)
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return 0, "", fmt.Errorf("name is required")
	}

	var companyID sql.NullInt64
	if in.CompanyName != nil && strings.TrimSpace(*in.CompanyName) != "" {
		var cid int
		lookupErr := h.db.QueryRow(`SELECT id FROM companies WHERE name ILIKE $1 LIMIT 1`, strings.TrimSpace(*in.CompanyName)).Scan(&cid)
		if lookupErr == nil {
			companyID = sql.NullInt64{Int64: int64(cid), Valid: true}
		}
		// If no match, we silently leave it unlinked rather than failing the
		// whole submission — the guided form's help text says company is optional.
	}

	tags := splitTags(in.Tags)

	var id int
	err := h.db.QueryRow(`
		INSERT INTO products (company_id, name, category, launch_year, version, description, tags, rating, monthly_active_users_million)
		VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
		companyID, in.Name, in.Category, in.LaunchYear, in.Version, in.Description,
		pqStringArray(tags), in.Rating, in.MAUMillion,
	).Scan(&id)
	if err != nil {
		return 0, "", fmt.Errorf("insert product: %w", err)
	}
	return id, in.Name, nil
}

func (h *Handler) createTrend(r *http.Request) (int, string, error) {
	var in struct {
		Name          string  `json:"name"`
		Category      *string `json:"category"`
		MomentumScore *int    `json:"momentum_score"`
		YearEmerged   *int    `json:"year_emerged"`
		AdoptionStage *string `json:"adoption_stage"`
		RelatedTags   string  `json:"related_tags"`
		Description   *string `json:"description"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		return 0, "", fmt.Errorf("invalid JSON: %w", err)
	}
	in.Name = strings.TrimSpace(in.Name)
	if in.Name == "" {
		return 0, "", fmt.Errorf("name is required")
	}
	tags := splitTags(in.RelatedTags)
	var id int
	err := h.db.QueryRow(`
		INSERT INTO trends (name, category, momentum_score, year_emerged, description, related_tags, adoption_stage)
		VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
		in.Name, in.Category, in.MomentumScore, in.YearEmerged, in.Description,
		pqStringArray(tags), in.AdoptionStage,
	).Scan(&id)
	if err != nil {
		return 0, "", fmt.Errorf("insert trend: %w", err)
	}
	return id, in.Name, nil
}

func (h *Handler) createInnovation(r *http.Request) (int, string, error) {
	var in struct {
		Title       string   `json:"title"`
		Institution *string  `json:"institution"`
		Year        *int     `json:"year"`
		Field       *string  `json:"field"`
		Citations   *int     `json:"citations"`
		ImpactScore *float64 `json:"impact_score"`
		ArxivID     *string  `json:"arxiv_id"`
		Authors     string   `json:"authors"`
		Abstract    *string  `json:"abstract"`
	}
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil {
		return 0, "", fmt.Errorf("invalid JSON: %w", err)
	}
	in.Title = strings.TrimSpace(in.Title)
	if in.Title == "" {
		return 0, "", fmt.Errorf("title is required")
	}
	authors := splitTags(in.Authors)
	var id int
	err := h.db.QueryRow(`
		INSERT INTO innovations (title, authors, institution, year, field, abstract, citations, arxiv_id, impact_score)
		VALUES ($1,$2,$3,$4,$5,$6,COALESCE($7,0),$8,$9) RETURNING id`,
		in.Title, pqStringArray(authors), in.Institution, in.Year, in.Field, in.Abstract,
		in.Citations, in.ArxivID, in.ImpactScore,
	).Scan(&id)
	if err != nil {
		return 0, "", fmt.Errorf("insert innovation: %w", err)
	}
	return id, in.Title, nil
}

func splitTags(s string) []string {
	if strings.TrimSpace(s) == "" {
		return nil
	}
	parts := strings.Split(s, ",")
	out := make([]string, 0, len(parts))
	for _, p := range parts {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

// pqStringArray formats a Go []string as a properly-escaped Postgres TEXT[]
// parameter via lib/pq's array support (nil stays NULL).
func pqStringArray(ss []string) interface{} {
	if ss == nil {
		return nil
	}
	return pq.Array(ss)
}

// ── Guided data-entry: recent additions + delete ─────────────────────────────

type recentItem struct {
	Kind      string    `json:"kind"`
	ID        int       `json:"id"`
	Text      string    `json:"text"`
	CreatedAt time.Time `json:"created_at"`
}

func (h *Handler) DataRecent(w http.ResponseWriter, r *http.Request) {
	rows, err := h.db.Query(`
		SELECT 'company', id, name, created_at FROM companies
		UNION ALL SELECT 'product', id, name, created_at FROM products
		UNION ALL SELECT 'trend', id, name, created_at FROM trends
		UNION ALL SELECT 'innovation', id, title, created_at FROM innovations
		ORDER BY created_at DESC LIMIT 25`)
	if err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	defer rows.Close()
	items := []recentItem{}
	for rows.Next() {
		var it recentItem
		if scanErr := rows.Scan(&it.Kind, &it.ID, &it.Text, &it.CreatedAt); scanErr == nil {
			items = append(items, it)
		}
	}
	writeJSON(w, 200, map[string]any{"items": items})
}

func (h *Handler) DataDelete(w http.ResponseWriter, r *http.Request) {
	kind := r.PathValue("kind")
	idStr := r.PathValue("id")
	id, err := strconv.Atoi(idStr)
	if err != nil {
		writeJSON(w, 400, map[string]string{"error": "invalid id"})
		return
	}

	var table, textCol string
	switch kind {
	case "company":
		table, textCol = "companies", "name"
	case "product":
		table, textCol = "products", "name"
	case "trend":
		table, textCol = "trends", "name"
	case "innovation":
		table, textCol = "innovations", "title"
	default:
		writeJSON(w, 400, map[string]string{"error": "unknown kind: " + kind})
		return
	}

	var text string
	if err := h.db.QueryRow(fmt.Sprintf(`SELECT %s FROM %s WHERE id = $1`, textCol, table), id).Scan(&text); err != nil {
		writeJSON(w, 404, map[string]string{"error": "not found"})
		return
	}

	t0 := time.Now()
	if _, err := h.db.Exec(fmt.Sprintf(`DELETE FROM %s WHERE id = $1`, table), id); err != nil {
		writeJSON(w, 500, map[string]string{"error": err.Error()})
		return
	}
	pgMs := time.Since(t0).Milliseconds()

	cur := h.keys.Current()
	touched, elapsed, _ := h.enc.UpdateKeyword(cur.Number, text, "")
	h.enc.UpdateRecordKeyword(cur.Number, text, "") //nolint:errcheck

	writeJSON(w, 200, map[string]any{
		"deleted": true, "kind": kind, "id": id, "indexed_text": text,
		"pg_write_ms": pgMs, "trie_update_us": elapsed.Microseconds(), "prefixes_touched": touched,
	})
}
