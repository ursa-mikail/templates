# Latency Calculus v2: Plain Postgres vs. Postgres-Backed Encrypted Trie

**This document replaces `latency_calculus_in_mem_demo.md`.** That
document's "200–460× faster" number was measured against a trie that lived
entirely in the Go process's RAM and never touched a database at request
time. It has been deleted from this project. This document measures the
system that actually ships: **the encrypted trie is rows in Postgres,
queried live, on every request, exactly like the plain path.**

---

## What changed, in one sentence

The encrypted side used to skip the database entirely (in-memory
`map[string][]byte` lookup); it now runs a real, indexed SQL query against
`enctrie_nodes` on every single call — same instance, same connection
pool, same network hop as the plain path.

---

## The two systems being compared (both hit Postgres, every request)

### Plain Postgres (`/api/suggest`)

```
Browser keystroke
  → Go handler receives HTTP request
  → Go opens connection from pool (or waits for one)
  → Go serialises SQL query string
  → TCP packet: Go → Postgres (loopback, ~0.05–0.15ms)
  → Postgres parses query
  → Postgres checks query cache (likely miss on first run)
  → Postgres runs ILIKE scan on GIN trigram index, across a
    UNION ALL of 4 tables (companies, products, trends, innovations)
  → Postgres serialises result rows (0–8 rows)
  → TCP packet: Postgres → Go (loopback, ~0.05–0.15ms)
  → Go deserialises rows, builds []Suggestion
  → Go serialises JSON response
  → HTTP response to browser
```

### Encrypted trie (`/api/enc-suggest`) — Postgres-backed, not in-memory

```
Browser keystroke
  → Web Crypto: HMAC-SHA256(rootKey, "td:e<epoch>:"+prefix)   [in-browser]
  → Web Crypto: HMAC-SHA256(rootKey, "node:e<epoch>:"+prefix) [in-browser]
  → Go handler receives HTTP request
  → Go opens connection from pool (or waits for one)
  → Go serialises SQL query string
  → TCP packet: Go → Postgres (loopback, ~0.05–0.15ms)
  → Postgres parses query (trivial plan: single-table PK lookup)
  → Postgres does a B-tree index scan on
    enctrie_nodes PRIMARY KEY (epoch, trapdoor) — 0 or 1 row, exact match
  → Postgres serialises 1 row (ciphertext bytes)
  → TCP packet: Postgres → Go (loopback, ~0.05–0.15ms)
  → Go: AES-256-GCM decrypt (~1–5µs for <1KB payload)
  → Go: json.Unmarshal of decrypted payload
  → Go serialises JSON response
  → HTTP response to browser
```

**Both paths cross the process boundary (Go ⇄ Postgres) at least twice**,
pay the same connection-pool and TCP round-trip costs, and pay Postgres's
own query-parse overhead. The only structural difference is *what kind of
query plan Postgres has to execute*: a multi-table pattern-match scan
versus a single-table exact-match point lookup.

---

## Latency breakdown by component

### Plain Postgres — modeled range ~377–772µs (unchanged from the original demo — this path was never the problem)

| Component | Estimated cost | Notes |
|-----------|---------------|-------|
| Go HTTP parse + route | ~5µs | net/http mux lookup |
| Connection pool acquire | ~10–50µs | varies with pool pressure |
| Query serialisation | ~2µs | string formatting |
| Loopback TCP round-trip (×2) | ~100–200µs | Go→PG, PG→Go |
| Postgres query parse + plan | ~50–100µs | 4-table UNION plan, not trivial |
| GIN trigram index scan | ~200–400µs | scans across 4 tables |
| Row deserialisation in Go | ~5–10µs | up to 8 rows |
| JSON marshal | ~5µs | |
| **Total (model)** | **~377–772µs** | |

### Encrypted trie, Postgres-backed — modeled range ~180–420µs

| Component | Estimated cost | Notes |
|-----------|---------------|-------|
| Go HTTP parse + route | ~5µs | faster path, no SQL string building needed for multiple UNIONs |
| Connection pool acquire | ~10–50µs | **same as plain** — same pool |
| Query serialisation | ~1µs | single parameterized statement |
| Loopback TCP round-trip (×2) | ~100–200µs | **same as plain** — same network hop, same instance |
| Postgres query parse + plan | ~5–15µs | trivial: single-table, PK equality, no join |
| B-tree PK index scan | ~10–50µs | exact match, 0–1 row — no multi-table scan |
| AES-256-GCM decrypt (Go) | ~1–5µs | ~100–500 byte payload |
| `json.Unmarshal` | ~1–3µs | small struct |
| JSON marshal response | ~1–3µs | |
| **Total (model)** | **~134–352µs**, realistically **~180–420µs** with jitter | |

**Modeled speedup at p50: roughly 2–4×** — not 200–460×. This comes
entirely from query-plan simplicity (a single B-tree point lookup vs. a
four-table pattern-match scan), while every network/connection-pool/
process-boundary cost is now shared equally between both paths, because
both paths now pay it.

---

## Latency formula derivation

### Plain Postgres latency model (unchanged)

```
L_plain = T_go_overhead + T_pool_acquire + T_loopback×2
        + T_pg_parse + T_pg_plan + T_pg_scan(N_rows, idx_type)
        + T_deser(N_rows) + T_json_marshal

  T_go_overhead  ≈ 5–10µs
  T_pool_acquire ≈ 10–100µs
  T_loopback     ≈ 50–150µs   (per direction)
  T_pg_parse     ≈ 10–30µs
  T_pg_plan      ≈ 20–80µs    (4-table UNION plan)
  T_pg_scan      ≈ 100–400µs  (GIN trigram scan, 4-table UNION ALL)
  T_deser        ≈ 2–10µs
  T_json_marshal ≈ 3–8µs
```

### Encrypted-trie latency model (Postgres-backed)

```
L_enc = T_go_overhead + T_pool_acquire + T_loopback×2
      + T_pg_parse + T_pg_plan + T_pg_pk_lookup
      + T_aes_gcm(len_bytes) + T_json_unmarshal + T_json_marshal_response

  T_go_overhead   ≈ 3–5µs      (simpler request, one param pair)
  T_pool_acquire  ≈ 10–100µs   (SAME pool as plain — no advantage here)
  T_loopback      ≈ 50–150µs   (SAME network hop as plain — no advantage here)
  T_pg_parse      ≈ 3–8µs      (trivial single-table plan)
  T_pg_plan       ≈ 2–10µs     (equality on a PK — near-instant plan)
  T_pg_pk_lookup  ≈ 10–50µs    (B-tree descent, 0–1 row, no join, no scan)
  T_aes_gcm(B)    ≈ B/500MB/s  (AES-NI: ~0.2µs/100B, ~1µs/500B)
  T_json_unmarshal≈ 0.3–1µs
  T_json_marshal  ≈ 0.3–1µs
```

Notice that **connection pool acquisition and network round-trip — the two
largest line items in the plain path — are identical in both models.**
That's the honest version of this comparison: the win is concentrated
entirely in `T_pg_scan` (100–400µs, multi-table pattern match) shrinking to
`T_pg_pk_lookup` (10–50µs, single-table exact match). Nothing else changes,
because nothing else *should* change — both paths are the same kind of
operation against the same database now.

---

## New: cost models this document didn't previously cover

The original document only measured steady-state reads and stopped there,
which is exactly what made its headline number misleading — it never
showed what it cost to get the fast path into a servable state in the
first place. Here is that cost, in full, because a system that "encrypts
faster than it reads" but never accounts for build/maintenance cost is not
telling the whole story.

### A. Full rebuild — `FullRebuild(epoch)`

```
T_rebuild = T_load_keywords + T_build_prefixmap + Σ(T_aes_encrypt + T_pg_insert)

  T_load_keywords   ≈ 2–8ms     (one UNION query across 5 source tables)
  T_build_prefixmap ≈ 1–3ms     (in-Go, walking every prefix of every keyword —
                                  held in memory only for this one call, see
                                  ARCHITECTURE.md §3.2)
  N_nodes           ≈ 800–1,500 for the seed dataset (grows with real data)
  T_aes_encrypt     ≈ 1–2µs per node
  T_pg_insert       ≈ 10–40µs per node (batched INSERT ... ON CONFLICT,
                                          inside one transaction)

Total (seed dataset): roughly 15–70ms, dominated by N_nodes × T_pg_insert.
```

Measure it yourself: `GET /api/bench/rebuild`. This cost is paid once at
startup (if the table is empty) and can be re-run on a schedule as a
safety net; it is never paid on a per-request basis.

### B. Incremental update — `UpdateKeyword(epoch, oldText, newText)`

Adding, renaming, or deleting one keyword does **not** trigger a full
rebuild. It touches only the union of the old and new keyword's prefixes:

```
T_incremental = Σ_{p ∈ touched_prefixes} ( T_aggregate_query(p) + T_aes + T_pg_upsert )

  touched_prefixes  = prefixes(oldText) ∪ prefixes(newText)
                       ≈ len(oldText) + len(newText), typically 10–20 total
  T_aggregate_query ≈ 0.3–1ms   per touched prefix (re-scans source tables
                                  for that exact prefix, inside the same
                                  transaction as the write)
  T_aes             ≈ 1–2µs     per touched prefix
  T_pg_upsert       ≈ 20–60µs   per touched prefix

Total for a typical single-keyword rename: roughly 3–15ms end-to-end,
entirely off the read path (triggered async via the outbox — see
ARCHITECTURE.md §5), independent of total trie size.
```

Measure it yourself: `GET /api/bench/incremental` — it inserts, updates,
then deletes one synthetic keyword in a dedicated `bench_keywords` table
(never touching real seed data) and reports the write cost and the
resulting trie-update cost for each step separately.

This same code path (`UpdateKeyword`) is what runs when you add real data
through the UI's "➕ Add Data" tab / `POST /api/data/{kind}` — the only
difference is the write goes to `companies`/`products`/`trends`/
`innovations` instead of the synthetic `bench_keywords` table, and the
response reports the identical `pg_write_ms` / `trie_update_us` /
`prefixes_touched` fields for that real write. See ARCHITECTURE.md §6.5.

### C. Key rotation — `RotateReencrypt(oldEpoch, newEpoch)`

```
T_rotate = T_stream_read(N_nodes) + Σ(T_aes_decrypt + T_aes_encrypt + T_pg_upsert)

  T_stream_read    ≈ streamed via a Postgres cursor in batches of 500 rows —
                      bounded memory regardless of N_nodes
  T_aes_decrypt    ≈ 1–2µs per node (old key)
  T_aes_encrypt    ≈ 1–2µs per node (new key)
  T_pg_upsert      ≈ 10–40µs per node, batched (500/transaction)

Total (seed dataset, ~1,000 nodes): roughly 20–60ms — same order of
magnitude as a full rebuild, but crucially it NEVER re-reads the plaintext
source tables, so it stays cheap even as companies/products/etc. grow to
sizes where a full rebuild would not.
```

Measure it yourself: `GET /api/bench/rotate?grace_seconds=10` — performs a
real rotation (new epoch, full re-encryption, old epoch demoted to a
10-second grace window) and reports the timing.

---

## Summary

```
Plain Postgres:    [HTTP] → [pool] → [loopback×2] → [4-table ILIKE scan] → [deser] → [JSON]
                     5µs      30µs       150µs             300µs             8µs        5µs
                   ≈ 380–770µs  (both a lower and upper bound, matches original demo's numbers)

Encrypted trie:    [HTTP] → [pool] → [loopback×2] → [PK point lookup] → [AES-GCM] → [JSON]
                     4µs      30µs       150µs             30µs              2µs        2µs
                   ≈ 180–420µs  (SAME pool + network cost as plain; only the query plan differs)

Modeled speedup at p50: roughly 2–4× — not 200–460×.

Root cause of the (smaller, honest) gap: Postgres query PLAN complexity —
a single-table B-tree point lookup vs. a four-table pattern-match scan —
not "database vs. no database." Connection pooling and network round-trip
costs, which dominated the original comparison's "savings," are now paid
identically by both sides, because both sides now do the same kind of
work: a real query against a real database.

Costs this document now accounts for, that the original never mentioned:
  - Full rebuild:      ~15–70ms,  paid once at startup / on a schedule
  - Incremental update: ~3–15ms,  paid once per data change, off the read path
  - Key rotation:       ~20–60ms, paid once per rotation (a scheduled
                                    security operation)

None of these are "free." All of them are now implemented, measurable via
`/api/bench/rebuild`, `/api/bench/incremental`, and `/api/bench/rotate`,
and documented in full in ARCHITECTURE.md.
```
