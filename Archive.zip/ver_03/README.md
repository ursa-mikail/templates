# SearchPulse-Enc

Live Postgres autocomplete vs. a production-shaped searchable-encrypted
trie, side by side, with an honest latency benchmark suite.

**Start here → [`SEARCHABLE_ENCRYPTION.md`](./SEARCHABLE_ENCRYPTION.md)** —
a self-contained guide to how the encrypted side actually works: setup,
the two encrypted data structures, the full search → retrieval pipeline
(typing a prefix, selecting a result, and what happens after — this is
also where the "selecting a result did nothing" bug and its fix are
explained), key rotation end to end, and exactly what happens when you add
or delete data (trie refresh, both the automatic and guided-UI paths).

**For deeper architecture (Postgres count, threat model, bug-fix log) →
[`ARCHITECTURE.md`](./ARCHITECTURE.md)**.

**For the latency numbers specifically → [`LATENCY_CALCULUS.md`](./LATENCY_CALCULUS.md)**
— a component-by-component breakdown of both query paths (both hit
Postgres, on every request — there is no in-memory cache anywhere), plus
full cost models for rebuild, incremental update, and key rotation. This
replaces the original `latency_calculus_in_mem_demo.md`, which measured a
trie that lived in RAM and never touched a database.

This build was verified by actually running it — a real Postgres
instance, the compiled binary, and real HTTP requests, not just reading
the code. Bugs found and fixed this way: a frontend/backend HMAC label
mismatch that made encrypted autocomplete return nothing; a concurrency
deadlock in the incremental-update path; and a missing retrieval step
where selecting an encrypted suggestion (or pressing Enter) never actually
fetched the full record. See `ARCHITECTURE.md` §8 for exactly what broke
and how each fix was confirmed.

## Run it

```bash
./up.sh
```

This builds and starts three containers — Postgres, the Go backend, and
the React frontend — and waits for the backend health check to pass.

- UI: http://localhost:3000
- API: http://localhost:8080/api/health

```bash
./down.sh    # stop
./clean.sh   # stop + remove volumes/images + free ports 3000/8080/5432
```

## Configuration

Set these before `./up.sh` in real (non-local-dev) use:

| Variable | Purpose | Local-dev default |
|---|---|---|
| `MASTER_KEK_HEX` | 64-hex-char (32-byte) key that wraps every trie root key at rest. In production this comes from a KMS/HSM, not an env var in a compose file. | An insecure fixed value — the server logs a warning if you leave this unset. |
| `API_KEYS` | Comma-separated shared secrets required (via `X-API-Key` header) to call `/api/enc-key`, `/api/admin/*`, and `/api/data/*` (create/delete). | Empty — those endpoints stay open, with a warning header, so the demo works out of the box. |

## What's in the UI

- **⚡ Plain Search** — every keystroke hits Postgres live (`ILIKE` +
  trigram/FTS indexes).
- **🔐 Encrypted Search** — every keystroke derives a trapdoor + key
  client-side (Web Crypto), and the backend answers with an indexed
  Postgres point lookup (`enctrie_nodes`, primary key `(epoch, trapdoor)`)
  followed by an AES-256-GCM decrypt. Selecting a suggestion (or pressing
  Enter) triggers a SEPARATE encrypted retrieval — a different trapdoor/key
  namespace, a different table (`enctrie_records`) — that decrypts the
  full record and renders it as a Card, exactly like the plain path. **No
  in-memory cache anywhere** — every request is a real query against the
  same Postgres instance as the plain path. See `SEARCHABLE_ENCRYPTION.md`
  §4 for the full pipeline.
- **➕ Add Data** — a guided form (rendered directly from
  `GET /api/data/schema`, so the fields aren't hand-duplicated) for adding
  a real company, product, trend, or research item to the actual source
  tables — not a synthetic benchmark row. Shows the exact Postgres write
  time and encrypted-trie update time for your submission, then live-
  verifies the new item is immediately searchable in both the plain and
  encrypted tabs. See `ARCHITECTURE.md` §6.5.
- **📊 Latency Benchmark** — the per-keystroke plain-vs-encrypted
  comparison, *plus* a "Lifecycle benchmarks" panel that runs and times a
  full rebuild, an incremental keyword update, and a real key rotation —
  the costs the per-keystroke comparison deliberately excludes. See
  `ARCHITECTURE.md` §6 for why these are kept separate.

## API surface

| Endpoint | Auth | What it does |
|---|---|---|
| `GET /api/search`, `GET /api/suggest` | none | Live Postgres search/autocomplete |
| `GET /api/enc-suggest` | none | Encrypted-trie autocomplete (client sends `td`, `nk`, optional `epoch`) |
| `GET /api/enc-record` | none | Encrypted full-record retrieval, exact match only (client sends `td`, `rk`, optional `epoch`) — see `SEARCHABLE_ENCRYPTION.md` §4 |
| `GET /api/enc-key` | `X-API-Key` | Issues current epoch's root key material to the browser |
| `GET /api/data/schema` | none | Field descriptions for the guided data-entry form |
| `GET /api/data/recent` | none | Last 25 items added, across all four content types |
| `POST /api/data/{kind}` | `X-API-Key` | Add a company/product/trend/innovation (`kind` = one of those four) |
| `DELETE /api/data/{kind}/{id}` | `X-API-Key` | Remove an item you added |
| `GET /api/bench`, `/api/bench/rebuild`, `/api/bench/incremental`, `/api/bench/rotate` | none | Latency benchmarks (see `ARCHITECTURE.md` §6) |
| `POST /api/admin/rebuild`, `POST /api/admin/rotate` | `X-API-Key` | Manually trigger a full rebuild / key rotation |
| `GET /api/health` | none | Postgres connectivity + current key epoch + node counts |
