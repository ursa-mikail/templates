export type ResultKind = 'company' | 'product' | 'innovation' | 'trend';

export interface MetaItem { label: string; value: string; }

export interface SearchResult {
  id: number; kind: ResultKind; title: string; subtitle: string;
  description: string; badge?: string; meta: MetaItem[];
  score: number; tags?: string[];
}

export interface Suggestion { text: string; kind: ResultKind; subtitle: string; }

export interface SearchResponse {
  query: string; results: SearchResult[];
  total_count: number; elapsed_ms: number;
}

export interface EncSuggestion { text: string; kind: string; subtitle: string; }

export interface EncSuggestResponse {
  suggestions: EncSuggestion[];
  found: boolean;
  elapsed_us: number;
  node_encrypted?: boolean;
  cipher?: string;
}

export interface EncRecordResponse {
  results: SearchResult[];
  found: boolean;
  elapsed_us: number;
  record_encrypted?: boolean;
  cipher?: string;
}

export interface EncKeyResponse {
  root_key_hex: string;
  epoch: number;
  node_count: number;
  algorithm: string;
  expires_hint: string;
}

export interface RebuildResponse {
  category: string;
  epoch: number;
  node_count: number;
  elapsed_ms: number;
}

export interface IncrementalStep {
  step: 'insert' | 'update' | 'delete';
  pg_write_ms: number;
  trie_update_us: number;
  prefixes_touched: number;
  total_direct_ms: number;
}

export interface IncrementalResponse {
  category: string;
  note: string;
  steps: IncrementalStep[];
}

export interface RotateResponse {
  category: string;
  new_epoch: number;
  old_epoch: number;
  nodes_reencrypted: number;
  elapsed_ms: number;
  old_epoch_readable_until_seconds: number;
  note: string;
}

export interface BenchStats {
  mode: string; queries: number; samples: number[];
  p50: number; p90: number; p95: number; p99: number;
  min: number; max: number; mean: number; std_dev: number;
}

export interface BenchResponse {
  category: string;
  n: number;
  plain: BenchStats;
  encrypted: BenchStats;
  caveat: string;
}

// ── Guided data entry ────────────────────────────────────────────────────

export interface FieldSpec {
  name: string;
  label: string;
  type: 'text' | 'textarea' | 'number' | 'checkbox' | 'tags' | 'select';
  required: boolean;
  placeholder?: string;
  help?: string;
  options?: string[];
}

export interface KindSpec {
  kind: string;
  label: string;
  table: string;
  title_field: string;
  fields: FieldSpec[];
  explanation: string;
}

export interface DataSchemaResponse {
  kinds: KindSpec[];
  how_it_works: string[];
}

export interface DataCreateResult {
  id: number;
  kind: string;
  indexed_text: string;
  pg_write_ms: number;
  trie_update_us: number;
  prefixes_touched: number;
  try_prefix: string;
}

export interface RecentItem {
  kind: string;
  id: number;
  text: string;
  created_at: string;
}
