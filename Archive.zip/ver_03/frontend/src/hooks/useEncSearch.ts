import { useState, useRef, useCallback, useEffect } from 'react';
import { EncSuggestion, EncSuggestResponse, EncRecordResponse, SearchResult } from '../types';

const API = '/api';

// Client-side HMAC-SHA256 using Web Crypto API.
// keyBytes.buffer cast to ArrayBuffer satisfies strict TS lib types.
// Exported so any other component that needs to derive a trapdoor/nodeKey
// (e.g. the guided data-entry tab, to verify a new item is searchable)
// reuses this single implementation instead of risking a second copy that
// silently drifts out of sync with the backend's label format — that drift
// is exactly what caused encrypted search to stop finding anything before.
export async function hmacSHA256(keyBytes: Uint8Array, message: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    'raw',
    keyBytes.buffer as ArrayBuffer,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const msgBytes = new TextEncoder().encode(message);
  const sig = await crypto.subtle.sign('HMAC', key, msgBytes.buffer as ArrayBuffer);
  return Array.from(new Uint8Array(sig))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}

export function hexToBytes(hex: string): Uint8Array {
  const arr = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2)
    arr[i / 2] = parseInt(hex.slice(i, i + 2), 16);
  return arr;
}

export function useEncSearch() {
  const [rootKey,   setRootKey]  = useState<string | null>(null);
  const [epoch,     setEpoch]    = useState<number | null>(null);
  const [nodeCount, setNodeCount] = useState<number>(0);
  const [query,     setQ]        = useState('');
  const [sugs,      setSugs]     = useState<EncSuggestion[]>([]);
  const [open,      setOpen]     = useState(false);
  const [loading,   setLoading]  = useState(false);
  const [keyReady,  setKeyReady] = useState(false);
  const [lastUs,    setLastUs]   = useState<number | null>(null);
  const [lastTd,    setLastTd]   = useState<string | null>(null);
  const [error,     setError]    = useState<string | null>(null);

  // Retrieval (exact-match, full record) — separate from the prefix
  // suggestion flow above. See EncRecord on the backend.
  const [records,       setRecords]       = useState<SearchResult[] | null>(null);
  const [recordLoading, setRecordLoading] = useState(false);
  const [lastRecordUs,  setLastRecordUs]  = useState<number | null>(null);
  const [recordMiss,    setRecordMiss]    = useState<string | null>(null); // text that had no record

  const timer  = useRef<ReturnType<typeof setTimeout>>();
  const sugCtl = useRef<AbortController>();

  // Fetch root key from server on mount (demo only — prod: key never leaves client)
  useEffect(() => {
    fetch(`${API}/enc-key`)
      .then(r => r.json())
      .then(d => {
        setRootKey(d.root_key_hex);
        setEpoch(d.epoch);
        setNodeCount(d.node_count);
        setKeyReady(true);
      })
      .catch((e: Error) => setError(`key fetch: ${e.message}`));
  }, []);

  // Re-fetch the key material if the epoch changes underneath us (e.g. an
  // admin rotated keys while this tab was open). A production client would
  // do this on a 401/"epoch retired" response instead of polling; kept
  // simple here since /api/enc-key is unauthenticated in local dev.
  const refreshKey = useCallback(() => {
    fetch(`${API}/enc-key`)
      .then(r => r.json())
      .then(d => { setRootKey(d.root_key_hex); setEpoch(d.epoch); setNodeCount(d.node_count); })
      .catch(() => {});
  }, []);

  const setQuery = useCallback((q: string) => {
    setQ(q);
    clearTimeout(timer.current);
    sugCtl.current?.abort();

    if (!q.trim() || !rootKey || epoch === null) { setSugs([]); setOpen(false); return; }

    setLoading(true);
    timer.current = setTimeout(async () => {
      if (!rootKey) return;
      try {
        const rootBytes = hexToBytes(rootKey);
        const prefix = q.toLowerCase();

        if (epoch === null) { setLoading(false); return; }

        // Client derives both tokens locally — root key never retransmitted.
        // MUST exactly match the backend's keys.DeriveTrapdoor /
        // keys.DeriveNodeKey label format: "td:e<epoch>:<prefix>" and
        // "node:e<epoch>:<prefix>". Epoch is mixed in so a trapdoor from
        // one key-rotation generation can never collide with another.
        const [td, nk] = await Promise.all([
          hmacSHA256(rootBytes, `td:e${epoch}:${prefix}`),
          hmacSHA256(rootBytes, `node:e${epoch}:${prefix}`),
        ]);
        setLastTd(td.slice(0, 16) + '…');

        const ctl = new AbortController();
        sugCtl.current = ctl;

        const epochParam = epoch !== null ? `&epoch=${epoch}` : '';
        const res = await fetch(
          `${API}/enc-suggest?td=${encodeURIComponent(td)}&nk=${encodeURIComponent(nk)}${epochParam}`,
          { signal: ctl.signal }
        );
        const data: EncSuggestResponse = await res.json();
        const list = data.suggestions ?? [];
        setSugs(list);
        setOpen(list.length > 0);
        setLastUs(data.elapsed_us);
      } catch {
        // AbortError — next keystroke superseded this one
      } finally {
        setLoading(false);
      }
    }, 120);
  }, [rootKey, epoch]);

  // Retrieve the FULL record for an exact keyword — a separate encrypted
  // lookup from the prefix-suggestion one above (see EncRecord's doc
  // comment on the backend for why this is a distinct trapdoor/key
  // namespace). This is what "select a suggestion" / "press Enter" was
  // missing entirely: without calling this, choosing a suggestion just
  // filled the search box and stopped — nothing was ever retrieved.
  const retrieveRecord = useCallback(async (exactText: string) => {
    if (!rootKey || epoch === null) return;
    setRecordLoading(true);
    setRecordMiss(null);
    try {
      const rootBytes = hexToBytes(rootKey);
      const lower = exactText.toLowerCase();
      // MUST exactly match the backend's keys.DeriveRecordTrapdoor /
      // keys.DeriveRecordKey label format: "rtd:e<epoch>:<text>" and
      // "rkey:e<epoch>:<text>" — a DIFFERENT namespace from the "td:"/
      // "node:" labels the prefix suggestions above use, on purpose.
      const [rtd, rk] = await Promise.all([
        hmacSHA256(rootBytes, `rtd:e${epoch}:${lower}`),
        hmacSHA256(rootBytes, `rkey:e${epoch}:${lower}`),
      ]);
      const res = await fetch(`${API}/enc-record?td=${encodeURIComponent(rtd)}&rk=${encodeURIComponent(rk)}&epoch=${epoch}`);
      const data: EncRecordResponse = await res.json();
      setLastRecordUs(data.elapsed_us);
      if (data.found && data.results.length > 0) {
        setRecords(data.results);
      } else {
        setRecords(null);
        setRecordMiss(exactText);
      }
    } catch (e: unknown) {
      setRecords(null);
      setError(e instanceof Error ? `record fetch: ${e.message}` : 'record fetch failed');
    } finally {
      setRecordLoading(false);
    }
  }, [rootKey, epoch]);

  const selectSuggestion = useCallback((text: string) => {
    clearTimeout(timer.current);
    sugCtl.current?.abort();
    setQ(text);
    setSugs([]);
    setOpen(false);
    retrieveRecord(text);
  }, [retrieveRecord]);

  return {
    rootKey, epoch, nodeCount, keyReady, refreshKey,
    query, setQuery,
    sugs, open, loading,
    lastUs, lastTd, error,
    records, recordLoading, lastRecordUs, recordMiss,
    retrieveRecord,
    closeDropdown: () => setOpen(false),
    selectSuggestion,
  };
}
