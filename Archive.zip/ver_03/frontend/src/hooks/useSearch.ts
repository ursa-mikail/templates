import { useState, useRef, useCallback } from 'react';
import { SearchResponse, Suggestion } from '../types';

const API = '/api';

export function useSearch() {
  const [query,      setQ]       = useState('');
  const [sugs,       setSugs]    = useState<Suggestion[]>([]);
  const [open,       setOpen]    = useState(false);
  const [sugLoading, setSugLoad] = useState(false);
  const [results,    setResults] = useState<SearchResponse | null>(null);
  const [loading,    setLoading] = useState(false);
  const [error,      setError]   = useState<string | null>(null);
  const [lastSugMs,  setLastSugMs] = useState<number | null>(null);

  const timer   = useRef<ReturnType<typeof setTimeout>>();
  const sugCtl  = useRef<AbortController>();
  const srchCtl = useRef<AbortController>();

  const setQuery = useCallback((q: string) => {
    setQ(q);
    clearTimeout(timer.current);
    sugCtl.current?.abort();
    setSugLoad(false);
    if (!q.trim()) { setSugs([]); setOpen(false); setResults(null); return; }
    setSugLoad(true);
    timer.current = setTimeout(async () => {
      const ctl = new AbortController();
      sugCtl.current = ctl;
      const t0 = performance.now();
      try {
        const res  = await fetch(`${API}/suggest?q=${encodeURIComponent(q)}`, { signal: ctl.signal });
        const data = await res.json();
        const list: Suggestion[] = Array.isArray(data) ? data : [];
        setSugs(list);
        setOpen(list.length > 0);
        setLastSugMs(parseFloat((performance.now() - t0).toFixed(1)));
      } catch { /* AbortError */ } finally { setSugLoad(false); }
    }, 120);
  }, []);

  const runSearch = useCallback(async (q: string) => {
    const t = q.trim(); if (!t) return;
    srchCtl.current?.abort();
    const ctl = new AbortController(); srchCtl.current = ctl;
    setSugs([]); setOpen(false); setLoading(true); setError(null);
    try {
      const res  = await fetch(`${API}/search?q=${encodeURIComponent(t)}`, { signal: ctl.signal });
      const body = await res.json();
      if (!res.ok) throw new Error(body.error ?? `HTTP ${res.status}`);
      setResults(body);
    } catch (e: unknown) {
      if (e instanceof Error && e.name !== 'AbortError') setError(e.message);
    } finally { setLoading(false); }
  }, []);

  const selectSuggestion = useCallback((text: string) => {
    clearTimeout(timer.current); sugCtl.current?.abort(); setSugLoad(false);
    setQ(text); setSugs([]); setOpen(false); runSearch(text);
  }, [runSearch]);

  return {
    query, setQuery, sugs, open, sugLoading, lastSugMs,
    closeDropdown: () => setOpen(false),
    results, loading, error,
    submitSearch: () => runSearch(query),
    selectSuggestion,
  };
}
