import { useRef, useEffect, KeyboardEvent, useState, useCallback } from 'react';
import { useSearch } from './hooks/useSearch';
import { useEncSearch, hmacSHA256, hexToBytes } from './hooks/useEncSearch';
import { ResultKind, SearchResult, Suggestion, BenchResponse, BenchStats, RebuildResponse, IncrementalResponse, RotateResponse, DataSchemaResponse, KindSpec, DataCreateResult, RecentItem, EncSuggestion } from './types';
import './index.css';

const API = '/api';

const KIND: Record<ResultKind, { label: string; color: string; icon: string }> = {
  company:    { label: 'Company',  color: '#00d9ff', icon: '◈' },
  product:    { label: 'Product',  color: '#a78bfa', icon: '⬡' },
  innovation: { label: 'Research', color: '#34d399', icon: '◎' },
  trend:      { label: 'Trend',    color: '#fb923c', icon: '◆' },
};

const HINTS = ['transformer','NVIDIA','AlphaFold','RAG','Rust','diffusion','Claude','CUDA'];
const PHS = [
  'Type anything — live from Postgres...',
  'Try "attention" or "NVIDIA"...',
  'Try "AlphaFold" or "RAG"...',
  'Try "diffusion" or "LoRA"...',
];

// ─── Shared tiny components ───────────────────────────────────────────────────

function usePlaceholder() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI(n => (n + 1) % PHS.length), 3000);
    return () => clearInterval(t);
  }, []);
  return PHS[i];
}

function KindBadge({ kind }: { kind: string }) {
  const k = KIND[kind as ResultKind] ?? { label: kind, color: '#94a3b8', icon: '○' };
  return <span className="badge" style={{ '--c': k.color } as React.CSSProperties}>{k.icon} {k.label}</span>;
}

function SugRow({ s, active, onPick, onHover }: {
  s: Suggestion | { text: string; kind: string; subtitle: string };
  active: boolean; onPick: (t: string) => void; onHover: () => void;
}) {
  const k = KIND[s.kind as ResultKind] ?? { color: '#94a3b8', icon: '○', label: s.kind };
  return (
    <button className={`sug-row${active ? ' active' : ''}`}
      onMouseEnter={onHover}
      onMouseDown={e => { e.preventDefault(); onPick(s.text); }}>
      <span style={{ color: k.color, flexShrink: 0 }}>{k.icon}</span>
      <span className="sug-name">{s.text}</span>
      <span className="sug-sub">{s.subtitle}</span>
      <span className="sug-tag" style={{ color: k.color }}>{k.label}</span>
    </button>
  );
}

function Card({ r, onTag }: { r: SearchResult; onTag: (t: string) => void }) {
  const k = KIND[r.kind];
  const pct = Math.min(Math.round(r.score * 100), 100);
  return (
    <article className="card" style={{ '--c': k.color } as React.CSSProperties}>
      <div className="card-bar" />
      <div className="card-body">
        <div className="card-row"><KindBadge kind={r.kind} />{r.badge && <span className="card-pill">{r.badge}</span>}</div>
        <h3 className="card-title">{r.title}</h3>
        <p className="card-sub">{r.subtitle}</p>
        <p className="card-desc">{r.description}</p>
        {r.meta?.length > 0 && (
          <div className="meta-grid">{r.meta.map((m, i) => (
            <div key={i} className="meta-cell">
              <span className="meta-lbl">{m.label}</span>
              <span className="meta-val">{m.value}</span>
            </div>
          ))}</div>
        )}
        {r.tags && r.tags.length > 0 && (
          <div className="tag-row">{r.tags.slice(0,6).map(t => (
            <button key={t} className="tag" onClick={() => onTag(t)}>#{t}</button>
          ))}</div>
        )}
        <div className="score-row">
          <div className="score-track"><div className="score-fill" style={{ width: `${pct}%`, background: k.color }} /></div>
          <span className="score-num">{pct}%</span>
        </div>
      </div>
    </article>
  );
}

// ─── Latency meter ────────────────────────────────────────────────────────────

function LatencyMeter({ ms, label }: { ms: number | null; label: string }) {
  if (ms === null) return null;
  const color = ms < 10 ? '#34d399' : ms < 50 ? '#00d9ff' : ms < 200 ? '#fb923c' : '#f87171';
  const width = Math.min((ms / 500) * 100, 100);
  return (
    <div className="latency-meter">
      <span className="lat-label">{label}</span>
      <div className="lat-track">
        <div className="lat-fill" style={{ width: `${width}%`, background: color }} />
      </div>
      <span className="lat-val" style={{ color }}>{ms < 1 ? '<1' : ms.toFixed(0)} ms</span>
    </div>
  );
}

function MicroMeter({ us, label }: { us: number | null; label: string }) {
  if (us === null) return null;
  const ms = us / 1000;
  const color = us < 100 ? '#34d399' : us < 1000 ? '#00d9ff' : '#fb923c';
  return (
    <div className="latency-meter">
      <span className="lat-label">{label}</span>
      <div className="lat-track">
        <div className="lat-fill" style={{ width: `${Math.min(us / 50, 100)}%`, background: color }} />
      </div>
      <span className="lat-val" style={{ color }}>{us < 1000 ? `${us}µs` : `${ms.toFixed(2)}ms`}</span>
    </div>
  );
}

// ─── TAB 1: Plain Search ──────────────────────────────────────────────────────

function PlainSearchTab() {
  const {
    query, setQuery, sugs, open, sugLoading, lastSugMs,
    closeDropdown, results, loading, error,
    submitSearch, selectSuggestion,
  } = useSearch();

  const ph = usePlaceholder();
  const inputRef = useRef<HTMLInputElement>(null);
  const wrapRef  = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(-1);

  useEffect(() => setActive(-1), [sugs]);
  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) closeDropdown();
    };
    document.addEventListener('mousedown', fn);
    return () => document.removeEventListener('mousedown', fn);
  }, [closeDropdown]);

  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Escape') { closeDropdown(); return; }
    if (!open || sugs.length === 0) { if (e.key === 'Enter') submitSearch(); return; }
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(a => Math.min(a+1, sugs.length-1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(a-1,-1)); }
    else if (e.key === 'Enter') {
      e.preventDefault();
      if (active >= 0) selectSuggestion(sugs[active].text);
      else { closeDropdown(); submitSearch(); }
    }
  };

  const grouped = results?.results.reduce<Partial<Record<ResultKind, SearchResult[]>>>((acc,r)=>{
    (acc[r.kind as ResultKind]??=[]).push(r); return acc;
  },{});

  const dropVisible = open || sugLoading;

  return (
    <div className="tab-content">
      <div className="mode-banner plain-banner">
        <span className="mode-icon">⚡</span>
        <div>
          <div className="mode-title">Plain PostgreSQL Search</div>
          <div className="mode-desc">Direct ILIKE + tsvector · No encryption · Baseline performance</div>
        </div>
      </div>

      <div className="search-wrap" ref={wrapRef}>
        <div className={`search-box${dropVisible ? ' is-open' : ''}`}>
          <span className="search-ico">⌕</span>
          <input ref={inputRef} className="search-input" type="text"
            value={query} placeholder={ph}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={onKey} autoComplete="off" spellCheck={false} />
          {sugLoading && <span className="sug-spin" />}
          {loading    && <span className="spin" />}
          {query && <button className="clear" onMouseDown={e=>{e.preventDefault();setQuery('');inputRef.current?.focus();}}>✕</button>}
          <button className="go-btn" onClick={submitSearch} disabled={!query.trim()||loading}>Search</button>
        </div>

        {dropVisible && (
          <div className="dropdown" role="listbox">
            <div className="drop-hdr">
              <span className="drop-live">
                <span className={`live-dot${sugLoading?' fetching':''}`} />
                {sugLoading ? 'querying Postgres…' : `${sugs.length} suggestion${sugs.length!==1?'s':''}`}
              </span>
              <span className="drop-keys">↑↓ · Enter · Esc</span>
            </div>
            {sugs.map((s,i)=>(
              <SugRow key={`${s.kind}:${s.text}`} s={s} active={i===active}
                onPick={selectSuggestion} onHover={()=>setActive(i)} />
            ))}
            {!sugLoading && sugs.length===0 && <div className="drop-empty">No matches</div>}
          </div>
        )}
      </div>

      <LatencyMeter ms={lastSugMs} label="Suggest latency" />

      {results && (
        <div className="status">
          <span>{results.total_count} result{results.total_count!==1?'s':''} for <strong>"{results.query}"</strong></span>
          <span className="status-ms">{results.elapsed_ms}ms</span>
          {(Object.entries(KIND) as [ResultKind, typeof KIND[ResultKind]][]).map(([k,v])=>{
            const n=grouped?.[k]?.length??0; if(!n)return null;
            return <span key={k} style={{color:v.color}}>{v.icon} {n} {v.label}{n!==1?'s':''}</span>;
          })}
        </div>
      )}
      {error && <div className="err-bar">⚠ {error}</div>}

      <section>
        {!results && !loading && (
          <div className="empty">
            <div className="orb" />
            <h2>Explore the Tech Universe</h2>
            <p>Every keystroke fires a live Postgres query. No cache, no pre-loading.</p>
            <div className="hints">{HINTS.map(h=>(
              <button key={h} className="hint" onClick={()=>selectSuggestion(h)}>{h}</button>
            ))}</div>
            <div className="legend">{(Object.entries(KIND) as [ResultKind, typeof KIND[ResultKind]][]).map(([k,v])=>(
              <div key={k} className="leg-item"><span style={{color:v.color}}>{v.icon}</span> {v.label}</div>
            ))}</div>
          </div>
        )}
        {results?.total_count===0 && <div className="no-res"><span className="no-res-sym">∅</span><p>No results for <strong>"{results.query}"</strong></p></div>}
        {results && results.total_count>0 && (
          <div className="grid">{results.results.map(r=>(
            <Card key={`${r.kind}:${r.id}`} r={r} onTag={selectSuggestion} />
          ))}</div>
        )}
      </section>
    </div>
  );
}

// ─── TAB 2: Encrypted Search ──────────────────────────────────────────────────

function EncryptedSearchTab() {
  const {
    rootKey, epoch, nodeCount, keyReady,
    query, setQuery, sugs, open, loading,
    lastUs, lastTd, error,
    records, recordLoading, lastRecordUs, recordMiss,
    retrieveRecord,
    closeDropdown, selectSuggestion,
  } = useEncSearch();

  const inputRef = useRef<HTMLInputElement>(null);
  const wrapRef  = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(-1);

  useEffect(() => setActive(-1), [sugs]);
  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target as Node)) closeDropdown();
    };
    document.addEventListener('mousedown', fn);
    return () => document.removeEventListener('mousedown', fn);
  }, [closeDropdown]);

  // Encrypted search can only ever RETRIEVE an exact keyword that's
  // actually indexed (the trapdoor is deterministic — there's no fuzzy
  // matching without the plaintext to compare against). So Enter here
  // means: pick the highlighted suggestion if there is one; otherwise, if
  // what's typed exactly matches one of the currently-shown suggestions
  // (case-insensitive), retrieve that one; otherwise attempt the typed
  // text directly and let the UI honestly report "no exact match" rather
  // than silently doing nothing, which was the bug.
  const onKey = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Escape') { closeDropdown(); return; }
    if (!open || sugs.length === 0) {
      if (e.key === 'Enter' && query.trim()) { e.preventDefault(); retrieveRecord(query.trim()); }
      return;
    }
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(a => Math.min(a+1, sugs.length-1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(a-1,-1)); }
    else if (e.key === 'Enter') {
      e.preventDefault();
      if (active >= 0) {
        selectSuggestion(sugs[active].text);
        return;
      }
      const exact = sugs.find(s => s.text.toLowerCase() === query.trim().toLowerCase());
      if (exact) { selectSuggestion(exact.text); return; }
      closeDropdown();
      retrieveRecord(query.trim());
    }
  };

  const dropVisible = open || loading;

  return (
    <div className="tab-content">
      <div className="mode-banner enc-banner">
        <span className="mode-icon">🔐</span>
        <div>
          <div className="mode-title">Searchable Encryption — HMAC-SHA256 Trie</div>
          <div className="mode-desc">AES-256-GCM payload · Client derives trapdoor · Server sees only ciphertext</div>
        </div>
      </div>

      {/* Security info panel */}
      <div className="sec-panel">
        <div className="sec-grid">
          <div className="sec-cell">
            <span className="sec-lbl">Algorithm</span>
            <span className="sec-val">HMAC-SHA256 trapdoor · AES-256-GCM</span>
          </div>
          <div className="sec-cell">
            <span className="sec-lbl">Trie nodes</span>
            <span className="sec-val enc-green">{nodeCount.toLocaleString()} encrypted</span>
          </div>
          <div className="sec-cell">
            <span className="sec-lbl">Root key</span>
            <span className="sec-val monospace">{rootKey ? rootKey.slice(0,16)+'…' : 'loading…'}</span>
          </div>
          <div className="sec-cell">
            <span className="sec-lbl">Key epoch</span>
            <span className="sec-val">{epoch ?? '—'} <span className="sec-hint">(rotate in the Latency Benchmark tab)</span></span>
          </div>
          <div className="sec-cell">
            <span className="sec-lbl">Key status</span>
            <span className={`sec-val ${keyReady ? 'enc-green' : 'enc-orange'}`}>
              {keyReady ? '✓ client holds key' : '⟳ fetching…'}
            </span>
          </div>
          {lastTd && (
            <div className="sec-cell sec-full">
              <span className="sec-lbl">Last trapdoor sent</span>
              <span className="sec-val monospace">{lastTd}</span>
            </div>
          )}
        </div>
        <div className="sec-note">
          🔒 Server receives only the HMAC trapdoor for lookup and the derived node key for decryption.
          It cannot traverse sibling nodes or derive any key without the client's root key.
        </div>
      </div>

      <div className="search-wrap" ref={wrapRef}>
        <div className={`search-box enc-box${dropVisible ? ' is-open' : ''}`}>
          <span className="search-ico enc-ico">🔑</span>
          <input ref={inputRef} className="search-input" type="text"
            value={query} placeholder="Search with encryption — type a prefix, Enter to retrieve…"
            onChange={e => setQuery(e.target.value)}
            onKeyDown={onKey} autoComplete="off" spellCheck={false}
            disabled={!keyReady} />
          {(loading || recordLoading) && <span className="sug-spin enc-spin" />}
          {query && <button className="clear" onMouseDown={e=>{e.preventDefault();setQuery('');inputRef.current?.focus();}}>✕</button>}
        </div>

        {dropVisible && (
          <div className="dropdown enc-dropdown" role="listbox">
            <div className="drop-hdr">
              <span className="drop-live">
                <span className={`live-dot enc-dot${loading?' fetching':''}`} />
                {loading ? 'decrypting trie node…' : `${sugs.length} decrypted suggestion${sugs.length!==1?'s':''}`}
              </span>
              {lastUs !== null && (
                <span className="enc-time">{lastUs < 1000 ? `${lastUs}µs` : `${(lastUs/1000).toFixed(2)}ms`} · AES-GCM</span>
              )}
            </div>
            {sugs.map((s,i)=>(
              <SugRow key={`${s.kind}:${s.text}`} s={s} active={i===active}
                onPick={selectSuggestion} onHover={()=>setActive(i)} />
            ))}
            {!loading && sugs.length===0 && <div className="drop-empty">No encrypted node for this prefix</div>}
            {!loading && sugs.length>0 && (
              <div className="drop-footer">↑↓ to pick · Enter to retrieve the full record</div>
            )}
          </div>
        )}
      </div>

      <MicroMeter us={lastUs} label="Trie decrypt latency" />

      {error && <div className="err-bar">⚠ {error}</div>}

      {(records || recordLoading || recordMiss) && (
        <div className="status">
          {recordLoading && <span>⟳ retrieving encrypted record…</span>}
          {!recordLoading && records && (
            <>
              <span>{records.length} record{records.length!==1?'s':''} decrypted for <strong>exact match</strong></span>
              {lastRecordUs !== null && (
                <span className="status-ms">{lastRecordUs < 1000 ? `${lastRecordUs}µs` : `${(lastRecordUs/1000).toFixed(2)}ms`}</span>
              )}
            </>
          )}
          {!recordLoading && recordMiss && !records && (
            <span>
              No encrypted record for the exact text <strong>"{recordMiss}"</strong> — encrypted retrieval only
              works for a keyword that is actually indexed (pick a suggestion from the dropdown, or type the
              exact name).
            </span>
          )}
        </div>
      )}

      <section>
        {!records && !recordLoading && !recordMiss && (
          <div className="empty">
            <div className="orb" />
            <h2>Encrypted, Exact-Match Retrieval</h2>
            <p>
              Autocomplete narrows down what exists via prefix trapdoors. Selecting a suggestion (or typing the
              exact name and hitting Enter) fires a SEPARATE encrypted lookup — same server, zero plaintext queries
              either way — that decrypts the full record.
            </p>
          </div>
        )}
        {records && records.length > 0 && (
          <div className="grid">{records.map(r=>(
            <Card key={`${r.kind}:${r.id}`} r={r} onTag={(t)=>{ setQuery(t); retrieveRecord(t); }} />
          ))}</div>
        )}
      </section>

      <div className="enc-explainer">
        <h3>How it works — autocomplete (per keystroke)</h3>
        <div className="steps">
          {[
            ['1', 'Client types prefix (e.g. "att")', '#00d9ff'],
            [
              '2',
              epoch !== null
                ? `Web Crypto: trapdoor = HMAC(rootKey, "td:e${epoch}:att") — never leaves client`
                : 'Web Crypto: trapdoor = HMAC(rootKey, "td:e<epoch>:att") — never leaves client',
              '#a78bfa',
            ],
            [
              '3',
              epoch !== null
                ? `Web Crypto: nodeKey = HMAC(rootKey, "node:e${epoch}:att") — decryption key`
                : 'Web Crypto: nodeKey = HMAC(rootKey, "node:e<epoch>:att") — decryption key',
              '#a78bfa',
            ],
            ['4', 'GET /api/enc-suggest?td=<trapdoor>&nk=<nodeKey>&epoch=<epoch>', '#34d399'],
            ['5', 'Server: indexed Postgres SELECT on enctrie_nodes by (epoch, trapdoor)', '#fb923c'],
            ['6', 'Server: AES-256-GCM decrypt payload using nodeKey', '#fb923c'],
            ['7', 'Server returns lightweight suggestions (text/kind/subtitle) — only for this node', '#34d399'],
            ['8', 'Server cannot see siblings ("atu", "atb") without their trapdoors', '#f87171'],
          ].map(([n, txt, c]) => (
            <div key={n} className="step">
              <span className="step-num" style={{ color: c as string }}>{n}</span>
              <span className="step-txt">{txt}</span>
            </div>
          ))}
        </div>

        <h3 className="enc-explainer-sub">How it works — retrieval (on Enter / select)</h3>
        <div className="steps">
          {[
            ['9', 'Client has the exact text now (from a suggestion, or typed in full)', '#00d9ff'],
            ['10', 'Web Crypto: recordTrapdoor/recordKey use DIFFERENT labels ("rtd:"/"rkey:") from suggestions', '#a78bfa'],
            ['11', 'GET /api/enc-record?td=<recordTrapdoor>&rk=<recordKey>&epoch=<epoch>', '#34d399'],
            ['12', 'Server: indexed Postgres SELECT on enctrie_records — a SEPARATE table from suggestions', '#fb923c'],
            ['13', 'Server: AES-256-GCM decrypt the full record (description, metadata, tags)', '#fb923c'],
            ['14', 'Client renders it as a Card — same shape as the plain path, fully decrypted', '#34d399'],
          ].map(([n, txt, c]) => (
            <div key={n} className="step">
              <span className="step-num" style={{ color: c as string }}>{n}</span>
              <span className="step-txt">{txt}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── TAB 3: Latency Benchmark ─────────────────────────────────────────────────

function BenchTab() {
  const [result,  setResult]  = useState<BenchResponse | null>(null);
  const [running, setRunning] = useState(false);
  const [n,       setN]       = useState(100);
  const [error,   setError]   = useState<string | null>(null);
  const [progress,setProgress]= useState(0);

  const runBench = useCallback(async () => {
    setRunning(true); setResult(null); setError(null); setProgress(0);
    const interval = setInterval(() => setProgress(p => Math.min(p + 3, 90)), 150);
    try {
      const res  = await fetch(`/api/bench?n=${n}`);
      const data = await res.json();
      setResult(data);
      setProgress(100);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'bench failed');
    } finally {
      clearInterval(interval);
      setRunning(false);
    }
  }, [n]);

  return (
    <div className="tab-content">
      <div className="mode-banner bench-banner">
        <span className="mode-icon">📊</span>
        <div>
          <div className="mode-title">Latency Benchmark Suite</div>
          <div className="mode-desc">Plain Postgres vs Encrypted Trie · p50 / p90 / p95 / p99</div>
        </div>
      </div>

      <div className="bench-controls">
        <label className="bench-label">
          Queries per run:
          <select className="bench-select" value={n} onChange={e => setN(+e.target.value)} disabled={running}>
            {[50, 100, 200, 500].map(v => <option key={v} value={v}>{v}</option>)}
          </select>
        </label>
        <button className="bench-btn" onClick={runBench} disabled={running}>
          {running ? '⟳ Running…' : '▶ Run Benchmark'}
        </button>
      </div>

      {running && (
        <div className="bench-progress-wrap">
          <div className="bench-progress-track">
            <div className="bench-progress-fill" style={{ width: `${progress}%` }} />
          </div>
          <span className="bench-progress-txt">{progress}%</span>
        </div>
      )}

      {error && <div className="err-bar">⚠ {error}</div>}

      {result && <BenchResults result={result} />}

      <div className="bench-explainer">
        <h3>What is being measured</h3>
        <p><strong>Plain:</strong> Go → PostgreSQL <code>ILIKE</code> scan across 4 tables (GIN-trigram-accelerated) → result fetch</p>
        <p><strong>Encrypted:</strong> Go → PostgreSQL exact-match point lookup on <code>enctrie_nodes</code>'s primary key <code>(epoch, trapdoor)</code> → AES-256-GCM decrypt</p>
        <p>Both queries hit the same Postgres instance, every single call — <strong>there is no in-memory cache on either side</strong>. Both measured end-to-end in Go using <code>time.Since()</code>. Results in microseconds (µs).</p>
        <p>This is a <strong>per-keystroke read</strong> comparison only. It does not include the cost of
        keeping the encrypted side fresh — that cost is real, it's just paid on a different path
        (see the lifecycle benchmarks below, and <code>ARCHITECTURE.md</code>).</p>
      </div>

      <LifecycleBench />
    </div>
  );
}

// ─── Lifecycle benchmarks: rebuild / incremental update / key rotation ────────
// These measure the costs the per-keystroke comparison above deliberately
// excludes: the price of keeping the encrypted trie correct and fresh.

function LifecycleBench() {
  const [rebuild,     setRebuild]     = useState<RebuildResponse | null>(null);
  const [incremental, setIncremental] = useState<IncrementalResponse | null>(null);
  const [rotate,       setRotate]     = useState<RotateResponse | null>(null);
  const [busy, setBusy] = useState<'rebuild' | 'incremental' | 'rotate' | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const run = useCallback(async (which: 'rebuild' | 'incremental' | 'rotate') => {
    setBusy(which); setErr(null);
    try {
      const path = which === 'rebuild' ? '/api/bench/rebuild'
                 : which === 'incremental' ? '/api/bench/incremental'
                 : '/api/bench/rotate?grace_seconds=10';
      const res = await fetch(path);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
      if (which === 'rebuild') setRebuild(data);
      if (which === 'incremental') setIncremental(data);
      if (which === 'rotate') setRotate(data);
    } catch (e: unknown) {
      setErr(e instanceof Error ? e.message : `${which} failed`);
    } finally {
      setBusy(null);
    }
  }, []);

  return (
    <div className="lifecycle-panel">
      <h3>Lifecycle benchmarks — the costs the read-latency test above excludes</h3>
      <p className="lifecycle-intro">
        Each button below performs a real operation against this deployment's own Postgres instance
        and reports how long it took. These are not read-path costs — they run once per rebuild
        schedule, once per data write, or once per key rotation, not once per keystroke.
      </p>

      <div className="lifecycle-grid">
        <div className="lifecycle-card">
          <div className="lifecycle-card-hdr">
            <span>🧱 Full rebuild</span>
            <button className="bench-btn small" disabled={busy!==null} onClick={() => run('rebuild')}>
              {busy==='rebuild' ? '⟳ Running…' : 'Run'}
            </button>
          </div>
          <p>Re-reads every keyword from all 5 source tables, rebuilds the prefix map, and
          re-encrypts every node. Scheduled/safety-net cost, not a per-request cost.</p>
          {rebuild && (
            <div className="lifecycle-result">
              <span>{rebuild.node_count.toLocaleString()} nodes</span>
              <span className="lifecycle-time">{rebuild.elapsed_ms} ms</span>
            </div>
          )}
        </div>

        <div className="lifecycle-card">
          <div className="lifecycle-card-hdr">
            <span>✏️ Incremental update</span>
            <button className="bench-btn small" disabled={busy!==null} onClick={() => run('incremental')}>
              {busy==='incremental' ? '⟳ Running…' : 'Run'}
            </button>
          </div>
          <p>Inserts, updates, then deletes one synthetic keyword in a dedicated bench table and
          re-derives only the affected trie nodes — not a full rebuild.</p>
          {incremental && (
            <div className="lifecycle-steps">
              {incremental.steps.map(s => (
                <div key={s.step} className="lifecycle-step-row">
                  <span className="lifecycle-step-name">{s.step}</span>
                  <span>{s.prefixes_touched} prefixes</span>
                  <span className="lifecycle-time">{s.trie_update_us}µs trie · {s.pg_write_ms}ms pg</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lifecycle-card">
          <div className="lifecycle-card-hdr">
            <span>🔁 Rotate keys</span>
            <button className="bench-btn small" disabled={busy!==null} onClick={() => run('rotate')}>
              {busy==='rotate' ? '⟳ Running…' : 'Run'}
            </button>
          </div>
          <p>Mints a new key epoch, re-encrypts every node under it, and gives the previous epoch a
          10s grace window before its key material is permanently deleted.</p>
          {rotate && (
            <div className="lifecycle-result">
              <span>epoch {rotate.old_epoch} → {rotate.new_epoch}</span>
              <span>{rotate.nodes_reencrypted.toLocaleString()} nodes</span>
              <span className="lifecycle-time">{rotate.elapsed_ms} ms</span>
            </div>
          )}
        </div>
      </div>

      {err && <div className="err-bar">⚠ {err}</div>}
    </div>
  );
}

function BenchResults({ result }: { result: BenchResponse }) {
  const { plain, encrypted } = result;
  if (!plain || !encrypted) return null;

  const metrics: Array<{ key: keyof BenchStats; label: string }> = [
    { key: 'p50', label: 'p50 (median)' },
    { key: 'p90', label: 'p90' },
    { key: 'p95', label: 'p95' },
    { key: 'p99', label: 'p99' },
    { key: 'min', label: 'min' },
    { key: 'max', label: 'max' },
    { key: 'mean', label: 'mean' },
  ];

  const maxUs = Math.max(plain.p99, encrypted.p99, 1000);

  return (
    <div className="bench-results">
      <div className="bench-summary">
        <div className="bench-winner">
          {encrypted.p50 < plain.p50
            ? `${(plain.p50 / Math.max(encrypted.p50, 1)).toFixed(1)}× lower p50 latency: indexed Postgres point-lookup vs. Postgres ILIKE scan (both live queries)`
            : `Postgres ILIKE is ${(encrypted.p50 / Math.max(plain.p50, 1)).toFixed(1)}× faster at p50 here`
          }
        </div>
        <div className="bench-note">n = {result.n} queries · µs = microseconds</div>
        {result.caveat && <div className="bench-caveat">⚠ {result.caveat}</div>}
      </div>

      <div className="bench-table">
        <div className="bench-thead">
          <div className="bench-th">Metric</div>
          <div className="bench-th plain-col">⚡ Plain Postgres</div>
          <div className="bench-th enc-col">🔐 Encrypted Trie</div>
          <div className="bench-th">Visual</div>
        </div>
        {metrics.map(({ key, label }) => {
          const pv = typeof plain[key] === 'number' ? plain[key] as number : 0;
          const ev = typeof encrypted[key] === 'number' ? encrypted[key] as number : 0;
          const winner = pv < ev ? 'plain' : 'enc';
          return (
            <div key={key} className="bench-row">
              <div className="bench-metric">{label}</div>
              <div className={`bench-val plain-col${winner==='plain'?' bench-win':''}`}>
                {pv < 1000 ? `${pv.toFixed(0)}µs` : `${(pv/1000).toFixed(2)}ms`}
              </div>
              <div className={`bench-val enc-col${winner==='enc'?' bench-win':''}`}>
                {ev < 1000 ? `${ev.toFixed(0)}µs` : `${(ev/1000).toFixed(2)}ms`}
              </div>
              <div className="bench-bars">
                <div className="bench-bar-wrap">
                  <div className="bench-bar plain-bar" style={{ width: `${(pv/maxUs)*100}%` }} />
                </div>
                <div className="bench-bar-wrap">
                  <div className="bench-bar enc-bar" style={{ width: `${(ev/maxUs)*100}%` }} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Histogram */}
      <div className="hist-section">
        <h3>Distribution (µs)</h3>
        <div className="hist-wrap">
          <Histogram samples={plain.samples} color="#00d9ff" label="Plain" />
          <Histogram samples={encrypted.samples} color="#a78bfa" label="Encrypted" />
        </div>
      </div>
    </div>
  );
}

function Histogram({ samples, color, label }: { samples: number[]; color: string; label: string }) {
  if (!samples?.length) return null;
  const BUCKETS = 20;
  const sorted = [...samples].sort((a,b)=>a-b);
  const min = sorted[0], max = sorted[sorted.length-1];
  const range = Math.max(max - min, 1);
  const bucketSize = range / BUCKETS;
  const counts = new Array(BUCKETS).fill(0);
  for (const v of sorted) {
    const bi = Math.min(Math.floor((v - min) / bucketSize), BUCKETS - 1);
    counts[bi]++;
  }
  const maxCount = Math.max(...counts, 1);
  return (
    <div className="histogram">
      <div className="hist-title" style={{ color }}>{label}</div>
      <div className="hist-bars">
        {counts.map((c, i) => (
          <div key={i} className="hist-col" title={`${(min + i * bucketSize).toFixed(0)}–${(min + (i+1) * bucketSize).toFixed(0)}µs: ${c}`}>
            <div className="hist-bar" style={{ height: `${(c/maxCount)*100}%`, background: color + 'cc' }} />
          </div>
        ))}
      </div>
      <div className="hist-axis">
        <span>{min.toFixed(0)}µs</span>
        <span>{max.toFixed(0)}µs</span>
      </div>
    </div>
  );
}

// ─── App shell ────────────────────────────────────────────────────────────────

// ─── Add Data tab: guided entry into the real source tables ───────────────────

function DataField({ spec, value, onChange }: {
  spec: KindSpec['fields'][number];
  value: string | boolean;
  onChange: (v: string | boolean) => void;
}) {
  if (spec.type === 'checkbox') {
    return (
      <label className="df-checkbox">
        <input type="checkbox" checked={!!value} onChange={e => onChange(e.target.checked)} />
        <span>{spec.label}</span>
      </label>
    );
  }
  if (spec.type === 'select') {
    return (
      <label className="df-field">
        <span className="df-label">{spec.label}{spec.required && <em> *</em>}</span>
        <select className="df-input" value={(value as string) ?? ''} onChange={e => onChange(e.target.value)}>
          <option value="">—</option>
          {(spec.options ?? []).map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      </label>
    );
  }
  if (spec.type === 'textarea') {
    return (
      <label className="df-field df-field-wide">
        <span className="df-label">{spec.label}{spec.required && <em> *</em>}</span>
        <textarea className="df-input df-textarea" rows={3} placeholder={spec.placeholder}
          value={(value as string) ?? ''} onChange={e => onChange(e.target.value)} />
        {spec.help && <span className="df-help">{spec.help}</span>}
      </label>
    );
  }
  return (
    <label className="df-field">
      <span className="df-label">{spec.label}{spec.required && <em> *</em>}</span>
      <input className="df-input" type={spec.type === 'number' ? 'number' : 'text'}
        placeholder={spec.placeholder} value={(value as string) ?? ''}
        onChange={e => onChange(e.target.value)} />
      {spec.help && <span className="df-help">{spec.help}</span>}
    </label>
  );
}

function AddDataTab() {
  const [schema, setSchema] = useState<DataSchemaResponse | null>(null);
  const [selectedKind, setSelectedKind] = useState('company');
  const [form, setForm] = useState<Record<string, string | boolean>>({});
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<DataCreateResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [recent, setRecent] = useState<RecentItem[]>([]);
  const [verifying, setVerifying] = useState(false);
  const [verifyPlain, setVerifyPlain] = useState<Suggestion[] | null>(null);
  const [verifyEnc, setVerifyEnc] = useState<{ found: boolean; suggestions: EncSuggestion[] } | null>(null);

  const loadRecent = useCallback(() => {
    fetch(`${API}/data/recent`).then(r => r.json()).then(d => setRecent(d.items ?? [])).catch(() => {});
  }, []);

  useEffect(() => {
    fetch(`${API}/data/schema`)
      .then(r => r.json())
      .then((d: DataSchemaResponse) => setSchema(d))
      .catch((e: Error) => setError(`schema fetch failed: ${e.message}`));
    loadRecent();
  }, [loadRecent]);

  const kindSpec = schema?.kinds.find(k => k.kind === selectedKind) ?? null;

  const selectKind = (k: string) => {
    setSelectedKind(k);
    setForm({});
    setResult(null);
    setError(null);
    setVerifyPlain(null);
    setVerifyEnc(null);
  };

  const verifyBothPaths = useCallback(async (prefix: string) => {
    setVerifying(true);
    try {
      const plainRes = await fetch(`${API}/suggest?q=${encodeURIComponent(prefix)}`);
      setVerifyPlain(await plainRes.json());

      const keyResp = await fetch(`${API}/enc-key`).then(r => r.json());
      const rootBytes = hexToBytes(keyResp.root_key_hex);
      const [td, nk] = await Promise.all([
        hmacSHA256(rootBytes, `td:e${keyResp.epoch}:${prefix}`),
        hmacSHA256(rootBytes, `node:e${keyResp.epoch}:${prefix}`),
      ]);
      const encRes = await fetch(`${API}/enc-suggest?td=${td}&nk=${nk}&epoch=${keyResp.epoch}`);
      const encData = await encRes.json();
      setVerifyEnc({ found: encData.found, suggestions: encData.suggestions ?? [] });
    } catch {
      // best-effort verification; the create already succeeded regardless
    } finally {
      setVerifying(false);
    }
  }, []);

  const submit = useCallback(async () => {
    if (!kindSpec) return;
    setSubmitting(true); setError(null); setResult(null); setVerifyPlain(null); setVerifyEnc(null);
    try {
      const body: Record<string, unknown> = {};
      for (const f of kindSpec.fields) {
        const v = form[f.name];
        if (f.type === 'checkbox') { body[f.name] = !!v; continue; }
        if (v === undefined || v === '') continue;
        body[f.name] = f.type === 'number' ? Number(v) : v;
      }
      const res = await fetch(`${API}/data/${selectedKind}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? `HTTP ${res.status}`);
      setResult(data);
      setForm({});
      loadRecent();
      await verifyBothPaths(data.try_prefix);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'submit failed');
    } finally {
      setSubmitting(false);
    }
  }, [kindSpec, form, selectedKind, loadRecent, verifyBothPaths]);

  const deleteItem = useCallback(async (kind: string, id: number) => {
    try {
      await fetch(`${API}/data/${kind}/${id}`, { method: 'DELETE' });
      loadRecent();
    } catch { /* best-effort */ }
  }, [loadRecent]);

  return (
    <div className="add-data-tab">
      <div className="dd-explain">
        <h3>What actually happens when you add something here</h3>
        <ol>
          {(schema?.how_it_works ?? []).map((line, i) => <li key={i}>{line}</li>)}
        </ol>
        {!schema && !error && <p className="dd-loading">Loading schema…</p>}
        {error && <div className="err-bar">⚠ {error}</div>}
      </div>

      <div className="dd-body">
        <div className="dd-form-panel">
          <div className="dd-kind-selector">
            {(schema?.kinds ?? []).map(k => (
              <button key={k.kind} className={`dd-kind-btn${selectedKind === k.kind ? ' active' : ''}`}
                onClick={() => selectKind(k.kind)}>
                {k.label}
              </button>
            ))}
          </div>

          {kindSpec && (
            <>
              <p className="dd-kind-explain">{kindSpec.explanation}</p>
              <div className="dd-fields">
                {kindSpec.fields.map(f => (
                  <DataField key={f.name} spec={f} value={form[f.name] ?? ''}
                    onChange={v => setForm(prev => ({ ...prev, [f.name]: v }))} />
                ))}
              </div>
              <button className="bench-btn" disabled={submitting} onClick={submit}>
                {submitting ? '⟳ Writing to Postgres…' : `+ Add ${kindSpec.label}`}
              </button>
            </>
          )}

          {result && (
            <div className="dd-result">
              <div className="dd-result-hdr">✅ Added — here's exactly what it cost, measured on this request</div>
              <div className="dd-result-grid">
                <div><span className="dd-result-lbl">Postgres write</span><span className="dd-result-val">{result.pg_write_ms} ms</span></div>
                <div><span className="dd-result-lbl">Trie update</span><span className="dd-result-val">{result.trie_update_us} µs</span></div>
                <div><span className="dd-result-lbl">Prefixes touched</span><span className="dd-result-val">{result.prefixes_touched}</span></div>
              </div>

              <div className="dd-verify">
                <div className="dd-verify-hdr">
                  {verifying ? `⟳ Verifying "${result.try_prefix}" is searchable both ways…` : `Searched for "${result.try_prefix}" in both tabs, live:`}
                </div>
                {!verifying && (
                  <div className="dd-verify-grid">
                    <div className="dd-verify-col">
                      <span className="dd-verify-lbl">⚡ Plain</span>
                      {verifyPlain && verifyPlain.length > 0
                        ? <span className="dd-verify-ok">✓ found — {verifyPlain.map(s => s.text).join(', ')}</span>
                        : <span className="dd-verify-fail">not found</span>}
                    </div>
                    <div className="dd-verify-col">
                      <span className="dd-verify-lbl">🔐 Encrypted</span>
                      {verifyEnc?.found
                        ? <span className="dd-verify-ok">✓ found — {verifyEnc.suggestions.map(s => s.text).join(', ')}</span>
                        : <span className="dd-verify-fail">not found</span>}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="dd-recent-panel">
          <h3>Recently added</h3>
          {recent.length === 0 && <p className="dd-loading">Nothing added yet in this session.</p>}
          <div className="dd-recent-list">
            {recent.map(it => (
              <div key={`${it.kind}-${it.id}`} className="dd-recent-row">
                <span className={`dd-recent-kind dd-recent-${it.kind}`}>{it.kind}</span>
                <span className="dd-recent-text">{it.text}</span>
                <button className="dd-recent-del" title="Delete" onClick={() => deleteItem(it.kind, it.id)}>✕</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

type Tab = 'search' | 'encrypted' | 'bench' | 'data';

export default function App() {
  const [tab, setTab] = useState<Tab>('search');

  return (
    <div className="app">
      <div className="bg-grid" />
      <div className="bg-glow" />
      <main className="main">
        <header className="hdr">
          <div className="logo">
            <span className="logo-dot" />
            <span className="logo-txt">Search<em>Pulse</em></span>
            <span className="logo-enc">enc</span>
          </div>
          <p className="tagline">Live autocomplete · Searchable encryption · Latency benchmark</p>
        </header>

        <div className="tabs">
          {([
            ['search',    '⚡ Plain Search'],
            ['encrypted', '🔐 Encrypted Search'],
            ['data',      '➕ Add Data'],
            ['bench',     '📊 Latency Benchmark'],
          ] as [Tab, string][]).map(([t, label]) => (
            <button key={t} className={`tab-btn${tab===t?' active':''}`} onClick={() => setTab(t)}>
              {label}
            </button>
          ))}
        </div>

        {tab === 'search'    && <PlainSearchTab />}
        {tab === 'encrypted' && <EncryptedSearchTab />}
        {tab === 'data'      && <AddDataTab />}
        {tab === 'bench'     && <BenchTab />}

        <footer className="foot">
          SearchPulse · HMAC-SHA256 · AES-256-GCM · Go · PostgreSQL · React
        </footer>
      </main>
    </div>
  );
}
