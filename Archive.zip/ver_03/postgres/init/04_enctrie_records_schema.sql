-- ============================================================================
-- Encrypted full-record retrieval (exact-match) — completes the pipeline
-- ============================================================================
-- enctrie_nodes (03_enctrie_schema.sql) only ever stores lightweight
-- autocomplete snippets (text/kind/subtitle) per PREFIX — that's all an
-- as-you-type suggestion needs, and it's deliberately minimal so a prefix
-- lookup can't leak more than "here are some things starting with this."
--
-- But selecting a suggestion needs to actually RETRIEVE something: the
-- full description, metadata, tags — the same rich payload
-- /api/search already returns for the plain path. That's a different
-- operation with a different trust shape (exact keyword needed, not just a
-- prefix), so it gets its own table and its own key-derivation labels
-- rather than overloading enctrie_nodes.
--
-- enctrie_records is keyed by the FULL, exact (not prefix) keyword. One
-- row per (epoch, trapdoor); trapdoor here is derived with the "rtd:"
-- label (record-trapdoor), distinct from the "td:" label prefix nodes use
-- — so leaking a prefix trapdoor never reveals a record trapdoor or vice
-- versa, even for the same underlying text.
CREATE TABLE enctrie_records (
    epoch      INTEGER     NOT NULL REFERENCES enctrie_key_epochs(epoch) ON DELETE CASCADE,
    trapdoor   CHAR(64)    NOT NULL,          -- hex(HMAC-SHA256(rootKey_epoch, "rtd:e<N>:"+exact_text))
    keyword    TEXT        NOT NULL,          -- plaintext exact text (builder-only field, see 03_enctrie_schema.sql §2 for the trust rationale)
    ciphertext BYTEA       NOT NULL,          -- AES-256-GCM(recordKey_epoch, []SearchResult JSON)
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (epoch, trapdoor),
    UNIQUE (epoch, keyword)
);
CREATE INDEX idx_enctrie_records_epoch ON enctrie_records (epoch);
-- Same rationale as idx_enctrie_nodes_trapdoor in 03_enctrie_schema.sql:
-- lets an epoch-less lookup (a client whose cached key predates a
-- rotation) still be an indexed query instead of a scan.
CREATE INDEX idx_enctrie_records_trapdoor ON enctrie_records (trapdoor);
