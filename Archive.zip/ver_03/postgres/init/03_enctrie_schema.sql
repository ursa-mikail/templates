-- ============================================================================
-- Encrypted Trie — persistent schema
-- ============================================================================
-- Everything in this file lives in the SAME Postgres instance as the
-- plaintext source tables (companies/products/trends/innovations).
-- There is no second database. See /ARCHITECTURE.md, section "How many
-- Postgres instances does this need?" for the reasoning.
--
-- Four new objects:
--   1. enctrie_key_epochs  — versioned root keys (envelope-encrypted at rest)
--   2. enctrie_nodes       — durable copy of the encrypted trie (ciphertext)
--   3. enctrie_outbox      — change-capture queue for incremental updates
--   4. bench_keywords      — a small, dedicated table used ONLY by the
--                            latency benchmarks to add/update/delete
--                            keywords without touching real seed data
-- ============================================================================

-- ── 1. Key epochs ────────────────────────────────────────────────────────────
-- One row per rotation generation. The root key itself is never stored in
-- the clear: it is wrapped (AES-256-GCM) under a Key-Encryption-Key (KEK)
-- that the Go process holds only in memory, sourced from the MASTER_KEK_HEX
-- environment variable (in real production: a KMS/HSM-backed key).
CREATE TABLE enctrie_key_epochs (
    epoch            INTEGER PRIMARY KEY,
    wrapped_root_key BYTEA       NOT NULL,   -- AES-GCM(KEK, root_key) ciphertext
    wrap_nonce       BYTEA       NOT NULL,   -- 12-byte GCM nonce used for the wrap
    status           TEXT        NOT NULL DEFAULT 'active'
                         CHECK (status IN ('active','grace','retired')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    retire_after     TIMESTAMPTZ,            -- set when rotated out; NULL while active
    retired_at       TIMESTAMPTZ             -- set once key material is purged
);

-- ── 2. Encrypted trie nodes (THE live serving table — no RAM cache) ────────
-- Every /api/enc-suggest request runs a real SELECT against this table.
-- There is no in-process cache in front of it: this table IS the trie.
-- `prefix` is kept in plaintext here because this table lives inside the
-- trusted builder's own database — the builder (this Go service) already
-- reads the plaintext source tables, so storing the prefix alongside its
-- ciphertext leaks nothing new. It is what lets the server do maintenance
-- (rotation, incremental updates) without needing the root key or
-- re-scanning all of Postgres. `trapdoor` is the value an untrusted reader
-- would use to look up ciphertext; it reveals nothing about `prefix`
-- without the epoch's root key. PRIMARY KEY (epoch, trapdoor) gives every
-- read an indexed, O(log n) point lookup — the same class of operation as
-- any other primary-key SELECT in this database.
CREATE TABLE enctrie_nodes (
    epoch      INTEGER     NOT NULL REFERENCES enctrie_key_epochs(epoch) ON DELETE CASCADE,
    trapdoor   CHAR(64)    NOT NULL,          -- hex(HMAC-SHA256(rootKey_epoch, "td:"+prefix))
    prefix     TEXT        NOT NULL,          -- plaintext prefix (builder-only field, see above)
    ciphertext BYTEA       NOT NULL,          -- AES-256-GCM(nodeKey_epoch, suggestions JSON)
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (epoch, trapdoor),
    UNIQUE (epoch, prefix)
);
CREATE INDEX idx_enctrie_nodes_epoch ON enctrie_nodes (epoch);
-- Secondary index for the (rare) epoch-less lookup path: a client whose
-- cached key predates a rotation sends only a trapdoor, no epoch. The
-- primary key (epoch, trapdoor) can't serve that alone, so a plain B-tree
-- on trapdoor lets Postgres still do an indexed lookup instead of a scan.
CREATE INDEX idx_enctrie_nodes_trapdoor ON enctrie_nodes (trapdoor);

-- ── 3. Change outbox (incremental-update queue) ─────────────────────────────
-- Populated by triggers below. A background goroutine (internal/outbox)
-- drains this table, recomputes only the trie nodes for the prefixes of the
-- affected keyword(s), and marks rows processed. LISTEN/NOTIFY wakes the
-- goroutine immediately; a periodic poll is the fallback if a notification
-- is ever missed (process restart mid-transaction, etc).
CREATE TABLE enctrie_outbox (
    id            BIGSERIAL PRIMARY KEY,
    source_table  TEXT        NOT NULL,
    op            TEXT        NOT NULL CHECK (op IN ('INSERT','UPDATE','DELETE')),
    keyword       TEXT,                       -- NEW value (NULL on DELETE)
    old_keyword   TEXT,                       -- OLD value (NULL on INSERT)
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    processed_at  TIMESTAMPTZ
);
CREATE INDEX idx_enctrie_outbox_unprocessed ON enctrie_outbox (id) WHERE processed_at IS NULL;

CREATE OR REPLACE FUNCTION enctrie_outbox_insert(
    p_table TEXT, p_op TEXT, p_keyword TEXT, p_old_keyword TEXT
) RETURNS void AS $$
BEGIN
    INSERT INTO enctrie_outbox (source_table, op, keyword, old_keyword)
    VALUES (p_table, p_op, p_keyword, p_old_keyword);
    PERFORM pg_notify('enctrie_changes', currval(pg_get_serial_sequence('enctrie_outbox','id'))::text);
END;
$$ LANGUAGE plpgsql;

-- One trigger function per source table (column names differ: name vs title).
CREATE OR REPLACE FUNCTION enctrie_trg_companies() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN PERFORM enctrie_outbox_insert('companies','INSERT', NEW.name, NULL);
    ELSIF TG_OP = 'UPDATE' THEN PERFORM enctrie_outbox_insert('companies','UPDATE', NEW.name, OLD.name);
    ELSIF TG_OP = 'DELETE' THEN PERFORM enctrie_outbox_insert('companies','DELETE', NULL, OLD.name);
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_companies_enctrie
AFTER INSERT OR UPDATE OF name OR DELETE ON companies
FOR EACH ROW EXECUTE FUNCTION enctrie_trg_companies();

CREATE OR REPLACE FUNCTION enctrie_trg_products() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN PERFORM enctrie_outbox_insert('products','INSERT', NEW.name, NULL);
    ELSIF TG_OP = 'UPDATE' THEN PERFORM enctrie_outbox_insert('products','UPDATE', NEW.name, OLD.name);
    ELSIF TG_OP = 'DELETE' THEN PERFORM enctrie_outbox_insert('products','DELETE', NULL, OLD.name);
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_products_enctrie
AFTER INSERT OR UPDATE OF name OR DELETE ON products
FOR EACH ROW EXECUTE FUNCTION enctrie_trg_products();

CREATE OR REPLACE FUNCTION enctrie_trg_trends() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN PERFORM enctrie_outbox_insert('trends','INSERT', NEW.name, NULL);
    ELSIF TG_OP = 'UPDATE' THEN PERFORM enctrie_outbox_insert('trends','UPDATE', NEW.name, OLD.name);
    ELSIF TG_OP = 'DELETE' THEN PERFORM enctrie_outbox_insert('trends','DELETE', NULL, OLD.name);
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_trends_enctrie
AFTER INSERT OR UPDATE OF name OR DELETE ON trends
FOR EACH ROW EXECUTE FUNCTION enctrie_trg_trends();

CREATE OR REPLACE FUNCTION enctrie_trg_innovations() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN PERFORM enctrie_outbox_insert('innovations','INSERT', NEW.title, NULL);
    ELSIF TG_OP = 'UPDATE' THEN PERFORM enctrie_outbox_insert('innovations','UPDATE', NEW.title, OLD.title);
    ELSIF TG_OP = 'DELETE' THEN PERFORM enctrie_outbox_insert('innovations','DELETE', NULL, OLD.title);
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_innovations_enctrie
AFTER INSERT OR UPDATE OF title OR DELETE ON innovations
FOR EACH ROW EXECUTE FUNCTION enctrie_trg_innovations();

-- ── 4. Bench scratch table ───────────────────────────────────────────────────
-- Dedicated churn table for the latency benchmarks (/api/bench/incremental).
-- Keeping this separate from `companies` etc. means running the benchmark
-- repeatedly never mutates the real seed data shown in the demo UI.
CREATE TABLE bench_keywords (
    id         SERIAL PRIMARY KEY,
    text       VARCHAR(255) NOT NULL,
    kind       VARCHAR(50)  NOT NULL DEFAULT 'bench',
    subtitle   VARCHAR(255) NOT NULL DEFAULT 'synthetic · churn test',
    created_at TIMESTAMPTZ  NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION enctrie_trg_bench_keywords() RETURNS trigger AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN PERFORM enctrie_outbox_insert('bench_keywords','INSERT', NEW.text, NULL);
    ELSIF TG_OP = 'UPDATE' THEN PERFORM enctrie_outbox_insert('bench_keywords','UPDATE', NEW.text, OLD.text);
    ELSIF TG_OP = 'DELETE' THEN PERFORM enctrie_outbox_insert('bench_keywords','DELETE', NULL, OLD.text);
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_bench_keywords_enctrie
AFTER INSERT OR UPDATE OF text OR DELETE ON bench_keywords
FOR EACH ROW EXECUTE FUNCTION enctrie_trg_bench_keywords();
