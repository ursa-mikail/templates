# SearchPulse-Enc — Architecture

This document explains, end to end and without gaps, how the encrypted
autocomplete system works: how many databases it needs, every data
structure involved, how keys rotate, how the trie stays fresh, and how to
read the latency numbers honestly.

**There is no in-memory cache anywhere in the read path.** Every single
autocomplete request — plain or encrypted — runs a real SQL query against
the same Postgres instance. This was the specific flaw in the original
demo (the encrypted side lived entirely in the Go process's RAM and never
touched Postgres at request time, which is what made its "200–460× faster"
number meaningless), and it's fixed structurally here, not just
disclaimed.

---

## 1. How many Postgres instances does this need? **One.**

```
┌─────────────────────────── ONE Postgres instance ───────────────────────────┐
│                                                                              │
│  Plaintext source tables            Encrypted-trie tables                   │
│  ───────────────────────            ──────────────────────                  │
│  companies                          enctrie_key_epochs (wrapped root keys)  │
│  products                           enctrie_nodes    ← autocomplete, every  │
│  trends                                                 read a real SELECT  │
│  innovations                        enctrie_records  ← full retrieval,      │
│  bench_keywords (churn test)                            every read a real   │
│                                                           SELECT (see        │
│                                      enctrie_outbox (change queue)  SEARCHABLE_ENCRYPTION.md §3) │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────┘
                          ▲                              ▲
                          │ live SELECT, every            │ live SELECT, every
                          │ /api/suggest call              │ /api/enc-suggest call
                          │ (ILIKE scan, GIN index)        │ (PK point lookup)
                          │                                │
┌──────────────────────────────────────────────────────────────────────────┐
│                Go backend process (any number of stateless replicas)      │
│         Holds NO trie data. Holds only: DB connections, and (small,       │
│         32-byte-per-epoch) key material needed to derive/verify HMACs.    │
└──────────────────────────────────────────────────────────────────────────┘
```

Why not a second database?

- **Durability is already solved.** Whatever backup/replication story you
  already run for Postgres now also covers the encrypted trie, for free —
  because it's rows in the same database, not a separate cache that a
  restart would wipe out.
- **One thing to operate**, not two — no second connection pool, no second
  failure mode, no second set of credentials to rotate.
- **Every backend replica is stateless.** Scale the Go process horizontally
  behind a load balancer with zero coordination — there's no cache to warm,
  no cache to keep in sync between replicas, because none of them hold a
  copy of the trie. They all just query the one Postgres instance.
- **The scale doesn't demand a second engine.** At the sizes this pattern
  targets (tens of thousands to low millions of prefixes), an indexed
  primary-key point lookup in Postgres is a single-digit-millisecond
  operation, same order of magnitude as any other indexed read in this
  system.
- **When you *would* add something else:** if read QPS grows far beyond
  what one Postgres instance (with read replicas) can serve, the standard
  next step is a read replica of `enctrie_nodes` specifically, or a
  distributed KV cache (Redis) *in front of* Postgres as an optional
  accelerator — not a replacement for it as the source of truth. This
  deployment doesn't need that; adding it prematurely is exactly the kind
  of "free lunch" shortcut that produced the original misleading
  benchmark.

---

## 2. Why the original 200–460× comparison was invalid, and how this fixes it

The two endpoints did not do equivalent work:

| | `/api/suggest` (plain) | `/api/enc-suggest`, **original demo** | `/api/enc-suggest`, **this version** |
|---|---|---|---|
| Where does the data live? | Postgres, on disk | Go process RAM (`map[string][]byte`) | Postgres, on disk (`enctrie_nodes`) |
| What runs per request? | Live SQL: connect, plan, GIN-scan 4 tables, serialize | A Go hash-map lookup + AES-GCM decrypt — **zero network, zero Postgres access** | Live SQL: connect, indexed point-lookup on `(epoch, trapdoor)`, decrypt |
| Does it touch the network/DB at all? | Yes, every time | **No** | **Yes, every time** |

The original version wasn't comparing "encrypted vs. plaintext" or even
"fast index vs. slow index" — it was comparing "a database query" against
"no database query at all." Of course the side with no database query won
by 200–460×; that's true of *any* in-memory cache versus *any* database,
encryption has nothing to do with it.

This version fixes that at the structural level: **`enctrie.Store` has no
cache field.** Look at `internal/enctrie/enctrie.go` — `Query()` issues a
`db.QueryRow(...)` on every call, full stop. There's nowhere for a
shortcut to hide. What you're left with is a legitimate, fair comparison:

> **Postgres pattern-match scan** (`ILIKE '%prefix%'`, GIN-trigram
> accelerated, across a `UNION ALL` of 4 tables) **vs. Postgres exact-match
> point lookup** (`WHERE epoch = $1 AND trapdoor = $2`, a single B-tree
> descent on the primary key of one table).

Both are real Postgres operations, paid for on every request, over the
same connection pool, on the same instance. The encrypted side is still
faster in practice — point lookups on a primary key are algorithmically
cheaper than multi-table pattern-match scans — but now the *reason* is
honest and the magnitude is realistic (see §6), not an artifact of one
side secretly skipping the database.

---

## 3. Every data structure, precisely

### 3.1 Plaintext source tables (Postgres, existing)

`companies`, `products`, `trends`, `innovations` — ordinary relational
tables with GIN trigram (`pg_trgm`) and full-text (`tsvector`) indexes.
This is the single source of truth. `/api/search` and `/api/suggest`
query these directly, live, every request.

### 3.2 The "trie", concretely: one Postgres table

A textbook trie is a tree: one node per character, linked by child
pointers, so looking up `"claude"` means walking `c → l → a → u → d → e`,
one pointer hop per letter. This system does **not** use that
representation, because every query already arrives with the complete
prefix string (whatever the user has typed) — there's no reason to walk it
character by character. Instead, the entire trie is one table:

```sql
CREATE TABLE enctrie_nodes (
    epoch      INTEGER     NOT NULL REFERENCES enctrie_key_epochs(epoch),
    trapdoor   CHAR(64)    NOT NULL,   -- hex(HMAC-SHA256(rootKey_epoch, "td:"+prefix))
    prefix     TEXT        NOT NULL,   -- plaintext prefix (builder-only, see §3.3)
    ciphertext BYTEA       NOT NULL,   -- AES-256-GCM(nodeKey_epoch, suggestions JSON)
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (epoch, trapdoor),     -- ← this IS the trie's indexing structure
    UNIQUE (epoch, prefix)
);
```

Every prefix of every keyword gets exactly one row (`"c"`, `"cl"`, `"cla"`,
`"clau"`, `"claud"`, `"claude"` are six separate rows). The
`PRIMARY KEY (epoch, trapdoor)` is a B-tree index — looking up a prefix is
one indexed point lookup, `O(log n)` in the number of rows, conceptually
identical to `SELECT * FROM products WHERE id = $1`. This is still
logically a trie (it indexes every prefix of every keyword); it is simply
materialized as rows in a table instead of pointers in RAM. The trade-off
versus a pointer-based tree: you cannot cheaply enumerate "every child of
node X" (useful for e.g. spell-correction that walks siblings) — this
system doesn't need that, so it doesn't pay for it.

**Building it** (`enctrie.buildPrefixMap`, called only inside
`FullRebuild`): for every keyword pulled from the source tables, walk
every prefix length from 1 to `len(keyword)`, and for each prefix,
aggregate that keyword's suggestion into that prefix's set (deduplicated
by suggestion text, capped at 8 per node). This intermediate map is held
in Go memory only for the duration of one `FullRebuild()` call — the same
way any bulk `INSERT` job has to hold *some* batch of rows in memory to
write them out — and is discarded the moment the function returns. It is
never consulted to answer a read; reads always go back to Postgres.

### 3.3 Key hierarchy

```
KEK (Key-Encryption-Key)              1 per deployment, from MASTER_KEK_HEX
  │                                    (production: KMS/HSM-managed, never
  │                                     a literal value in a config file)
  ▼
root key, per epoch                   32 random bytes, generated at
  │                                    Rotate() time, wrapped with
  │                                    AES-256-GCM under the KEK before
  │                                    it's ever written to disk
  ├──▶ trapdoor(prefix)  = hex(HMAC-SHA256(rootKey_epoch, "td:e<N>:"+prefix))
  └──▶ nodeKey(prefix)   =     HMAC-SHA256(rootKey_epoch, "node:e<N>:"+prefix)
```

- **Trapdoor** — a deterministic, one-way lookup token. Postgres indexes
  ciphertext by trapdoor, never by the plaintext prefix. Given a trapdoor,
  nobody without the root key can recover the prefix that produced it or
  enumerate other valid trapdoors.
- **Node key** — the AES-256 key that decrypts a node's ciphertext.
  Deliberately a *different* HMAC output than the trapdoor (different
  label: `"td:"` vs `"node:"`), so leaking one doesn't leak the other.
- **Epoch** — an integer versioning the root key, mixed into every HMAC
  call so epoch 1's trapdoor for `"claude"` and epoch 2's trapdoor for
  `"claude"` are unrelated 32-byte values to an outside observer. This is
  what makes key rotation safe without downtime (§4).

The 32-byte-per-epoch root keys themselves (typically 1–2 of them at a
time: current + one in its grace window) are held in the Go process's
memory (`keys.Store`). That is *not* a violation of "no in-memory cache" —
it's cryptographic material the process fundamentally needs to compute
HMACs and issue keys to clients; it is not a copy of query results
standing in for a database read. Every actual autocomplete answer still
comes from Postgres on every request, regardless of how the keys
themselves are held.

**What the server is trusted to know, and why storing `prefix` in
`enctrie_nodes` is fine:** the Go backend is the *builder* — it already
reads all the plaintext keywords directly from the source tables to build
the trie in the first place. Storing the plaintext `prefix` alongside its
ciphertext in the same trusted Postgres instance therefore reveals nothing
that this process didn't already know. What the searchable-encryption
design protects is the **query path**: an untrusted reader of
`enctrie_nodes`, or a browser sniffing the network between client and
server, sees only opaque trapdoors and ciphertext, and learns nothing
beyond "someone queried whatever prefix produces this trapdoor" — which is
inherent to any prefix-search system and is the stated threat-model
boundary.

### 3.4 Encrypted node (ciphertext at rest)

```
ciphertext = AES-256-GCM_Seal(nodeKey, plaintext = JSON{ suggestions: [...] })
```

GCM is authenticated encryption: confidentiality **and** tamper-evidence
in one primitive — a corrupted or forged ciphertext fails to decrypt
rather than silently returning garbage. A random 12-byte nonce is
generated per encryption and prepended to the ciphertext.

### 3.5 Change outbox (`enctrie_outbox`)

Postgres triggers on `companies`, `products`, `trends`, `innovations`, and
`bench_keywords` fire on every `INSERT`/`UPDATE`/`DELETE`, writing a row
recording which keyword changed (old value, new value) and calling
`pg_notify('enctrie_changes', ...)`. A Go goroutine
(`internal/outbox.Processor`) is subscribed via `pq.Listener` and wakes up
immediately on notify; a 5-second poll ticker is the fallback in case a
notification is ever missed (Postgres does not queue notifications for
offline listeners, but the outbox *rows* persist on disk, so the next poll
always catches up). The processor's job is entirely about **writes** — it
calls `enctrie.Store.UpdateKeyword`, which writes directly to
`enctrie_nodes`. It never populates anything that a read depends on beyond
those rows.

### 3.6 Key epoch table (`enctrie_key_epochs`)

One row per rotation generation: the wrapped (KEK-encrypted) root key, its
status (`active` / `grace` / `retired`), and — once superseded — the
timestamp after which its key material gets permanently deleted.

---

## 4. Key rotation — the full lifecycle

```
 epoch 1                epoch 2                          epoch 1 material
 "active"      Rotate()  "active"                         permanently deleted
 ────────────────┬─────────────────────┬──────────────────────┬────────────
                  │                     │                      │
             mint epoch 2      re-encrypt every node      grace window
             (new root key)    under epoch 2's key         elapses →
             epoch 1 → "grace"  (RotateReencrypt,           PruneExpired()
                                streamed FROM Postgres,      deletes epoch 1
                                written back TO Postgres,    row (cascades to
                                in batches — see §4.2)       its enctrie_nodes
                                                              rows in Postgres)
```

### 4.1 Minting a new epoch

`keys.Store.Rotate(grace)` generates a fresh 32-byte root key, wraps it
under the KEK, inserts it as a new epoch (`status = 'active'`), and
demotes the previous epoch to `status = 'grace'` with
`retire_after = now() + grace`.

### 4.2 Re-encrypting every node — streamed through Postgres, not loaded into RAM

`enctrie.Store.RotateReencrypt(oldEpoch, newEpoch)`:

1. Opens a **streaming** `SELECT prefix, ciphertext FROM enctrie_nodes
   WHERE epoch = $1` cursor against Postgres — rows are read one at a time
   via `rows.Next()`, not fetched all at once.
2. For each row: decrypt with the old epoch's derived node key, re-encrypt
   with the new epoch's derived node key, derive the new trapdoor.
3. Accumulates re-encrypted rows into a small batch (500 at a time —
   `rotateBatchSize`) and writes each batch to Postgres in its own
   transaction, then discards the batch and continues streaming.

At no point does the full node set sit in the Go process's memory — it
flows through in bounded-size batches, the same way any ETL/bulk-write job
processes a large table without loading all of it at once. Crucially, this
never re-reads the *plaintext source tables* — cost scales with node
count, not with the size of `companies`/`products`/etc, which is what
keeps rotation affordable regardless of how large those tables grow.

### 4.3 Dual-key read window

While both epochs are valid, `EncSuggest` accepts a request for either:
a client can pass `epoch` explicitly for a direct primary-key lookup, or
omit it and the server queries `WHERE trapdoor = $1 AND epoch = ANY($2)`
(indexed via a secondary B-tree index on `trapdoor` alone,
`idx_enctrie_nodes_trapdoor`) across every currently-valid epoch. This
means a browser tab that fetched its key material just before a rotation
still gets correct answers — via a real, indexed Postgres query — until it
refreshes its key.

### 4.4 Actually deleting the old key — the step that matters

`keys.Store.PruneExpired()`, run on a 30-second ticker in `main.go`,
deletes any epoch whose grace window has elapsed. Deleting its
`enctrie_key_epochs` row **cascades** (`ON DELETE CASCADE`) to delete
every one of its `enctrie_nodes` rows in Postgres. Rotation without this
deletion step is not rotation — it's just "now there are two valid keys
forever." Crypto-shredding the old key material is what bounds the blast
radius of a compromise to one epoch's grace window.

**Suggested cadence:** routine rotation every 30–90 days with a grace
window of hours to a day; emergency rotation immediately on suspected
compromise, with the grace window shortened to minutes.

**Trigger it:**
- `POST /api/admin/rotate?grace_seconds=86400` (behind `X-API-Key`)
- Or from the UI: Latency Benchmark tab → Lifecycle benchmarks → "Rotate
  keys" (uses a 10-second grace window so the demo can show pruning happen
  live).

---

## 5. Incremental updates — keeping the trie fresh without a full rebuild

A full rebuild costs O(total keyword characters across every source
table) — fine at startup, wasteful on every single write. Instead:

1. A source-table trigger fires on write, inserting one row into
   `enctrie_outbox` with the changed keyword's old and new text.
2. The outbox processor picks it up (via NOTIFY or the poll fallback) and
   calls `enctrie.Store.UpdateKeyword(epoch, oldText, newText)`.
3. `UpdateKeyword` computes the **union of every prefix of `oldText` and
   every prefix of `newText`** — e.g. renaming `"Cloud"` → `"Clouds"`
   touches `{"c","cl","clo","clou","cloud"}` from the old value and
   `{"c","cl","clo","clou","cloud","clouds"}` from the new one — O(len)
   prefixes, independent of total trie size.
4. Because a prefix node aggregates suggestions from **every** keyword
   that shares it, the code re-queries Postgres for each touched prefix's
   current, correct aggregate suggestion set
   (`aggregateForPrefixTx`, run inside the same transaction as the write),
   then re-encrypts just those nodes and writes them straight to
   `enctrie_nodes`. If a prefix's aggregate becomes empty, the row is
   deleted rather than stored empty.
5. This runs against **every currently-valid epoch**, so reads against a
   not-yet-retired grace-period epoch also stay correct during a rotation.

There is nothing to update "in the cache" — the write goes to Postgres,
and the very next `/api/enc-suggest` call for that prefix sees it via a
normal `SELECT`, the same as any other database-backed application.

### 5.1 A real concurrency bug, found by actually running this, and its fix

`/api/bench/incremental` writes a keyword directly (to measure the raw
trie-update cost) *and* that same write fires a trigger that the outbox
processor picks up independently and applies again, asynchronously — by
design, so both costs are observable. Under live testing against a real
Postgres instance, this produced `pq: deadlock detected`: two transactions
(the handler's direct call and the outbox's async call) both doing
`INSERT ... ON CONFLICT DO UPDATE` across the *same set* of prefix rows,
but iterating that set in Go's randomized map order — so transaction A
might lock row `"b"` then wait on row `"be"`, while transaction B holds
`"be"` and waits on `"b"`. Classic lock-order inversion.

The fix (`enctrie.go`, `UpdateKeyword` and `FullRebuild`): sort the touched
prefixes before writing, so every writer in the system locks
`enctrie_nodes` rows in the same global (lexicographic) order. Two
transactions can still collide on the same row, but now one simply waits
for the other to commit instead of deadlocking. Verified with 15
sequential and 10 fully concurrent calls to `/api/bench/incremental`
against a live Postgres instance — zero errors after the fix, reproducible
`pq: deadlock detected` before it. `RotateReencrypt` was already safe
because its writes are ordered by the SQL `ORDER BY prefix` on the read
side.

---

## 6. What every latency benchmark actually measures

`/api/bench*` intentionally never blends these into one number:

| Endpoint | Measures | Cost model | Hits Postgres? |
|---|---|---|---|
| `GET /api/bench?n=` | Plain `ILIKE` scan vs. encrypted point lookup, per keystroke | Paid on every request | **Both sides, every call** |
| `GET /api/bench/rebuild` | Full trie rebuild from all 5 source tables, written to Postgres | Paid once at startup / on a schedule | Yes (read + bulk write) |
| `GET /api/bench/incremental` | Insert → update → delete one synthetic keyword (dedicated `bench_keywords` table, never touches real seed data), plus the resulting trie row updates | Paid once per data change, async | Yes |
| `GET /api/bench/rotate?grace_seconds=` | A real key rotation: new epoch + streamed re-encryption of every node | Paid once per rotation | Yes (streamed read + batched write) |

The `/api/bench` response's `caveat` field spells out, in the JSON itself,
that both sides are live Postgres queries and that the gap is query
complexity — so the number can't be quoted out of context the way the
original 200–460× figure was. The UI's Latency Benchmark tab surfaces all
four as separate panels (a per-keystroke comparison + a "Lifecycle
benchmarks" section with Rebuild / Incremental / Rotate buttons), each
labeled with what it costs and when that cost is paid.

**Roughly what to expect**, and why: an `ILIKE` scan across a `UNION ALL`
of 4 tables (even GIN-trigram-accelerated) typically costs low hundreds of
microseconds to low milliseconds, because it still involves planning a
multi-table query and scanning a variable number of matching rows. A
primary-key point lookup on `enctrie_nodes` typically costs tens to low
hundreds of microseconds, because it's a single B-tree descent that
returns exactly zero or one row. Expect something in the range of a
single-digit multiple (roughly 3–15×), not hundreds of times — because,
unlike before, both sides are now doing real, comparable database work.
Exact numbers depend on your hardware, connection pool state, and
Postgres configuration; run `/api/bench` yourself rather than trusting any
number printed in a document, including this one.

---

## 6.5. Adding real data — not just synthetic benchmark churn

`/api/bench/incremental` (§6) proves the incremental-update *mechanism*
works, but it only ever writes a throwaway synthetic keyword to the
dedicated `bench_keywords` table. There is a separate, real feature for
adding actual searchable content:

- **UI:** the "➕ Add Data" tab.
- **API:** `GET /api/data/schema` returns a machine-readable description of
  all four content types this system indexes (`company`, `product`,
  `trend`, `innovation`) — which table each maps to, every field, and
  which single field is *the* text that gets walked into trie prefixes
  (`companies.name`, `products.name`, `trends.name`,
  `innovations.title`). The UI renders its form directly from this
  response — the form fields are not hand-coded twice, they come from the
  same schema description a script or another client could also read.
  `POST /api/data/{kind}` and `DELETE /api/data/{kind}/{id}` create/remove
  a real row in the real source table (`companies`/`products`/`trends`/
  `innovations`), gated by the same `RequireAPIKey` pattern as
  `/api/admin/*` (see §7).

What happens on submit, precisely, in order:

1. A real `INSERT` into the source table you picked — the exact same
   table `/api/search` and `/api/suggest` already query live. For a
   product, an optional `company_name` field is resolved to a
   `company_id` via a case-insensitive name lookup against `companies` —
   left unlinked if there's no match, so linking is opportunistic, not a
   hard requirement.
2. The Postgres trigger on that table (§3.6) fires automatically and
   queues the change in `enctrie_outbox`, exactly as it would for any
   other write to that table, from any source.
3. The same request **also** calls `enctrie.Store.UpdateKeyword` directly
   — the identical function the outbox processor itself calls — so the
   new item is live in the encrypted trie by the time the HTTP response
   comes back, rather than only eventually, asynchronously. The response
   reports precisely how long that took: `pg_write_ms`, `trie_update_us`,
   and how many prefix rows were touched.
4. The UI then immediately re-queries both `/api/suggest` and
   `/api/enc-suggest` for a short prefix of what you just typed and shows
   both results side by side — proof, not just a claim, that the item is
   findable both ways right now.

`DELETE /api/data/{kind}/{id}` does the mirror operation: deletes the
source row (the trigger fires the same way) and calls `UpdateKeyword` with
the old text and an empty new text, which — per §5 — removes the row from
`enctrie_nodes` entirely if no other keyword still shares that prefix.

---

## 7. What is still explicitly a demo simplification

**`GET /api/enc-key` still hands the raw root key to whoever calls it.**
That's actually the *correct* half of the design — the browser deriving
`trapdoor`/`nodeKey` locally via Web Crypto is what keeps the server from
ever seeing the plaintext prefix a user is typing, and moving that
derivation server-side would defeat the whole point. What's missing is
**access control on who gets a key and what they get**:

- The endpoint should require authenticated-session auth (OAuth/JWT), not
  the placeholder shared-secret (`X-API-Key` via `RequireAPIKey`) used
  here — that placeholder exists to demonstrate the endpoint must not be
  publicly reachable, not to be a complete auth system.
- Issued keys should be short-lived (minutes, not indefinite) and scoped
  per tenant/session, refreshed automatically rather than fetched once and
  held forever.
- `RequireAPIKey` also gates `/api/admin/rebuild` and `/api/admin/rotate`
  for the same reason — those are cluster-wide operational actions and
  must not be publicly callable either.

Everything else in this document — one Postgres instance, zero in-memory
caching on the read path, the durable trie and record-retrieval tables,
the incremental update path, the key-rotation lifecycle with actual
deletion of old key material, and the honest, apples-to-apples latency
accounting — is implemented for real against this repo's own Postgres
instance, not simulated or disclaimed away.

---

## 8. Bugs found by actually running this, and their fixes

Both of these were caught by running the real stack against a real
Postgres instance and exercising it with real HTTP requests — not by
reading the code. Recorded here so the fixes don't get silently reverted.

**Encrypted search returned nothing (`found: false` on every query).**
When epoch-based key rotation was added to the backend, the HMAC label
format changed to include the epoch: `"td:e<epoch>:"+prefix` and
`"node:e<epoch>:"+prefix` (`internal/keys/keys.go`,
`DeriveTrapdoor`/`DeriveNodeKey`). The frontend's client-side HMAC
computation (`hooks/useEncSearch.ts`) was never updated to match — it kept
computing `"td:"+prefix` with no epoch at all, so every trapdoor the
browser generated was cryptographically guaranteed to miss every row in
`enctrie_nodes`. Verified with a side-by-side reproduction: the old label
format returns `{"found": false}` against a live server every time; the
corrected format (`` `td:e${epoch}:${prefix}` ``) returns correct,
decrypted results. Fixed by matching the label format exactly, and by
exporting the corrected `hmacSHA256`/`hexToBytes` functions from the hook
so any other code that needs to derive a trapdoor (e.g. the "Add Data"
tab's own verification step, §6.5) reuses the same implementation instead
of risking a second copy drifting out of sync the same way.

**`pq: deadlock detected` on `/api/bench/incremental`.** See §5.1.

**Selecting an encrypted suggestion (or pressing Enter) did nothing —
"autosuggestion works, but nothing is retrieved."** This wasn't a small
bug, it was a missing feature: `enctrie_nodes` only ever stored
lightweight suggestion snippets (text/kind/subtitle) keyed by prefix — a
genuine full-record retrieval step, analogous to what `/api/search`
already does for the plain path, never existed on the encrypted side.
`selectSuggestion` in the frontend just set the search box text and
closed the dropdown; there was nothing to select an action *to*. Fixed by
adding a second encrypted data structure, `enctrie_records` (exact-match,
full payload, distinct `rtd:`/`rkey:` HMAC-label namespace from the
prefix trie's `td:`/`node:` — see SEARCHABLE_ENCRYPTION.md §3), a new
`GET /api/enc-record` endpoint, and wiring `selectSuggestion` (and Enter
with no highlighted suggestion) to call it. Verified end-to-end with a
Node script running the exact client-side algorithm: type a prefix → get
a suggestion → select it → retrieve and decrypt the full record — against
a live Postgres instance, not mocked. `enctrie_records` participates in
every rebuild, incremental update, and rotation the prefix trie does (see
SEARCHABLE_ENCRYPTION.md §5–§6); it was not bolted on as an afterthought.


