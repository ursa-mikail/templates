# How Searchable Encryption Works in SearchPulse-Enc

This is a self-contained guide to the encrypted side of this system: what
it actually does, how to set it up, and exactly what happens on every
operation — typing a character, selecting a result, adding data, deleting
data, and rotating keys. For the plain-Postgres side and the "why is this
faster/slower" latency analysis, see `LATENCY_CALCULUS.md`. For the deepest
architectural detail and the bug-fix log, see `ARCHITECTURE.md`. This
document is the one to read first.

---

## 1. The problem this solves, in one paragraph

Normal full-text search means the database sees every keystroke in plain
text — the search terms, and therefore a good deal about what the user is
interested in, pass through the server and typically get logged. Searchable
encryption lets the **server index and query data it can never read**: it
stores ciphertext, receives cryptographic lookup tokens instead of search
terms, and returns ciphertext back. Only the client — who holds the root
key — can turn a query into a lookup token, and turn a ciphertext response
back into readable text. The server does real work (Postgres queries,
index lookups) on data it cannot itself decrypt.

---

## 2. Setup

### 2.1 What you need

**One Postgres instance.** That's it — see `ARCHITECTURE.md` §1 for the
reasoning. No Redis, no second database, no external KMS required to run
this locally (though production should use a real KMS — see §7).

### 2.2 Running it

```bash
./up.sh
```

This starts three containers (Postgres, the Go backend, the React
frontend) via `docker-compose.yml`. On first boot, `postgres/init/*.sql`
runs automatically (Postgres's own `docker-entrypoint-initdb.d`
convention) and creates:

- The four plaintext content tables (`companies`, `products`, `trends`,
  `innovations`) plus a synthetic churn table (`bench_keywords`) —
  `01_schema.sql`, `02_seed.sql`.
- The encrypted trie's tables (`enctrie_key_epochs`, `enctrie_nodes`,
  `enctrie_outbox`) — `03_enctrie_schema.sql`.
- The encrypted full-record retrieval table (`enctrie_records`) —
  `04_enctrie_records_schema.sql`.

Then the Go backend boots (`cmd/server/main.go`) and:

1. Connects to Postgres.
2. Loads or mints the first key **epoch** (§6).
3. Checks whether `enctrie_nodes` has rows for the current epoch — if not,
   runs a full build (§4.1).
4. Checks whether `enctrie_records` has rows for the current epoch — if
   not, runs a full build (§4.1).
5. Starts the outbox processor (§5.2), which keeps both tables in sync
   with any future writes.
6. Starts listening on `:8080`.

### 2.3 Configuration

| Variable | Purpose | Local-dev default |
|---|---|---|
| `MASTER_KEK_HEX` | 64-hex-char (32-byte) key that wraps every root key at rest. Generate a real one with `openssl rand -hex 32`. | A fixed insecure value — the server logs a warning if left unset. |
| `API_KEYS` | Comma-separated secrets required (via `X-API-Key`) for `/api/enc-key`, `/api/admin/*`, `/api/data/*` (write). | Empty — those endpoints stay open (with a warning header) so the demo works out of the box. |
| `DATABASE_URL` | Postgres connection string. | Points at the compose-managed `postgres` service. |

Nothing about the searchable-encryption design itself needs configuring
beyond this — the trie's structure, key derivation, and rotation policy
are fixed in code, not environment-tunable, on purpose (so there's one
correct way to run it, not a matrix of configurations to reason about).

---

## 3. The two encrypted data structures

Everything below lives in **one Postgres instance**, in two tables that
serve two different purposes:

```
enctrie_nodes                          enctrie_records
──────────────                         ────────────────
Purpose: autocomplete-as-you-type      Purpose: full retrieval of one item
Keyed by: every PREFIX of every        Keyed by: the exact, complete text
  keyword ("c","cl","cla",…,"claude")    of a keyword only ("claude")
Payload: lightweight — text/kind/      Payload: everything — description,
  subtitle for up to 8 matches           metadata, tags, for every item
                                          that shares that exact text
Trapdoor label: "td:e<epoch>:"         Trapdoor label: "rtd:e<epoch>:"
Key label: "node:e<epoch>:"            Key label: "rkey:e<epoch>:"
```

**Why two tables with two separate key-label namespaces, instead of one?**
A prefix lookup and a full-record lookup are different operations with
different sensitivity — a suggestion snippet is meant to be cheap and
disposable-looking, while a full record carries everything about an item.
Deriving them with different HMAC labels means a leaked prefix trapdoor
for "claude" and a leaked record trapdoor for "claude" are two unrelated
32-byte values; possessing one implies nothing about the other. This also
means the two tables could, in a hardened deployment, live behind
different access-control policies or even different storage tiers,
without the client needing to know or care.

**Why not just make the prefix node's payload richer instead of having a
second table?** Because a prefix node is intentionally an *aggregate* of
every keyword sharing that prefix (e.g. "cl" aggregates "Claude",
"Cloudflare", "Clockwork" together, capped at 8 items) — that's what makes
autocomplete-as-you-type cheap and useful. A retrieval needs the *one*
specific item the user picked, in full — a different query shape
entirely, keyed by exact text, not prefix.

### 3.1 The prefix trie, concretely: `enctrie_nodes`

```sql
CREATE TABLE enctrie_nodes (
    epoch      INTEGER     NOT NULL,
    trapdoor   CHAR(64)    NOT NULL,   -- hex(HMAC-SHA256(rootKey, "td:e<N>:"+prefix))
    prefix     TEXT        NOT NULL,   -- plaintext, builder-only (see §3.3)
    ciphertext BYTEA       NOT NULL,   -- AES-256-GCM(nodeKey, small suggestion list)
    PRIMARY KEY (epoch, trapdoor)
);
```

One row per prefix of every keyword. `PRIMARY KEY (epoch, trapdoor)` is a
B-tree index — every read is a single indexed point lookup, not a scan.

### 3.2 The exact-match record store: `enctrie_records`

```sql
CREATE TABLE enctrie_records (
    epoch      INTEGER     NOT NULL,
    trapdoor   CHAR(64)    NOT NULL,   -- hex(HMAC-SHA256(rootKey, "rtd:e<N>:"+exact_text))
    keyword    TEXT        NOT NULL,   -- plaintext exact text, builder-only
    ciphertext BYTEA       NOT NULL,   -- AES-256-GCM(recordKey, full result list, JSON)
    PRIMARY KEY (epoch, trapdoor)
);
```

One row per **distinct exact keyword** across all four content tables.
The ciphertext, once decrypted, is a JSON array of full result objects
(same shape `/api/search` returns: id, kind, title, subtitle, description,
badge, metadata, tags) — an array, not a single object, because more than
one item can legitimately share an exact name.

### 3.3 Why storing plaintext `prefix`/`keyword` columns is fine here

The Go backend is the **builder**: it already reads the plaintext content
tables directly to construct both encrypted tables in the first place.
Storing the plaintext prefix/keyword alongside the ciphertext, in the
*same trusted Postgres instance*, reveals nothing the builder didn't
already know. What searchable encryption protects here is the **query
path**: a client (browser) never sends plaintext to the server — it sends
only a trapdoor and a decryption key it derived locally. An observer of
the network traffic, or of the ciphertext tables in isolation, learns
nothing without the root key. If you need a stricter deployment where even
the storage tier shouldn't hold plaintext, project only
`(epoch, trapdoor, ciphertext)` to that tier and keep the plaintext
columns only in the trusted builder's own database — the code already
keeps these concerns separable.

---

## 4. The full pipeline: search → retrieval

This is the part that was incomplete before: autocomplete existed, but
nothing ever *retrieved* anything. Here is the complete, current flow,
end to end, for a user typing "claude" and pressing Enter.

```
BROWSER                                    SERVER (Postgres, single instance)
───────                                    ─────────────────────────────────

 GET /api/enc-key  ───────────────────────▶
                    ◀─────────────────────  { root_key_hex, epoch }
 (root key now held in browser memory only, for this session)

 user types "c"
   trapdoor = HMAC(rootKey, "td:e2:c")
   nodeKey  = HMAC(rootKey, "node:e2:c")
   GET /api/enc-suggest?td=..&nk=..&epoch=2 ▶
                                              SELECT ciphertext FROM enctrie_nodes
                                              WHERE epoch=2 AND trapdoor=<td>
                                              -- indexed point lookup, one row
                                              AES-256-GCM decrypt with nk
                    ◀─────────────────────  { suggestions: [...], found: true }
 (dropdown shows suggestions)

 user types "cl", "cla", "clau", "claud", "claude"
   (same round-trip repeats per keystroke, ~debounced 120ms)

 user selects "Claude" from the dropdown, OR presses Enter
   exactText = "claude" (lowercased)
   recordTrapdoor = HMAC(rootKey, "rtd:e2:claude")   ◀── DIFFERENT LABEL
   recordKey      = HMAC(rootKey, "rkey:e2:claude")  ◀── from the suggestion one
   GET /api/enc-record?td=..&rk=..&epoch=2  ▶
                                              SELECT ciphertext FROM enctrie_records
                                              WHERE epoch=2 AND trapdoor=<recordTrapdoor>
                                              -- indexed point lookup, one row
                                              AES-256-GCM decrypt with recordKey
                    ◀─────────────────────  { results: [{ id, title, description,
                                                            meta, tags, ... }],
                                               found: true }
 (full Card rendered — description, metadata, tags, exactly like the
  plain-search result Card)
```

Two properties worth being explicit about:

- **No plaintext ever crosses the wire from client to server**, at any
  step — not the typed prefix, not the selected item's name. The server
  only ever receives trapdoors (deterministic hashes) and decryption keys
  scoped to one ciphertext blob.
- **Retrieval requires an exact, indexed keyword.** Unlike the plain
  path's `ILIKE '%text%'`, which matches any substring anywhere, the
  encrypted path can only retrieve something whose *exact* text was
  walked into the trie at build/update time. You cannot "encrypted-search"
  for an arbitrary phrase that was never indexed — you can only
  autocomplete toward an indexed prefix, then retrieve that specific,
  now-known-exact item. This is an inherent trade-off of trapdoor-based
  search, not a missing feature, and the UI says so explicitly when a
  typed string doesn't match anything indexed.

### 4.1 The bug this replaced

Previously, selecting a suggestion (or pressing Enter) only ever set the
search box's text and closed the dropdown — there was no retrieval step
at all, anywhere in the code. `/api/enc-record`, `enctrie_records`, and
the `rtd:`/`rkey:` key derivations described above did not exist. This
document, and the code it describes, is that missing piece.

---

## 5. Building and maintaining the encrypted tables

### 5.1 Full rebuild — O(total content), run once at boot (or on demand)

```
loadAllKeywords()            -- one query across companies/products/trends/innovations
  → buildPrefixMap()         -- walk every prefix of every keyword, in Go, transiently
  → for each prefix:
      encrypt(nodeKey, suggestions) → INSERT INTO enctrie_nodes

loadDistinctKeywords()       -- one query, DISTINCT lower(text)
  → for each exact keyword:
      query full records sharing that exact text (exact-match SQL, not prefix)
      encrypt(recordKey, results) → INSERT INTO enctrie_records
```

Both run once at boot if their table is empty for the current epoch, and
can be re-triggered manually: `POST /api/admin/rebuild` (needs
`X-API-Key`), or `GET /api/bench/rebuild` for a timed, unauthenticated
version that returns the cost.

### 5.2 Add / delete data — how the trie actually refreshes

This is the piece most likely to cause confusion, so here it is in full,
for **both** the automatic path (any write to the content tables) and the
guided path (the "➕ Add Data" UI tab).

```
 Any INSERT/UPDATE/DELETE on
 companies / products / trends / innovations / bench_keywords
        │
        ▼
 Postgres trigger fires automatically
        │
        ▼
 INSERT INTO enctrie_outbox (source_table, op, keyword, old_keyword)
 pg_notify('enctrie_changes', ...)
        │
        ▼
 Go outbox processor (running continuously, LISTEN + poll fallback)
        │
        ├──▶ UpdateKeyword(epoch, oldText, newText)         -- enctrie_nodes
        │      touches only prefixes(oldText) ∪ prefixes(newText)
        │      re-queries Postgres for each touched prefix's CURRENT
        │      aggregate suggestion set, re-encrypts, upserts (or deletes
        │      the row if nothing shares that prefix anymore)
        │
        └──▶ UpdateRecordKeyword(epoch, oldText, newText)   -- enctrie_records
               same idea, but for the exact old/new text only (at most 2
               rows touched, not a whole prefix chain)
        │
        ▼
 Both run for every currently-valid epoch (not just the active one), so
 reads against a not-yet-retired grace-period epoch also stay correct.
```

**The guided "➕ Add Data" UI path does the same thing, faster, on
purpose:** `POST /api/data/{kind}` performs the real `INSERT` (which fires
the trigger above, same as any other write) **and additionally calls
`UpdateKeyword`/`UpdateRecordKeyword` directly, synchronously, in the same
request** — the identical functions the outbox calls asynchronously. This
means a guided add is searchable and fully retrievable **before the HTTP
response even comes back**, instead of only eventually via the outbox.
The response reports exactly how long each step took
(`pg_write_ms`, `trie_update_us`, `prefixes_touched`).

`DELETE /api/data/{kind}/{id}` is the mirror: deletes the row (trigger
fires the same way), then calls both update functions with the old text
and an empty new text — which removes the prefix/record rows entirely if
no other item still shares that text, or shrinks the aggregate down if
something else does.

Try it yourself: the ➕ Add Data tab shows the exact cost of each step for
whatever you add, then immediately re-queries both `/api/suggest` and
`/api/enc-suggest` (and, per §4, you can then select the result to trigger
`/api/enc-record`) to prove the new item is live.

---

## 6. Key rotation, end to end

```
 epoch 1 "active"        keys.Store.Rotate(grace)         epoch 1 "grace"
 ─────────────────────────────┬──────────────────────────────┬───────────
                               │                              │
                    mint epoch 2 (new random root key,   grace window
                    wrapped under the KEK before          elapses:
                    ever touching disk)                   PruneExpired()
                    epoch 1 demoted to "grace" with        deletes epoch 1's
                    a retire_after deadline                key row — CASCADE
                               │                            deletes every
                               ▼                            epoch-1 row in
                    RotateReencrypt (enctrie_nodes)         enctrie_nodes AND
                    RotateReencryptRecords (enctrie_records)enctrie_records
                    — both STREAM existing ciphertext        permanently
                    out of Postgres, decrypt with the
                    OLD key, re-encrypt with the NEW
                    key, write back — never re-reads
                    the plaintext content tables
```

**Why both tables must rotate together:** a client that fetched its root
key just before a rotation still has valid epoch-N derivations for both
namespaces (`td:`/`node:` and `rtd:`/`rkey:`) — if only one table rotated,
autocomplete and retrieval would fall out of sync with each other for that
client during the grace window. `AdminRotate`/`BenchRotate` always call
both `RotateReencrypt` and `RotateReencryptRecords` in the same request.

**Dual-key reads during the grace window:** both `EncSuggest` and
`EncRecord` accept an optional `epoch` parameter. If given, it's a direct
indexed lookup. If omitted, the server tries every currently-valid epoch
(active + grace) via a secondary index on `trapdoor` alone — in practice
1–2 epochs, so still cheap.

**The step that makes rotation actually mean something:** `PruneExpired`,
run on a 30-second ticker, deletes any epoch whose grace window has
elapsed. This isn't just "stop using the old key" — the key material and
every row encrypted under it are gone, permanently, from Postgres. That's
what bounds the blast radius of a leaked key to one rotation's grace
window, not "forever, unless someone remembers to clean it up."

Trigger a rotation yourself: the Latency Benchmark tab → Lifecycle
benchmarks → "Rotate keys" (10-second grace window, so you can watch
`/api/health` lose the old epoch a few seconds later), or
`POST /api/admin/rotate?grace_seconds=86400` for a production-realistic
window.

---

## 7. What's still a deliberate demo simplification

`GET /api/enc-key` hands the raw root key to whoever calls it. Client-side
key derivation (the browser computing HMACs locally) is the *correct*
half of this design — it's what keeps the server from ever seeing
plaintext. What's missing for production is **who is allowed to ask for a
key and what they get**: real deployments should put real session
authentication in front of this endpoint (not the placeholder
`X-API-Key` check used here), issue short-lived keys scoped to one
tenant/session, and rotate them far more often than the trie's own
encryption epoch. See `ARCHITECTURE.md` §7 for the full discussion.

---

## 8. Where to look in the code

| Concept | File |
|---|---|
| Key derivation (all four label namespaces) | `backend/internal/keys/keys.go` |
| Prefix trie build/update/rotate/query | `backend/internal/enctrie/enctrie.go` |
| Record store build/update/rotate/query | `backend/internal/enctrie/records.go` |
| Change capture (triggers → outbox → both update functions) | `postgres/init/03_enctrie_schema.sql`, `backend/internal/outbox/outbox.go` |
| HTTP handlers (`/api/enc-suggest`, `/api/enc-record`, `/api/data/*`) | `backend/internal/handlers/handlers.go`, `data.go` |
| Client-side HMAC + the full search→retrieve flow | `frontend/src/hooks/useEncSearch.ts`, `frontend/src/App.tsx` (`EncryptedSearchTab`) |
