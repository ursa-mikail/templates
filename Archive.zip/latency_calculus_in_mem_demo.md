# Latency Calculus: Plain Postgres vs Encrypted Trie

## Why the encrypted trie is 200–460× faster

These numbers are not a bug. They measure fundamentally different things.

---

## The two systems being compared

### Plain Postgres (`/api/suggest`)

```
Browser keystroke
  → Go handler receives HTTP request
  → Go opens connection from pool (or waits for one)
  → Go serialises SQL query string
  → TCP packet: Go → Postgres (loopback, ~0.05ms)
  → Postgres parses query
  → Postgres checks query cache (likely miss on first run)
  → Postgres runs ILIKE scan on GIN index
  → Postgres serialises result rows
  → TCP packet: Postgres → Go (loopback, ~0.05ms)
  → Go deserialises rows, builds []Suggestion
  → Go serialises JSON response
  → HTTP response to browser
```

**Every query crosses the process boundary at least twice** (Go → Postgres → Go).
Even on localhost this costs ~0.1–0.5ms of pure I/O wait before any computation.

### Encrypted Trie (`/api/enc-suggest`)

```
Browser keystroke
  → Web Crypto: HMAC-SHA256(rootKey, "td:"+prefix)  [in-browser]
  → Web Crypto: HMAC-SHA256(rootKey, "node:"+prefix) [in-browser]
  → Go handler receives HTTP request
  → map lookup: nodes[trapdoor]                       [O(1), in-memory]
  → AES-256-GCM decrypt(nodeKey, ciphertext)          [in-memory]
  → JSON unmarshal of decrypted payload
  → HTTP response to browser
```

**Zero network I/O after the initial request reaches Go.** The entire operation is:
- one Go `sync.RWMutex` read lock
- one `map[string][]byte` lookup (hash map, O(1))
- one AES-256-GCM block cipher operation (~1–5µs for <1KB payload)
- one `json.Unmarshal` of a small struct

---

## Latency breakdown by component

### Plain Postgres — observed p50 ≈ 690µs

| Component | Estimated cost | Notes |
|-----------|---------------|-------|
| Go HTTP parse + route | ~5µs | net/http mux lookup |
| Connection pool acquire | ~10–50µs | varies with pool pressure |
| Query serialisation | ~2µs | string formatting |
| Loopback TCP round-trip (×2) | ~100–200µs | Go→PG, PG→Go |
| Postgres query parse + plan | ~50–100µs | ILIKE plan is simple but not free |
| GIN index scan (pg_trgm) | ~200–400µs | 4-table UNION ALL |
| Row deserialisation in Go | ~5–10µs | up to 8 rows |
| JSON marshal | ~5µs | |
| **Total (model)** | **~377–772µs** | matches observed 458–690µs |

### Encrypted Trie — observed p50 ≈ 3µs

| Component | Estimated cost | Notes |
|-----------|---------------|-------|
| Go HTTP parse + route | ~1µs | faster path, no SQL |
| `sync.RWMutex` RLock | <0.1µs | uncontended |
| `map[string][]byte` lookup | ~0.1µs | O(1) hash map |
| AES-256-GCM decrypt | ~1–3µs | ~100–500 bytes payload |
| `json.Unmarshal` | ~0.5–1µs | small struct |
| JSON marshal response | ~0.5µs | |
| **Total (model)** | **~3–6µs** | matches observed 3–22µs (p50–p90) |

---

## Why the min is 0µs for the encrypted trie

Go's `time.Since()` has ~1µs resolution on most platforms. Calls that complete
in under 1µs get rounded to 0. The AES-GCM operation on a cached, warm key
genuinely runs in ~200–500ns — below the timer's measurement floor.

For accuracy at this scale you would use `runtime/trace` or
`time.Now().UnixNano()` with the Go perf clock.

---

## Latency formula derivation

### Plain Postgres latency model

```
L_plain = T_go_overhead
        + T_pool_acquire
        + T_loopback × 2
        + T_pg_parse
        + T_pg_plan
        + T_pg_scan(N_rows, idx_type)
        + T_deser(N_rows)
        + T_json_marshal

Where:
  T_go_overhead  ≈ 5–10µs      (HTTP parse, mux, handler dispatch)
  T_pool_acquire ≈ 10–100µs    (connection wait; 0 if pool idle)
  T_loopback     ≈ 50–150µs    (per direction, Docker bridge or host loopback)
  T_pg_parse     ≈ 10–30µs     (query parse + bind)
  T_pg_plan      ≈ 20–80µs     (plan cache hit: ~5µs, miss: ~80µs)
  T_pg_scan      ≈ 100–400µs   (GIN trigram scan, 4-table UNION ALL)
  T_deser        ≈ 2–10µs      (N_rows × ~1µs per row)
  T_json_marshal ≈ 3–8µs
```

**Lower bound** (pool hot, plan cached, 0 rows):
```
L_plain_min ≈ 10 + 0 + 100 + 10 + 5 + 50 + 0 + 3 = 178µs
```

**p50 observed: 690µs** — plan cache misses + GIN scan over 4 tables dominate.

**p99 spike to 6.26ms** — Postgres autovacuum, checkpoint I/O, or GIN index
consolidation running concurrently. Normal for a development Postgres instance
with no tuning (`work_mem`, `shared_buffers` at defaults).

---

### Encrypted trie latency model

```
L_enc = T_go_overhead
      + T_mutex_rlock
      + T_map_lookup
      + T_aes_gcm(len_bytes)
      + T_json_unmarshal
      + T_json_marshal_response

Where:
  T_go_overhead      ≈ 1–2µs
  T_mutex_rlock      ≈ 0.05–0.1µs   (uncontended RWMutex read)
  T_map_lookup       ≈ 0.05–0.2µs   (O(1) hash map, 64-byte key)
  T_aes_gcm(B)       ≈ B / 500MB/s  (AES-NI: ~0.2µs for 100B, ~1µs for 500B)
  T_json_unmarshal   ≈ 0.3–1µs      (small nodePayload struct)
  T_json_marshal     ≈ 0.3–1µs
```

**Lower bound**:
```
L_enc_min ≈ 1 + 0.1 + 0.1 + 0.2 + 0.3 + 0.3 = ~2µs
```

**p50 observed: 3µs** — consistent with the model. ✓

**p90 at 22µs** — Go runtime GC pauses, OS scheduler jitter, or the HTTP
request arriving during a brief stop-the-world. These dominate at this scale.

---

## Why p99 diverges so much

| Metric | Plain | Encrypted | Ratio |
|--------|-------|-----------|-------|
| p50 | 690µs | 3µs | 230× |
| p90 | 1.13ms | 22µs | 51× |
| p99 | 6.26ms | 145µs | 43× |

**Plain Postgres p99** is dominated by Postgres internals: checkpoint writes,
BGWriter contention, lock acquisition, autovacuum. These are rare but expensive
(1–10ms spikes). The encrypted trie bypasses all of this entirely.

**Encrypted trie p99** is dominated by Go GC and OS scheduling. A 145µs p99
is typical for a Go HTTP handler that allocates a few objects — the GC may
pause the goroutine briefly during a minor collection.

---

## What this means in practice

| Scenario | Right choice | Why |
|----------|-------------|-----|
| Need freshest data (live DB updates) | Plain Postgres | Trie is built at startup, stale until rebuild |
| Maximum autocomplete speed | Encrypted Trie | 200× faster, no DB round-trip |
| Search arbitrary new strings | Plain Postgres | Trie only covers pre-built prefixes |
| Zero-knowledge server (privacy) | Encrypted Trie | Server holds only AES-GCM ciphertext |
| Horizontal scaling | Encrypted Trie | Stateless per-node, just replicate the trie |
| Complex ranking (ts_rank, similarity) | Plain Postgres | Trie returns pre-ranked suggestions only |

---

## Rebuild cost of the encrypted trie

When new data is inserted into Postgres, the trie must be rebuilt:

```
T_rebuild = T_load_keywords + T_build_prefixes + T_aes_encrypt × N_nodes

Where for 80 keywords (current dataset):
  T_load_keywords  ≈ 2–5ms   (one Postgres query)
  T_build_prefixes ≈ 0.5ms   (trie construction in Go)
  N_nodes          ≈ 800–1200 (every unique prefix of every keyword)
  T_aes_encrypt    ≈ 1–2µs   per node
  T_encrypt_total  ≈ 1–2ms

Total rebuild: ~5–10ms — can run in the background without blocking queries.
```

The rebuild is triggered at startup and can be re-triggered via a background
goroutine on a timer or database LISTEN/NOTIFY event.

---

## Summary

```
Plain Postgres:   [HTTP] → [pool] → [loopback×2] → [GIN scan] → [deser] → [JSON]
                    5µs      50µs      200µs          300µs        10µs      5µs
                  = ~570µs baseline (p50 ≈ 690µs observed)

Encrypted Trie:   [HTTP] → [map O(1)] → [AES-GCM] → [JSON]
                    2µs       0.1µs         1µs         0.5µs
                  = ~3.6µs baseline (p50 ≈ 3µs observed)

Speedup at p50:  690µs / 3µs ≈ 230×

Root cause of the gap: Postgres requires two process-boundary crossings
and a disk-backed index scan. The encrypted trie is pure in-memory computation
with no I/O and no syscalls beyond the HTTP receive itself.
```
