package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

func main() {
	fmt.Println(banner("Key Lifecycle Management Demo"))

	// ── 1. Bootstrap master authorization key ────────────────────────────────
	fmt.Println("\n▶ Step 1 – Bootstrapping master authorization key")
	master, err := NewMasterKey("master-auth-key-001")
	must(err)
	fmt.Printf("  Master key ID  : %s\n", master.ID)
	fmt.Printf("  Master pub key : %s...\n", master.PublicKeyBase64()[:24])

	// ── 2. Load state machine definition ─────────────────────────────────────
	fmt.Println("\n▶ Step 2 – Loading state machine from statemachine.json")
	lm, err := NewLifecycleManager("statemachine.json", master)
	must(err)
	fmt.Printf("  SM description : %s\n", lm.sm.Description())

	// ── 3. Generate keys of each type ────────────────────────────────────────
	fmt.Println("\n▶ Step 3 – Generating managed keys")

	keys := []struct {
		id  string
		kt  KeyType
		ttl time.Duration
	}{
		{"ecdsa-signing-01", KeyTypeECDSA, 365 * 24 * time.Hour},
		{"eddsa-signing-01", KeyTypeEdDSA, 180 * 24 * time.Hour},
		{"rsa-signing-01", KeyTypeRSA, 730 * 24 * time.Hour},
	}

	records := make([]*KeyRecord, 0, len(keys))
	for _, k := range keys {
		rec, err := GenerateKey(k.id, k.kt, k.ttl, master)
		must(err)
		fmt.Printf("  %-20s  type=%-12s  state=%s  fp=%s\n",
			rec.KeyID, rec.KeyType, rec.Lifecycle.State, Fingerprint(rec.PublicKey))

		// Verify signature straight away
		must(master.Verify(*rec))
		records = append(records, rec)

		// Persist initial record
		path := filepath.Join("keys", rec.KeyID+".json")
		os.MkdirAll("keys", 0700)
		must(SaveRecord(path, rec))
	}

	// ── 4. Walk through a full lifecycle for the ECDSA key ───────────────────
	fmt.Println("\n▶ Step 4 – ECDSA key full lifecycle walk-through")
	ecKey := records[0]

	type step struct {
		action string
		actor  string
		reason string
	}
	steps := []step{
		{"distribute", "admin@example.com", "initial distribution to HSM pool"},
		{"activate",   "admin@example.com", "installed and verified on node-1"},
		{"suspend",    "security@example.com", "incident INC-4471 investigation"},
		{"reactivate", "security@example.com", "investigation closed – key clean"},
		{"deactivate", "admin@example.com", "scheduled rotation"},
		{"archive",    "admin@example.com", "retained for signature verification"},
	}

	for _, s := range steps {
		prev := ecKey.Lifecycle.State
		if err := lm.Transition(ecKey, s.action, s.actor, s.reason); err != nil {
			fmt.Printf("  ✗ [%s] %s → ? : %v\n", s.action, prev, err)
			continue
		}
		fmt.Printf("  ✓ [%-12s] %-14s → %-14s  (by %s)\n",
			s.action, prev, ecKey.Lifecycle.State, s.actor)
		must(SaveRecord(filepath.Join("keys", ecKey.KeyID+".json"), ecKey))
	}

	// ── 5. Focused suspend / reactivate demo on EdDSA key with history log ───
	fmt.Println("\n▶ Step 5 – EdDSA key: suspend → reactivate (with signed history log)")
	edKey := records[1]

	edSteps := []step{
		{"distribute",  "admin@example.com",    "distributed for signing service"},
		{"activate",    "admin@example.com",    "installed on signing node-2"},
		{"suspend",     "security@example.com", "INCIDENT-8821: suspected key exposure"},
		{"reactivate",  "security@example.com", "INCIDENT-8821 closed – key confirmed clean"},
		{"suspend",     "security@example.com", "scheduled 30-day audit window"},
		{"reactivate",  "security@example.com", "audit complete – no anomalies"},
		{"deactivate",  "admin@example.com",    "end of validity period"},
		{"destroy",     "admin@example.com",    "secure wipe confirmed on HSM"},
	}
	for _, s := range edSteps {
		prev := edKey.Lifecycle.State
		if err := lm.Transition(edKey, s.action, s.actor, s.reason); err != nil {
			fmt.Printf("  ✗ [%s] %s → ? : %v\n", s.action, prev, err)
			continue
		}
		latest := edKey.Lifecycle.History[len(edKey.Lifecycle.History)-1]
		fmt.Printf("  ✓ [%-12s] %-14s → %-14s  actor=%-28s  sig=%s…\n",
			s.action, prev, edKey.Lifecycle.State,
			latest.Actor, edKey.Signature[:20])
	}

	// Attempt transition after terminal state
	fmt.Print("\n  ✗ Attempt 'distribute' after destroyed: ")
	err = lm.Transition(edKey, "distribute", "attacker", "sneak")
	if err != nil {
		fmt.Println(err)
	}
	must(SaveRecord(filepath.Join("keys", edKey.KeyID+".json"), edKey))

	// Print the full signed history log for the EdDSA key
	fmt.Println("\n  ── Signed history log embedded in EdDSA key record ──")
	printHistory(edKey)

	// ── 6. Demonstrate tamper detection ──────────────────────────────────────
	fmt.Println("\n▶ Step 6 – Tamper detection")
	rsaKey := records[2]
	must(lm.Transition(rsaKey, "distribute", "admin@example.com", "initial"))
	must(lm.Transition(rsaKey, "activate", "admin@example.com", "online"))

	// Tamper: manually change state without re-signing
	rsaKey.Lifecycle.State = "compromised"
	err = lm.Transition(rsaKey, "destroy", "attacker@evil.com", "cover tracks")
	fmt.Printf("  Tamper detected: %v\n", err)

	// ── 7. Print final ECDSA record JSON ─────────────────────────────────────
	fmt.Println("\n▶ Step 7 – Final ECDSA key record (JSON, public key truncated)")
	display := *ecKey
	display.PublicKey = "<truncated>"
	pretty, _ := json.MarshalIndent(display, "  ", "  ")
	fmt.Println("  " + string(pretty))

	// ── 8. Reload from disk and verify ───────────────────────────────────────
	fmt.Println("\n▶ Step 8 – Reload ECDSA key from disk, verify signature, print history")
	loaded, err := LoadRecord(filepath.Join("keys", "ecdsa-signing-01.json"))
	must(err)
	if err := master.Verify(*loaded); err != nil {
		fmt.Printf("  ✗ Signature invalid: %v\n", err)
	} else {
		fmt.Printf("  ✓ Signature valid. State=%s  History entries=%d\n",
			loaded.Lifecycle.State, len(loaded.Lifecycle.History))
		printHistory(loaded)
	}

	// ── 9. Show allowed actions from each state ───────────────────────────────
	fmt.Println("\n▶ Step 9 – Allowed actions from each state")
	for _, state := range []string{"generated", "ready", "active", "suspended", "deactivated", "destroyed", "archived"} {
		dummy := &KeyRecord{Lifecycle: KeyLifecycle{State: state}}
		actions := lm.AllowedActions(dummy)
		fmt.Printf("  %-14s → [%s]\n", state, strings.Join(actions, ", "))
	}

	fmt.Println("\n✅  Demo complete. Key records written to ./keys/")
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

func must(err error) {
	if err != nil {
		fmt.Fprintf(os.Stderr, "FATAL: %v\n", err)
		os.Exit(1)
	}
}

func banner(s string) string {
	line := strings.Repeat("─", len(s)+4)
	return fmt.Sprintf("\n┌%s┐\n│  %s  │\n└%s┘", line, s, line)
}

// printHistory prints the tamper-evident history log embedded in a key record.
// Every entry was covered by the master signature at the time of the transition,
// so altering any event would invalidate the current signature.
func printHistory(rec *KeyRecord) {
	fmt.Printf("  ┌── History log for key %q (signed by %s) ──\n", rec.KeyID, rec.SignedBy)
	for i, e := range rec.Lifecycle.History {
		from := e.FromState
		if from == "" {
			from = "(none)"
		}
		fmt.Printf("  │ %2d. %-26s  %-14s → %-14s\n",
			i+1, e.Timestamp.Format("2006-01-02 15:04:05"), from, e.ToState)
		fmt.Printf("  │     action=%-12s  actor=%s\n", e.Action, e.Actor)
		if e.Reason != "" {
			fmt.Printf("  │     reason=%s\n", e.Reason)
		}
	}
	fmt.Printf("  └── sig=%s…\n", rec.Signature[:32])
}
