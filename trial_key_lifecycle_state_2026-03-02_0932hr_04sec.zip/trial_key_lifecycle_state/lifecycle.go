package main

import (
	"encoding/json"
	"fmt"
	"os"
	"time"
)

// LifecycleManager wires together the state machine and master authorization key
type LifecycleManager struct {
	sm     *StateMachine
	master *MasterKey
}

// NewLifecycleManager creates a manager from a state machine file and master key
func NewLifecycleManager(smPath string, master *MasterKey) (*LifecycleManager, error) {
	sm, err := LoadStateMachine(smPath)
	if err != nil {
		return nil, err
	}
	return &LifecycleManager{sm: sm, master: master}, nil
}

// Transition applies a lifecycle action to a key record, re-signs with the master key,
// and writes the updated record back to disk (if a path is provided).
//
// Steps:
//  1. Verify the existing master signature – reject tampered records
//  2. Ask the state machine if the action is valid from the current state
//  3. Update the lifecycle fields and append a history event
//  4. Re-sign the updated record with the master key
func (lm *LifecycleManager) Transition(rec *KeyRecord, action, actor, reason string) error {
	// ── 1. Verify existing signature ─────────────────────────────────────────
	if err := lm.master.Verify(*rec); err != nil {
		return fmt.Errorf("authorization check failed: %w", err)
	}

	// ── 2. Validate state transition ─────────────────────────────────────────
	oldState := rec.Lifecycle.State
	newState, err := lm.sm.Apply(oldState, action)
	if err != nil {
		return fmt.Errorf("state machine rejected transition: %w", err)
	}

	// ── 3. Mutate lifecycle ───────────────────────────────────────────────────
	now := time.Now().UTC()
	rec.Lifecycle.State = newState
	rec.Lifecycle.UpdatedAt = now
	rec.Lifecycle.History = append(rec.Lifecycle.History, Event{
		Timestamp: now,
		Action:    action,
		FromState: oldState,
		ToState:   newState,
		Actor:     actor,
		Reason:    reason,
	})

	// ── 4. Re-sign ────────────────────────────────────────────────────────────
	if err := lm.master.Sign(rec); err != nil {
		return fmt.Errorf("re-sign after transition: %w", err)
	}
	return nil
}

// AllowedActions returns the actions available from the record's current state
func (lm *LifecycleManager) AllowedActions(rec *KeyRecord) []string {
	return lm.sm.AllowedActions(rec.Lifecycle.State)
}

// ─────────────────────────────────────────────────────────────────────────────
// JSON persistence helpers
// ─────────────────────────────────────────────────────────────────────────────

// SaveRecord writes a KeyRecord as pretty-printed JSON to path
func SaveRecord(path string, rec *KeyRecord) error {
	data, err := json.MarshalIndent(rec, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0600)
}

// LoadRecord reads a KeyRecord from a JSON file
func LoadRecord(path string) (*KeyRecord, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var rec KeyRecord
	if err := json.Unmarshal(data, &rec); err != nil {
		return nil, err
	}
	return &rec, nil
}
