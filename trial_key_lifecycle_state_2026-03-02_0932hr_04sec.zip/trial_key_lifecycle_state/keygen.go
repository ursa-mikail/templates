package main

import (
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"time"

	"crypto/sha256"
)

// GenerateKey creates a new managed KeyRecord for the requested algorithm,
// signs it with the master key, and returns it in the "generated" initial state.
func GenerateKey(id string, kt KeyType, ttl time.Duration, master *MasterKey) (*KeyRecord, error) {
	pubPEM, err := generatePublicKeyPEM(kt)
	if err != nil {
		return nil, err
	}

	now := time.Now().UTC()
	rec := &KeyRecord{
		KeyID:     id,
		KeyType:   kt,
		PublicKey: pubPEM,
		Lifecycle: KeyLifecycle{
			State:       "generated",
			CreatedAt:   now,
			UpdatedAt:   now,
			ExpiresAt:   now.Add(ttl),
			Description: fmt.Sprintf("Managed %s signing key", kt),
			History: []Event{
				{
					Timestamp: now,
					Action:    "generate",
					FromState: "",
					ToState:   "generated",
					Actor:     master.ID,
					Reason:    "initial key generation",
				},
			},
		},
	}

	if err := master.Sign(rec); err != nil {
		return nil, fmt.Errorf("sign new key record: %w", err)
	}
	return rec, nil
}

// generatePublicKeyPEM generates a key pair and returns the public key in PEM
// (for ECDSA / RSA) or base64url (for Ed25519, which has no standard PEM type
// in older Go stdlib versions).
func generatePublicKeyPEM(kt KeyType) (string, error) {
	switch kt {
	case KeyTypeECDSA:
		priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
		if err != nil {
			return "", err
		}
		der, err := x509.MarshalPKIXPublicKey(&priv.PublicKey)
		if err != nil {
			return "", err
		}
		return string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: der})), nil

	case KeyTypeEdDSA:
		pub, _, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return "", err
		}
		// Encode as base64url for compactness; still verifiable
		return base64.RawURLEncoding.EncodeToString(pub), nil

	case KeyTypeRSA:
		priv, err := rsa.GenerateKey(rand.Reader, 2048)
		if err != nil {
			return "", err
		}
		der, err := x509.MarshalPKIXPublicKey(&priv.PublicKey)
		if err != nil {
			return "", err
		}
		return string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: der})), nil

	default:
		return "", fmt.Errorf("unsupported key type: %s", kt)
	}
}

// Fingerprint returns the SHA-256 fingerprint of the public key bytes
func Fingerprint(pubPEM string) string {
	h := sha256.Sum256([]byte(pubPEM))
	return fmt.Sprintf("SHA256:%x", h[:8]) // short fingerprint for display
}
