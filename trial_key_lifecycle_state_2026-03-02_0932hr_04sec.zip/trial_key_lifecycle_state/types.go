package main

import "time"

// ─────────────────────────────────────────────────────────────────────────────
// State Machine types
// ─────────────────────────────────────────────────────────────────────────────

// Transition defines a single allowed state change
type Transition struct {
	ID          string `json:"id"`
	From        string `json:"from"`
	To          string `json:"to"`
	Action      string `json:"action"`
	Description string `json:"description"`
}

// StateMachineDefinition is loaded from statemachine.json
type StateMachineDefinition struct {
	Version        string       `json:"version"`
	Description    string       `json:"description"`
	States         []string     `json:"states"`
	InitialState   string       `json:"initial_state"`
	TerminalStates []string     `json:"terminal_states"`
	Transitions    []Transition `json:"transitions"`
}

// ─────────────────────────────────────────────────────────────────────────────
// Key Record types  (stored/serialised as JSON)
// ─────────────────────────────────────────────────────────────────────────────

// KeyType enumerates supported asymmetric algorithms
type KeyType string

const (
	KeyTypeECDSA KeyType = "ECDSA-P256"
	KeyTypeEdDSA KeyType = "Ed25519"
	KeyTypeRSA   KeyType = "RSA-2048"
)

// KeyLifecycle carries lifecycle metadata embedded inside the key record
type KeyLifecycle struct {
	State       string    `json:"state"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
	ExpiresAt   time.Time `json:"expires_at,omitempty"`
	Description string    `json:"description,omitempty"`
	History     []Event   `json:"history"`
}

// Event records a single state transition
type Event struct {
	Timestamp time.Time `json:"timestamp"`
	Action    string    `json:"action"`
	FromState string    `json:"from_state"`
	ToState   string    `json:"to_state"`
	Actor     string    `json:"actor"`
	Reason    string    `json:"reason,omitempty"`
}

// KeyRecord is the full JSON document describing one managed key.
// The "signature" field is a detached JWS-like base64url signature produced
// by the master authorization key over the canonical (signature-stripped) JSON.
type KeyRecord struct {
	KeyID      string       `json:"key_id"`
	KeyType    KeyType      `json:"key_type"`
	PublicKey  string       `json:"public_key"`  // PEM or base64url depending on algorithm
	Lifecycle  KeyLifecycle `json:"lifecycle"`
	Signature  string       `json:"signature,omitempty"`  // master sig over payload
	SignedBy   string       `json:"signed_by,omitempty"` // master key id
}
