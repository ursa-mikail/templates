package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
)

// MasterKey holds the master Ed25519 signing key used to authorize key records
// and lifecycle state transitions.
type MasterKey struct {
	ID         string
	publicKey  ed25519.PublicKey
	privateKey ed25519.PrivateKey
}

// NewMasterKey generates a fresh Ed25519 master key
func NewMasterKey(id string) (*MasterKey, error) {
	pub, priv, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		return nil, fmt.Errorf("generate master key: %w", err)
	}
	return &MasterKey{ID: id, publicKey: pub, privateKey: priv}, nil
}

// PublicKeyBase64 returns the base64url-encoded public key (for display / embedding)
func (m *MasterKey) PublicKeyBase64() string {
	return base64.RawURLEncoding.EncodeToString(m.publicKey)
}

// ─────────────────────────────────────────────────────────────────────────────
// Signing helpers
// ─────────────────────────────────────────────────────────────────────────────

// payloadBytes returns the canonical JSON byte slice of a KeyRecord with the
// Signature field cleared, suitable for signing / verifying.
func payloadBytes(rec KeyRecord) ([]byte, error) {
	rec.Signature = ""
	rec.SignedBy = ""
	data, err := json.Marshal(rec)
	if err != nil {
		return nil, err
	}
	return data, nil
}

// Sign signs the key record with the master key, embedding the signature.
func (m *MasterKey) Sign(rec *KeyRecord) error {
	payload, err := payloadBytes(*rec)
	if err != nil {
		return fmt.Errorf("marshal for signing: %w", err)
	}
	// Hash first so the signature covers a fixed-size digest (standard practice)
	digest := sha256.Sum256(payload)
	sig := ed25519.Sign(m.privateKey, digest[:])
	rec.Signature = base64.RawURLEncoding.EncodeToString(sig)
	rec.SignedBy = m.ID
	return nil
}

// Verify checks the embedded signature of a key record.
func (m *MasterKey) Verify(rec KeyRecord) error {
	sigBytes, err := base64.RawURLEncoding.DecodeString(rec.Signature)
	if err != nil {
		return fmt.Errorf("decode signature: %w", err)
	}
	payload, err := payloadBytes(rec)
	if err != nil {
		return fmt.Errorf("marshal for verification: %w", err)
	}
	digest := sha256.Sum256(payload)
	if !ed25519.Verify(m.publicKey, digest[:], sigBytes) {
		return fmt.Errorf("signature verification FAILED – record has been tampered")
	}
	return nil
}
