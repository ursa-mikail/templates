module keylifecycle

go 1.21
