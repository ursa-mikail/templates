package main

import (
	"encoding/json"
	"fmt"
	"os"
)

// StateMachine wraps a loaded definition and provides transition logic
type StateMachine struct {
	def StateMachineDefinition
	// index: "from:action" -> Transition
	index map[string]Transition
}

// LoadStateMachine reads statemachine.json from disk
func LoadStateMachine(path string) (*StateMachine, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read state machine: %w", err)
	}
	var def StateMachineDefinition
	if err := json.Unmarshal(data, &def); err != nil {
		return nil, fmt.Errorf("parse state machine: %w", err)
	}
	sm := &StateMachine{def: def, index: make(map[string]Transition)}
	for _, t := range def.Transitions {
		key := t.From + ":" + t.Action
		sm.index[key] = t
	}
	return sm, nil
}

// Apply validates the action and returns the next state (does NOT mutate the record).
// Returns an error if the transition is not allowed from the current state.
func (sm *StateMachine) Apply(currentState, action string) (string, error) {
	if sm.IsTerminal(currentState) {
		return "", fmt.Errorf("state %q is terminal – no further transitions allowed", currentState)
	}
	key := currentState + ":" + action
	t, ok := sm.index[key]
	if !ok {
		return "", fmt.Errorf("action %q is not allowed from state %q", action, currentState)
	}
	return t.To, nil
}

// IsTerminal returns true for states that cannot be left
func (sm *StateMachine) IsTerminal(state string) bool {
	for _, s := range sm.def.TerminalStates {
		if s == state {
			return true
		}
	}
	return false
}

// AllowedActions returns the list of actions available from a given state
func (sm *StateMachine) AllowedActions(state string) []string {
	var out []string
	for _, t := range sm.def.Transitions {
		if t.From == state {
			out = append(out, t.Action)
		}
	}
	return out
}

// Description returns the state machine description string
func (sm *StateMachine) Description() string { return sm.def.Description }
