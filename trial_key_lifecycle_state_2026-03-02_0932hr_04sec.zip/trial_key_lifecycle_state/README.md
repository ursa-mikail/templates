# Key Lifecycle Management Demo (Go)

A self-contained Go demo of cryptographic key lifecycle management for ECDSA,
EdDSA (Ed25519), and RSA signing keys, with a JSON-driven state machine and
master-key-based authorization.

## Quick Start

```bash
cd keylifecycle
go run .
```

No external dependencies – standard library only.

## File Overview

| File | Purpose |
|------|---------|
| `main.go` | Demo entrypoint – runs through full lifecycle scenarios |
| `types.go` | Shared data types (KeyRecord, Event, StateMachineDef, …) |
| `keygen.go` | Key generation for ECDSA-P256, Ed25519, RSA-2048 |
| `master.go` | Master Ed25519 authorization key – sign & verify key records |
| `lifecycle.go` | LifecycleManager – verify → apply state machine → re-sign |
| `statemachine.go` | Load statemachine.json, enforce transitions |
| `statemachine.json` | **Editable** state machine definition (states + transitions) |
| `go.mod` | Module file (stdlib only) |

## Architecture

```
statemachine.json         (editable – defines allowed state transitions)
       │
       ▼
StateMachine             (loads + indexes transitions)
       │
LifecycleManager  ◄──── MasterKey (Ed25519)
       │                    │
       │  1. Verify sig      │ Signs/re-signs KeyRecord
       │  2. Apply SM rule   │
       │  3. Append history  │
       │  4. Re-sign         │
       ▼
  KeyRecord JSON  (persisted to ./keys/<id>.json)
```

## Lifecycle States (from statemachine.json)

```
generated ──(distribute)──▶ ready ──(activate)──▶ active
                                                     │    │
                                              (suspend)  (compromise)
                                                     │
                                                suspended ──(reactivate)──▶ active
                                                     │
                                              (deactivate)
                                                     │
                                                deactivated ──(archive)──▶ archived
                                                     │
                                                 (destroy)
                                                     │
                                                 destroyed  ← terminal
```

### Key Suspension

Keys can be suspended (e.g. for security audits or incident response) and then
**re-activated** if cleared. This is controlled by two transitions:

- `active` → `suspend` → `suspended`
- `suspended` → `reactivate` → `active`
- `suspended` → `deactivate` → `deactivated`  (if not cleared)
- `suspended` → `compromise` → `compromised`  (if confirmed bad)

## Authorization Model

Every state transition:

1. **Verifies the existing Ed25519 master signature** over the canonical
   (signature-stripped) JSON of the record.  Tampered records are rejected.

2. **Validates the action** against the state machine definition – invalid
   transitions (e.g. `destroy` from `generated`) are rejected.

3. **Re-signs** the updated record, producing a new signature that covers the
   new state and the appended history event.

The master key is the root of trust. In production you would load it from an
HSM or KMS rather than generating it ephemerally.

## Customising the State Machine

Edit `statemachine.json` to add/remove states or transitions without touching
Go code.  The loader validates the JSON schema at startup.

Example – add a "pre-active" state:
```json
{
  "id": "t_pre",
  "from": "ready",
  "to": "pre-active",
  "action": "stage",
  "description": "Key staged but not yet live"
}
```

## Sample Output

```
▶ Step 1 – Bootstrapping master authorization key
  Master key ID  : master-auth-key-001
  Master pub key : 4nZk8F3mQpXa7Bv2Tc...

▶ Step 3 – Generating managed keys
  ecdsa-signing-01    type=ECDSA-P256   state=generated  fp=SHA256:3f8a12e4...
  eddsa-signing-01    type=Ed25519      state=generated  fp=SHA256:7b2c90d1...
  rsa-signing-01      type=RSA-2048     state=generated  fp=SHA256:c5e01fa7...

▶ Step 4 – ECDSA key full lifecycle walk-through
  ✓ [distribute   ] generated      → ready
  ✓ [activate     ] ready          → active
  ✓ [suspend      ] active         → suspended
  ✓ [reactivate   ] suspended      → active
  ✓ [deactivate   ] active         → deactivated
  ✓ [archive      ] deactivated    → archived

▶ Step 6 – Tamper detection
  Tamper detected: authorization check failed: signature verification FAILED – record has been tampered
```

```
% go run .

┌─────────────────────────────────┐
│  Key Lifecycle Management Demo  │
└─────────────────────────────────┘

▶ Step 1 – Bootstrapping master authorization key
  Master key ID  : master-auth-key-001
  Master pub key : kLnIoQj59B2hRUbcz8-DSA_C...

▶ Step 2 – Loading state machine from statemachine.json
  SM description : Key lifecycle state machine based on NIST SP 800-57

▶ Step 3 – Generating managed keys
  ecdsa-signing-01      type=ECDSA-P256    state=generated  fp=SHA256:fcbe884447681239
  eddsa-signing-01      type=Ed25519       state=generated  fp=SHA256:27145ff4ab7b3ffb
  rsa-signing-01        type=RSA-2048      state=generated  fp=SHA256:c88e19f0db5e088f

▶ Step 4 – ECDSA key full lifecycle walk-through
  ✓ [distribute  ] generated      → ready           (by admin@example.com)
  ✓ [activate    ] ready          → active          (by admin@example.com)
  ✓ [suspend     ] active         → suspended       (by security@example.com)
  ✓ [reactivate  ] suspended      → active          (by security@example.com)
  ✓ [deactivate  ] active         → deactivated     (by admin@example.com)
  ✓ [archive     ] deactivated    → archived        (by admin@example.com)

▶ Step 5 – EdDSA key: suspend → reactivate (with signed history log)
  ✓ [distribute  ] generated      → ready           actor=admin@example.com             sig=PUlbv3hhEX9I9LxALj45…
  ✓ [activate    ] ready          → active          actor=admin@example.com             sig=moHxUb6KzLhAdkGNSLMc…
  ✓ [suspend     ] active         → suspended       actor=security@example.com          sig=OM1-_dkeRkBsN-AiFmCf…
  ✓ [reactivate  ] suspended      → active          actor=security@example.com          sig=vxGKVHTC1sS_6O9WVS56…
  ✓ [suspend     ] active         → suspended       actor=security@example.com          sig=eiExeY3vXyDfHnZfOHlR…
  ✓ [reactivate  ] suspended      → active          actor=security@example.com          sig=9Y_lN7qkhBCiz2JttEV9…
  ✓ [deactivate  ] active         → deactivated     actor=admin@example.com             sig=fg1mjbNUV8mEicykMRob…
  ✓ [destroy     ] deactivated    → destroyed       actor=admin@example.com             sig=WWNYe5U_jOK89_eo3D_H…

  ✗ Attempt 'distribute' after destroyed: state machine rejected transition: state "destroyed" is terminal – no further transitions allowed

  ── Signed history log embedded in EdDSA key record ──
  ┌── History log for key "eddsa-signing-01" (signed by master-auth-key-001) ──
  │  1. 2026-02-27 19:57:04         (none)         → generated     
  │     action=generate      actor=master-auth-key-001
  │     reason=initial key generation
  │  2. 2026-02-27 19:57:04         generated      → ready         
  │     action=distribute    actor=admin@example.com
  │     reason=distributed for signing service
  │  3. 2026-02-27 19:57:04         ready          → active        
  │     action=activate      actor=admin@example.com
  │     reason=installed on signing node-2
  │  4. 2026-02-27 19:57:04         active         → suspended     
  │     action=suspend       actor=security@example.com
  │     reason=INCIDENT-8821: suspected key exposure
  │  5. 2026-02-27 19:57:04         suspended      → active        
  │     action=reactivate    actor=security@example.com
  │     reason=INCIDENT-8821 closed – key confirmed clean
  │  6. 2026-02-27 19:57:04         active         → suspended     
  │     action=suspend       actor=security@example.com
  │     reason=scheduled 30-day audit window
  │  7. 2026-02-27 19:57:04         suspended      → active        
  │     action=reactivate    actor=security@example.com
  │     reason=audit complete – no anomalies
  │  8. 2026-02-27 19:57:04         active         → deactivated   
  │     action=deactivate    actor=admin@example.com
  │     reason=end of validity period
  │  9. 2026-02-27 19:57:04         deactivated    → destroyed     
  │     action=destroy       actor=admin@example.com
  │     reason=secure wipe confirmed on HSM
  └── sig=WWNYe5U_jOK89_eo3D_HOiHIV4nai8ZB…

▶ Step 6 – Tamper detection
  Tamper detected: authorization check failed: signature verification FAILED – record has been tampered

▶ Step 7 – Final ECDSA key record (JSON, public key truncated)
  {
    "key_id": "ecdsa-signing-01",
    "key_type": "ECDSA-P256",
    "public_key": "\u003ctruncated\u003e",
    "lifecycle": {
      "state": "archived",
      "created_at": "2026-02-27T19:57:04.406498Z",
      "updated_at": "2026-02-27T19:57:04.507694Z",
      "expires_at": "2027-02-27T19:57:04.406498Z",
      "description": "Managed ECDSA-P256 signing key",
      "history": [
        {
          "timestamp": "2026-02-27T19:57:04.406498Z",
          "action": "generate",
          "from_state": "",
          "to_state": "generated",
          "actor": "master-auth-key-001",
          "reason": "initial key generation"
        },
        {
          "timestamp": "2026-02-27T19:57:04.506933Z",
          "action": "distribute",
          "from_state": "generated",
          "to_state": "ready",
          "actor": "admin@example.com",
          "reason": "initial distribution to HSM pool"
        },
        {
          "timestamp": "2026-02-27T19:57:04.507086Z",
          "action": "activate",
          "from_state": "ready",
          "to_state": "active",
          "actor": "admin@example.com",
          "reason": "installed and verified on node-1"
        },
        {
          "timestamp": "2026-02-27T19:57:04.507243Z",
          "action": "suspend",
          "from_state": "active",
          "to_state": "suspended",
          "actor": "security@example.com",
          "reason": "incident INC-4471 investigation"
        },
        {
          "timestamp": "2026-02-27T19:57:04.507391Z",
          "action": "reactivate",
          "from_state": "suspended",
          "to_state": "active",
          "actor": "security@example.com",
          "reason": "investigation closed – key clean"
        },
        {
          "timestamp": "2026-02-27T19:57:04.507541Z",
          "action": "deactivate",
          "from_state": "active",
          "to_state": "deactivated",
          "actor": "admin@example.com",
          "reason": "scheduled rotation"
        },
        {
          "timestamp": "2026-02-27T19:57:04.507694Z",
          "action": "archive",
          "from_state": "deactivated",
          "to_state": "archived",
          "actor": "admin@example.com",
          "reason": "retained for signature verification"
        }
      ]
    },
    "signature": "hIXMXCTqWu4KQLVxdq92tOzhGMEEYq3LJaUg7M8zIoIitWNcGcqFuzVyiP1ltMIflOVfaIDVXljpbap2z0KVCw",
    "signed_by": "master-auth-key-001"
  }

▶ Step 8 – Reload ECDSA key from disk, verify signature, print history
  ✓ Signature valid. State=archived  History entries=7
  ┌── History log for key "ecdsa-signing-01" (signed by master-auth-key-001) ──
  │  1. 2026-02-27 19:57:04         (none)         → generated     
  │     action=generate      actor=master-auth-key-001
  │     reason=initial key generation
  │  2. 2026-02-27 19:57:04         generated      → ready         
  │     action=distribute    actor=admin@example.com
  │     reason=initial distribution to HSM pool
  │  3. 2026-02-27 19:57:04         ready          → active        
  │     action=activate      actor=admin@example.com
  │     reason=installed and verified on node-1
  │  4. 2026-02-27 19:57:04         active         → suspended     
  │     action=suspend       actor=security@example.com
  │     reason=incident INC-4471 investigation
  │  5. 2026-02-27 19:57:04         suspended      → active        
  │     action=reactivate    actor=security@example.com
  │     reason=investigation closed – key clean
  │  6. 2026-02-27 19:57:04         active         → deactivated   
  │     action=deactivate    actor=admin@example.com
  │     reason=scheduled rotation
  │  7. 2026-02-27 19:57:04         deactivated    → archived      
  │     action=archive       actor=admin@example.com
  │     reason=retained for signature verification
  └── sig=hIXMXCTqWu4KQLVxdq92tOzhGMEEYq3L…

▶ Step 9 – Allowed actions from each state
  generated      → [distribute]
  ready          → [activate, compromise]
  active         → [suspend, deactivate, compromise]
  suspended      → [reactivate, deactivate, compromise]
  deactivated    → [destroy, archive]
  destroyed      → []
  archived       → []

✅  Demo complete. Key records written to ./keys/
```