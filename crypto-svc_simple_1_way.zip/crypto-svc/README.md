# crypto-svc

A gRPC encryption service with two cipher versions and zero-downtime migration.

## How it works

### The version flag

`config.json` has one key that controls everything:

```json
{ "active_version": "v1" }
```

Change it to `"v2"` — the server picks up the change within 3 seconds, no restart needed.

### The interop mechanism

Every ciphertext blob starts with a 2-byte magic prefix:

```
V1 blob: [0xC1 0x01] [12-byte nonce] [AES-256-GCM ciphertext]
V2 blob: [0xC2 0x02] [24-byte nonce] [ChaCha20-Poly1305 ciphertext]
```

- **Encrypt** reads the `active_version` flag → picks the cipher
- **Decrypt** reads the first 2 bytes of the blob → picks the cipher, ignores the flag

This means: flip the flag to `"v2"`, and old v1 ciphertexts **still decrypt fine**. The API never changes.

### Project layout

```
crypto-svc/
├── proto/
│   ├── crypto.proto          # Service definition (Encrypt / Decrypt)
│   └── crypto.pb.go          # gRPC stub (hand-written, no protoc needed)
├── internal/
│   ├── cipher/cipher.go      # V1 (AES-256-GCM) + V2 (ChaCha20-Poly1305) + Router
│   ├── config/config.go      # Hot-reload from config.json
│   └── store/store.go        # Postgres: save, load, sha256
├── cmd/
│   ├── server/main.go        # gRPC server
│   ├── client/main.go        # CLI: encrypt / decrypt
│   └── migrate/main.go       # One-shot backfill: v1 → v2
├── config.json               # ← change active_version here
├── docker-compose.yml        # Two Postgres instances (ports 5432 / 5433)
└── Makefile
```

## Quick start

```bash
# 1. Start both Postgres databases
make up

# 2. Build everything
make build

# 3. Start the gRPC server (reads config.json)
make run
```

In a second terminal:

```bash
# Encrypt something
make encrypt ID=hello TEXT="my secret"

# Decrypt it (paste the hex from the encrypt output)
make decrypt ID=hello HEX=<paste hex here>
```

## Migrating from v1 to v2

```bash
# Step 1: edit config.json
#   "active_version": "v2"
# The running server detects the change in ~3 seconds. No restart needed.
# New records are now encrypted with ChaCha20-Poly1305.
# Old v1 records still decrypt automatically (magic prefix detection).

# Step 2: backfill old records
make migrate

# Step 3: verify both databases agree on sha256(plaintext)
make sha256-check ID=hello
```

The migrate tool:
1. Lists all records in the v1 database
2. Skips any already on v2
3. Decrypts each v1 record (auto-detected)
4. Re-encrypts under v2
5. Writes to both databases
6. Logs sha256 match/mismatch per record

## Two databases

Both databases use the same schema:

```sql
CREATE TABLE records (
    id             TEXT PRIMARY KEY,
    ciphertext     BYTEA       NOT NULL,
    cipher_version TEXT        NOT NULL,   -- 'v1' or 'v2'
    plaintext_sha  TEXT        NOT NULL,   -- sha256(plaintext), hex
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

`plaintext_sha` lets you verify both databases hold the same secret without storing the plaintext:

```bash
make sha256-check ID=hello
# v1-db: a3f1...
# v2-db: a3f1...   ← must match
```

## Teardown

```bash
make down    # stop containers, keep data
make clean   # stop containers + delete all data + delete binaries
```

## Keys

Each cipher uses a completely separate 32-byte key (hex-encoded in `config.json`):

- `key_v1_hex` — AES-256-GCM key
- `key_v2_hex` — ChaCha20-Poly1305 key

Generate new keys:
```bash
openssl rand -hex 32   # run twice, once for each key
```
