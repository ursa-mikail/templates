// main.go — simple CLI client for the CryptoService.
//
// Usage:
//
//	client -op encrypt -id mykey -text "hello world"
//	client -op decrypt -id mykey -hex <ciphertext-hex>
//	client -op verify  -id mykey  # checks sha256 matches across both DBs (via server)
package main

import (
	"context"
	"encoding/hex"
	"flag"
	"fmt"
	"log"
	"os"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	pb "github.com/example/crypto-svc/proto"
)

func main() {
	addr := flag.String("addr", "localhost:50051", "server address")
	op := flag.String("op", "", "encrypt | decrypt")
	id := flag.String("id", "", "record id")
	text := flag.String("text", "", "plaintext to encrypt")
	hexStr := flag.String("hex", "", "hex-encoded ciphertext to decrypt")
	flag.Parse()

	conn, err := grpc.NewClient(*addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("connect: %v", err)
	}
	defer conn.Close()

	client := pb.NewCryptoServiceClient(conn)
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	switch *op {
	case "encrypt":
		if *id == "" || *text == "" {
			fmt.Fprintln(os.Stderr, "encrypt requires -id and -text")
			os.Exit(1)
		}
		resp, err := client.Encrypt(ctx, &pb.EncryptRequest{
			Id:        *id,
			Plaintext: []byte(*text),
		})
		if err != nil {
			log.Fatalf("encrypt: %v", err)
		}
		fmt.Printf("cipher_version : %s\n", resp.CipherVersion)
		fmt.Printf("ciphertext (hex): %s\n", hex.EncodeToString(resp.Ciphertext))

	case "decrypt":
		if *id == "" || *hexStr == "" {
			fmt.Fprintln(os.Stderr, "decrypt requires -id and -hex")
			os.Exit(1)
		}
		blob, err := hex.DecodeString(*hexStr)
		if err != nil {
			log.Fatalf("bad hex: %v", err)
		}
		resp, err := client.Decrypt(ctx, &pb.DecryptRequest{
			Id:         *id,
			Ciphertext: blob,
		})
		if err != nil {
			log.Fatalf("decrypt: %v", err)
		}
		fmt.Printf("cipher_version: %s\n", resp.CipherVersion)
		fmt.Printf("plaintext     : %s\n", resp.Plaintext)

	default:
		fmt.Fprintf(os.Stderr, "Usage: client -op <encrypt|decrypt> [flags]\n")
		flag.PrintDefaults()
		os.Exit(1)
	}
}
