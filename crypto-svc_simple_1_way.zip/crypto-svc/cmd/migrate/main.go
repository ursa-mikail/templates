// main.go — Migration tool.
//
// Run this AFTER flipping active_version to "v2" in config.json.
// It reads every record from v1-db, decrypts it (auto-detected as v1),
// re-encrypts under v2, and writes the new ciphertext to BOTH databases.
//
// Strategy:
//  1. Change config.json → "active_version": "v2"
//  2. Server immediately encrypts new records with v2
//  3. Run this migrate tool to backfill existing v1 records → v2
//  4. Verify: both databases should show sha256 match for every id
//
// Usage:
//
//	migrate -config config.json
package main

import (
	"context"
	"flag"
	"fmt"
	"log"

	"github.com/example/crypto-svc/internal/cipher"
	"github.com/example/crypto-svc/internal/config"
	"github.com/example/crypto-svc/internal/store"
)

func main() {
	cfgPath := flag.String("config", "config.json", "path to config file")
	dryRun := flag.Bool("dry-run", false, "print what would be migrated without writing")
	flag.Parse()

	cfg, err := config.Load(*cfgPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}
	c := cfg.Get()

	if c.ActiveVersion != "v2" {
		log.Fatalf("active_version must be 'v2' before migrating (currently %q). "+
			"Update config.json first.", c.ActiveVersion)
	}

	router, err := cipher.NewRouter(c.KeyV1Hex, c.KeyV2Hex)
	if err != nil {
		log.Fatalf("init ciphers: %v", err)
	}

	dbV1, err := store.Open(c.DatabaseV1, "v1-db")
	if err != nil {
		log.Fatalf("open v1-db: %v", err)
	}
	defer dbV1.Close()

	dbV2, err := store.Open(c.DatabaseV2, "v2-db")
	if err != nil {
		log.Fatalf("open v2-db: %v", err)
	}
	defer dbV2.Close()

	ctx := context.Background()

	// Get all ids from v1-db
	ids, err := dbV1.AllIDs(ctx)
	if err != nil {
		log.Fatalf("list ids: %v", err)
	}

	log.Printf("found %d records in v1-db", len(ids))

	migrated, skipped, failed := 0, 0, 0

	for _, id := range ids {
		// Load the ciphertext from v1-db
		ciphertext, version, err := dbV1.Load(ctx, id)
		if err != nil {
			log.Printf("[SKIP] %s: load error: %v", id, err)
			failed++
			continue
		}

		// Already migrated — skip
		if version == "v2" {
			log.Printf("[SKIP] %s: already v2", id)
			skipped++
			continue
		}

		// Decrypt using auto-detected cipher (will use v1 key)
		plaintext, detectedVersion, err := router.Decrypt(ciphertext)
		if err != nil {
			log.Printf("[FAIL] %s: decrypt error: %v", id, err)
			failed++
			continue
		}

		log.Printf("[MIGRATE] %s: %s → v2", id, detectedVersion)

		if *dryRun {
			migrated++
			continue
		}

		// Re-encrypt under v2
		newCiphertext, newVersion, err := router.Encrypt(plaintext, "v2")
		if err != nil {
			log.Printf("[FAIL] %s: re-encrypt error: %v", id, err)
			failed++
			continue
		}

		// Write new v2 ciphertext to BOTH databases
		if err := dbV1.Save(ctx, id, newCiphertext, newVersion, plaintext); err != nil {
			log.Printf("[FAIL] %s: save to v1-db: %v", id, err)
			failed++
			continue
		}
		if err := dbV2.Save(ctx, id, newCiphertext, newVersion, plaintext); err != nil {
			log.Printf("[FAIL] %s: save to v2-db: %v", id, err)
			failed++
			continue
		}

		// Verify both databases now agree on sha256(plaintext)
		sha1, err := dbV1.SHA256(ctx, id)
		if err != nil {
			log.Printf("[WARN] %s: sha256 check v1-db: %v", id, err)
		}
		sha2, err := dbV2.SHA256(ctx, id)
		if err != nil {
			log.Printf("[WARN] %s: sha256 check v2-db: %v", id, err)
		}
		if sha1 != sha2 {
			log.Printf("[WARN] %s: SHA256 MISMATCH v1=%s v2=%s", id, sha1, sha2)
		} else {
			log.Printf("[OK]   %s: sha256 match ✓", id)
		}

		migrated++
	}

	fmt.Printf("\n=== Migration complete ===\n")
	fmt.Printf("  migrated : %d\n", migrated)
	fmt.Printf("  skipped  : %d\n", skipped)
	fmt.Printf("  failed   : %d\n", failed)
	if *dryRun {
		fmt.Println("  (dry-run: no changes written)")
	}
}
