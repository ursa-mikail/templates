// main.go — gRPC server.
//
// The server reads config.json on startup and polls it every 3 seconds.
// To migrate from v1 to v2: change "active_version" in config.json to "v2".
// No restart needed. Old v1 ciphertexts continue to decrypt automatically.
package main

import (
	"context"
	"flag"
	"log"
	"net"
	"os"
	"os/signal"
	"syscall"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"

	"github.com/example/crypto-svc/internal/cipher"
	"github.com/example/crypto-svc/internal/config"
	"github.com/example/crypto-svc/internal/store"
	pb "github.com/example/crypto-svc/proto"
)

func main() {
	cfgPath := flag.String("config", "config.json", "path to config file")
	addr := flag.String("addr", ":50051", "gRPC listen address")
	flag.Parse()

	// Load config (hot-reloads every 3 s automatically)
	cfg, err := config.Load(*cfgPath)
	must(err, "load config")

	c := cfg.Get()

	// Build the cipher router (holds both v1 and v2 ciphers)
	router, err := cipher.NewRouter(c.KeyV1Hex, c.KeyV2Hex)
	must(err, "init ciphers")

	// Open both Postgres databases
	dbV1, err := store.Open(c.DatabaseV1, "v1-db")
	must(err, "open v1 db")
	defer dbV1.Close()

	dbV2, err := store.Open(c.DatabaseV2, "v2-db")
	must(err, "open v2 db")
	defer dbV2.Close()

	// Wire up gRPC
	lis, err := net.Listen("tcp", *addr)
	must(err, "listen")

	srv := grpc.NewServer()
	pb.RegisterCryptoServiceServer(srv, &cryptoServer{
		cfg:    cfg,
		router: router,
		dbV1:   dbV1,
		dbV2:   dbV2,
	})

	log.Printf("server listening on %s (active_version=%s)", *addr, c.ActiveVersion)

	go func() {
		if err := srv.Serve(lis); err != nil {
			log.Printf("serve error: %v", err)
		}
	}()

	// Graceful shutdown on SIGINT / SIGTERM
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("shutting down…")
	srv.GracefulStop()
}

// cryptoServer implements the gRPC CryptoService.
type cryptoServer struct {
	pb.UnimplementedCryptoServiceServer
	cfg    *config.Loader
	router *cipher.Router
	dbV1   *store.DB
	dbV2   *store.DB
}

// Encrypt encrypts the plaintext using the active cipher version (from config).
// It writes to BOTH databases so they stay in sync.
func (s *cryptoServer) Encrypt(ctx context.Context, req *pb.EncryptRequest) (*pb.EncryptResponse, error) {
	if len(req.Plaintext) == 0 {
		return nil, status.Error(codes.InvalidArgument, "plaintext is empty")
	}

	activeVersion := s.cfg.Get().ActiveVersion

	// Encrypt with whichever cipher version is active
	ciphertext, version, err := s.router.Encrypt(req.Plaintext, activeVersion)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "encrypt: %v", err)
	}

	// Write to both databases.
	// Both get the same plaintext_sha so we can verify consistency later.
	if err := s.dbV1.Save(ctx, req.Id, ciphertext, version, req.Plaintext); err != nil {
		return nil, status.Errorf(codes.Internal, "save to v1-db: %v", err)
	}
	if err := s.dbV2.Save(ctx, req.Id, ciphertext, version, req.Plaintext); err != nil {
		return nil, status.Errorf(codes.Internal, "save to v2-db: %v", err)
	}

	log.Printf("[encrypt] id=%s version=%s", req.Id, version)
	return &pb.EncryptResponse{Ciphertext: ciphertext, CipherVersion: version}, nil
}

// Decrypt auto-detects the cipher version from the ciphertext prefix.
// The active_version config flag is NOT consulted — old blobs always work.
func (s *cryptoServer) Decrypt(ctx context.Context, req *pb.DecryptRequest) (*pb.DecryptResponse, error) {
	if len(req.Ciphertext) == 0 {
		return nil, status.Error(codes.InvalidArgument, "ciphertext is empty")
	}

	plaintext, version, err := s.router.Decrypt(req.Ciphertext)
	if err != nil {
		return nil, status.Errorf(codes.Internal, "decrypt: %v", err)
	}

	log.Printf("[decrypt] id=%s version=%s", req.Id, version)
	return &pb.DecryptResponse{Plaintext: plaintext, CipherVersion: version}, nil
}

func must(err error, label string) {
	if err != nil {
		log.Fatalf("FATAL [%s]: %v", label, err)
		os.Exit(1)
	}
}
