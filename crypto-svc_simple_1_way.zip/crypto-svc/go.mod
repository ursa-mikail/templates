module github.com/example/crypto-svc

go 1.22

require (
	github.com/lib/pq v1.10.9
	golang.org/x/crypto v0.22.0
	google.golang.org/grpc v1.63.2
)

require (
	golang.org/x/net v0.24.0 // indirect
	golang.org/x/sys v0.19.0 // indirect
	golang.org/x/text v0.14.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20240415180920-8c6c420018be // indirect
	google.golang.org/protobuf v1.34.1 // indirect
)
