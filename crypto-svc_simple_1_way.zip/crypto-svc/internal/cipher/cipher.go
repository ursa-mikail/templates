// Package cipher provides two AEAD ciphers and a Router that picks
// the right one automatically.
//
// Every ciphertext is prefixed with 2 magic bytes so Decrypt can
// auto-detect the version without any external metadata:
//
//	V1: 0xC1 0x01 | 12-byte nonce | AES-256-GCM ciphertext+tag
//	V2: 0xC2 0x02 | 24-byte nonce | ChaCha20-Poly1305 ciphertext+tag
//
// This is the core interoperability mechanism:
//   - Encrypt uses the active_version flag (from config)
//   - Decrypt ignores the flag — it reads the prefix and picks the cipher
package cipher

import (
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"io"

	"golang.org/x/crypto/chacha20poly1305"
)

// Magic version prefixes embedded in every ciphertext blob.
const (
	magicV1a = byte(0xC1)
	magicV1b = byte(0x01)
	magicV2a = byte(0xC2)
	magicV2b = byte(0x02)
)

// ErrUnknownVersion is returned when the ciphertext prefix is unrecognised.
var ErrUnknownVersion = errors.New("cipher: unknown version prefix")

// ─── V1: AES-256-GCM ────────────────────────────────────────────────────────

// v1Cipher wraps AES-256-GCM.
type v1Cipher struct{ key []byte }

func newV1(keyHex string) (*v1Cipher, error) {
	key, err := hex.DecodeString(keyHex)
	if err != nil {
		return nil, fmt.Errorf("v1 key hex decode: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("v1 key must be 32 bytes, got %d", len(key))
	}
	return &v1Cipher{key: key}, nil
}

func (c *v1Cipher) encrypt(plaintext []byte) ([]byte, error) {
	block, err := aes.NewCipher(c.key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, gcm.NonceSize()) // 12 bytes
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	ct := gcm.Seal(nil, nonce, plaintext, nil)

	// blob = [magic(2)] + [nonce(12)] + [ciphertext+tag]
	blob := make([]byte, 2+len(nonce)+len(ct))
	blob[0], blob[1] = magicV1a, magicV1b
	copy(blob[2:], nonce)
	copy(blob[2+len(nonce):], ct)
	return blob, nil
}

func (c *v1Cipher) decrypt(blob []byte) ([]byte, error) {
	block, err := aes.NewCipher(c.key)
	if err != nil {
		return nil, err
	}
	gcm, err := cipher.NewGCM(block)
	if err != nil {
		return nil, err
	}
	ns := gcm.NonceSize()
	if len(blob) < 2+ns {
		return nil, errors.New("v1: blob too short")
	}
	nonce, ct := blob[2:2+ns], blob[2+ns:]
	return gcm.Open(nil, nonce, ct, nil)
}

// ─── V2: ChaCha20-Poly1305 ──────────────────────────────────────────────────

// v2Cipher wraps XChaCha20-Poly1305 (24-byte nonce variant).
type v2Cipher struct{ key []byte }

func newV2(keyHex string) (*v2Cipher, error) {
	key, err := hex.DecodeString(keyHex)
	if err != nil {
		return nil, fmt.Errorf("v2 key hex decode: %w", err)
	}
	if len(key) != 32 {
		return nil, fmt.Errorf("v2 key must be 32 bytes, got %d", len(key))
	}
	return &v2Cipher{key: key}, nil
}

func (c *v2Cipher) encrypt(plaintext []byte) ([]byte, error) {
	aead, err := chacha20poly1305.NewX(c.key)
	if err != nil {
		return nil, err
	}
	nonce := make([]byte, aead.NonceSize()) // 24 bytes
	if _, err = io.ReadFull(rand.Reader, nonce); err != nil {
		return nil, err
	}
	ct := aead.Seal(nil, nonce, plaintext, nil)

	// blob = [magic(2)] + [nonce(24)] + [ciphertext+tag]
	blob := make([]byte, 2+len(nonce)+len(ct))
	blob[0], blob[1] = magicV2a, magicV2b
	copy(blob[2:], nonce)
	copy(blob[2+len(nonce):], ct)
	return blob, nil
}

func (c *v2Cipher) decrypt(blob []byte) ([]byte, error) {
	aead, err := chacha20poly1305.NewX(c.key)
	if err != nil {
		return nil, err
	}
	ns := aead.NonceSize()
	if len(blob) < 2+ns {
		return nil, errors.New("v2: blob too short")
	}
	nonce, ct := blob[2:2+ns], blob[2+ns:]
	return aead.Open(nil, nonce, ct, nil)
}

// ─── Router ─────────────────────────────────────────────────────────────────

// Router holds both ciphers and routes based on the active version flag
// (for Encrypt) or the ciphertext magic prefix (for Decrypt).
type Router struct {
	v1 *v1Cipher
	v2 *v2Cipher
}

// NewRouter builds a Router from two hex-encoded 32-byte keys.
func NewRouter(keyV1Hex, keyV2Hex string) (*Router, error) {
	v1, err := newV1(keyV1Hex)
	if err != nil {
		return nil, err
	}
	v2, err := newV2(keyV2Hex)
	if err != nil {
		return nil, err
	}
	return &Router{v1: v1, v2: v2}, nil
}

// Encrypt uses whichever cipher matches activeVersion ("v1" or "v2").
// This is the ONLY place the flag is consulted.
func (r *Router) Encrypt(plaintext []byte, activeVersion string) ([]byte, string, error) {
	switch activeVersion {
	case "v1":
		blob, err := r.v1.encrypt(plaintext)
		return blob, "v1", err
	case "v2":
		blob, err := r.v2.encrypt(plaintext)
		return blob, "v2", err
	default:
		return nil, "", fmt.Errorf("unknown active_version %q", activeVersion)
	}
}

// Decrypt reads the first 2 bytes of the blob to determine which cipher
// to use. The active_version flag is NOT consulted — old v1 blobs always
// decrypt with the v1 key even after the flag is switched to v2.
func (r *Router) Decrypt(blob []byte) ([]byte, string, error) {
	if len(blob) < 2 {
		return nil, "", errors.New("ciphertext too short")
	}
	switch {
	case blob[0] == magicV1a && blob[1] == magicV1b:
		pt, err := r.v1.decrypt(blob)
		return pt, "v1", err
	case blob[0] == magicV2a && blob[1] == magicV2b:
		pt, err := r.v2.decrypt(blob)
		return pt, "v2", err
	default:
		return nil, "", fmt.Errorf("%w: %02x %02x", ErrUnknownVersion, blob[0], blob[1])
	}
}
