// Package config loads config.json and hot-reloads it every few seconds.
// The only thing you change to migrate is: "active_version": "v2"
package config

import (
	"encoding/json"
	"log"
	"os"
	"sync"
	"time"
)

// Config is the full configuration loaded from config.json.
type Config struct {
	// ActiveVersion controls which cipher is used for NEW encryptions.
	// "v1" = AES-256-GCM,  "v2" = ChaCha20-Poly1305
	// Decryption always auto-detects from the ciphertext prefix — so
	// flipping this is safe at any time without touching the API.
	ActiveVersion string `json:"active_version"`

	// Each cipher has its own independent 32-byte key (hex-encoded).
	KeyV1Hex string `json:"key_v1_hex"`
	KeyV2Hex string `json:"key_v2_hex"`

	// Postgres connection strings for the two databases.
	DatabaseV1 string `json:"database_v1"`
	DatabaseV2 string `json:"database_v2"`
}

// Loader watches a config file and reloads it on change.
type Loader struct {
	path string
	mu   sync.RWMutex
	cfg  Config
}

// Load reads the config file once and starts a background watcher.
func Load(path string) (*Loader, error) {
	l := &Loader{path: path}
	if err := l.reload(); err != nil {
		return nil, err
	}
	go l.watch()
	return l, nil
}

// Get returns the current config (safe for concurrent use).
func (l *Loader) Get() Config {
	l.mu.RLock()
	defer l.mu.RUnlock()
	return l.cfg
}

func (l *Loader) reload() error {
	data, err := os.ReadFile(l.path)
	if err != nil {
		return err
	}
	var cfg Config
	if err := json.Unmarshal(data, &cfg); err != nil {
		return err
	}
	l.mu.Lock()
	l.cfg = cfg
	l.mu.Unlock()
	log.Printf("[config] loaded: active_version=%s", cfg.ActiveVersion)
	return nil
}

// watch polls the file every 3 seconds and reloads on modification.
func (l *Loader) watch() {
	var lastMod time.Time
	for range time.Tick(3 * time.Second) {
		info, err := os.Stat(l.path)
		if err != nil {
			continue
		}
		if info.ModTime().After(lastMod) {
			lastMod = info.ModTime()
			if err := l.reload(); err != nil {
				log.Printf("[config] reload error: %v", err)
			}
		}
	}
}
