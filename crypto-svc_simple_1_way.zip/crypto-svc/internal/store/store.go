// Package store manages one Postgres database.
// Each database stores: id, ciphertext, cipher_version, plaintext_sha256.
// The sha256 of the plaintext is stored so we can verify both databases
// hold the same underlying secret without storing the plaintext itself.
package store

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"fmt"

	_ "github.com/lib/pq" // postgres driver
)

const schema = `
CREATE TABLE IF NOT EXISTS records (
    id             TEXT PRIMARY KEY,
    ciphertext     BYTEA       NOT NULL,
    cipher_version TEXT        NOT NULL,
    plaintext_sha  TEXT        NOT NULL,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);`

// DB is a single Postgres database connection.
type DB struct {
	db    *sql.DB
	label string // "v1-db" or "v2-db" for log messages
}

// Open connects to Postgres and creates the table if needed.
func Open(dsn, label string) (*DB, error) {
	db, err := sql.Open("postgres", dsn)
	if err != nil {
		return nil, fmt.Errorf("[%s] open: %w", label, err)
	}
	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("[%s] ping: %w", label, err)
	}
	if _, err := db.Exec(schema); err != nil {
		return nil, fmt.Errorf("[%s] schema: %w", label, err)
	}
	return &DB{db: db, label: label}, nil
}

// Save stores or replaces a record. The plaintext is hashed (not stored).
func (d *DB) Save(ctx context.Context, id string, ciphertext []byte, version string, plaintext []byte) error {
	hash := sha256Hex(plaintext)
	_, err := d.db.ExecContext(ctx, `
		INSERT INTO records (id, ciphertext, cipher_version, plaintext_sha)
		VALUES ($1, $2, $3, $4)
		ON CONFLICT (id) DO UPDATE
		    SET ciphertext     = EXCLUDED.ciphertext,
		        cipher_version = EXCLUDED.cipher_version,
		        plaintext_sha  = EXCLUDED.plaintext_sha,
		        updated_at     = NOW()
	`, id, ciphertext, version, hash)
	return err
}

// Load retrieves the ciphertext and version for an id.
func (d *DB) Load(ctx context.Context, id string) (ciphertext []byte, version string, err error) {
	err = d.db.QueryRowContext(ctx,
		`SELECT ciphertext, cipher_version FROM records WHERE id = $1`, id,
	).Scan(&ciphertext, &version)
	if err == sql.ErrNoRows {
		return nil, "", fmt.Errorf("[%s] id %q not found", d.label, id)
	}
	return ciphertext, version, err
}

// SHA256 returns the stored sha256(plaintext) hex for an id.
// Used to verify both databases hold the same underlying secret.
func (d *DB) SHA256(ctx context.Context, id string) (string, error) {
	var hash string
	err := d.db.QueryRowContext(ctx,
		`SELECT plaintext_sha FROM records WHERE id = $1`, id,
	).Scan(&hash)
	if err == sql.ErrNoRows {
		return "", fmt.Errorf("[%s] id %q not found", d.label, id)
	}
	return hash, err
}

// AllIDs returns every id stored in this database.
func (d *DB) AllIDs(ctx context.Context) ([]string, error) {
	rows, err := d.db.QueryContext(ctx, `SELECT id FROM records ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var ids []string
	for rows.Next() {
		var id string
		if err := rows.Scan(&id); err != nil {
			return nil, err
		}
		ids = append(ids, id)
	}
	return ids, rows.Err()
}

// Close closes the connection pool.
func (d *DB) Close() error { return d.db.Close() }

func sha256Hex(data []byte) string {
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:])
}
