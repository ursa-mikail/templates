// Hand-written gRPC stub using JSON codec.
// gRPC's default codec is protobuf binary, which requires generated code.
// We register a JSON codec so plain Go structs work over the wire without protoc.
package proto

import (
	"context"
	"encoding/json"
	"fmt"

	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/encoding"
	"google.golang.org/grpc/status"
)

func init() {
	// Register our JSON codec under the name "proto" so it replaces
	// the default protobuf codec. Both client and server import this
	// package, so both sides use JSON automatically.
	encoding.RegisterCodec(JSONCodec{})
}

// JSONCodec encodes gRPC messages as JSON instead of protobuf binary.
// This lets us use plain Go structs without running protoc.
type JSONCodec struct{}

func (JSONCodec) Name() string { return "proto" }

func (JSONCodec) Marshal(v any) ([]byte, error) {
	b, err := json.Marshal(v)
	if err != nil {
		return nil, fmt.Errorf("json marshal: %w", err)
	}
	return b, nil
}

func (JSONCodec) Unmarshal(data []byte, v any) error {
	if err := json.Unmarshal(data, v); err != nil {
		return fmt.Errorf("json unmarshal: %w", err)
	}
	return nil
}

// ---------- message types ----------

type EncryptRequest struct {
	Id        string `json:"id"`
	Plaintext []byte `json:"plaintext"`
}

type EncryptResponse struct {
	Ciphertext    []byte `json:"ciphertext"`
	CipherVersion string `json:"cipher_version"`
}

type DecryptRequest struct {
	Id         string `json:"id"`
	Ciphertext []byte `json:"ciphertext"`
}

type DecryptResponse struct {
	Plaintext     []byte `json:"plaintext"`
	CipherVersion string `json:"cipher_version"`
}

// GRPCCodec marker — satisfies grpc codec interface via init() above.
func (m *EncryptRequest) Reset()        {}
func (m *EncryptRequest) String() string { return m.Id }
func (m *EncryptRequest) ProtoMessage()  {}

func (m *EncryptResponse) Reset()        {}
func (m *EncryptResponse) String() string { return m.CipherVersion }
func (m *EncryptResponse) ProtoMessage()  {}

func (m *DecryptRequest) Reset()        {}
func (m *DecryptRequest) String() string { return m.Id }
func (m *DecryptRequest) ProtoMessage()  {}

func (m *DecryptResponse) Reset()        {}
func (m *DecryptResponse) String() string { return m.CipherVersion }
func (m *DecryptResponse) ProtoMessage()  {}

// ---------- server interface ----------

type CryptoServiceServer interface {
	Encrypt(context.Context, *EncryptRequest) (*EncryptResponse, error)
	Decrypt(context.Context, *DecryptRequest) (*DecryptResponse, error)
	mustEmbedUnimplemented()
}

type UnimplementedCryptoServiceServer struct{}

func (UnimplementedCryptoServiceServer) Encrypt(_ context.Context, _ *EncryptRequest) (*EncryptResponse, error) {
	return nil, status.Error(codes.Unimplemented, "Encrypt not implemented")
}
func (UnimplementedCryptoServiceServer) Decrypt(_ context.Context, _ *DecryptRequest) (*DecryptResponse, error) {
	return nil, status.Error(codes.Unimplemented, "Decrypt not implemented")
}
func (UnimplementedCryptoServiceServer) mustEmbedUnimplemented() {}

// ---------- client ----------

type CryptoServiceClient interface {
	Encrypt(ctx context.Context, in *EncryptRequest, opts ...grpc.CallOption) (*EncryptResponse, error)
	Decrypt(ctx context.Context, in *DecryptRequest, opts ...grpc.CallOption) (*DecryptResponse, error)
}

type cryptoClient struct{ cc grpc.ClientConnInterface }

func NewCryptoServiceClient(cc grpc.ClientConnInterface) CryptoServiceClient {
	return &cryptoClient{cc}
}

func (c *cryptoClient) Encrypt(ctx context.Context, in *EncryptRequest, opts ...grpc.CallOption) (*EncryptResponse, error) {
	out := &EncryptResponse{}
	return out, c.cc.Invoke(ctx, "/crypto.CryptoService/Encrypt", in, out, opts...)
}

func (c *cryptoClient) Decrypt(ctx context.Context, in *DecryptRequest, opts ...grpc.CallOption) (*DecryptResponse, error) {
	out := &DecryptResponse{}
	return out, c.cc.Invoke(ctx, "/crypto.CryptoService/Decrypt", in, out, opts...)
}

// ---------- server registration ----------

func RegisterCryptoServiceServer(s *grpc.Server, srv CryptoServiceServer) {
	s.RegisterService(&grpc.ServiceDesc{
		ServiceName: "crypto.CryptoService",
		HandlerType: (*CryptoServiceServer)(nil),
		Methods: []grpc.MethodDesc{
			{MethodName: "Encrypt", Handler: encryptHandler},
			{MethodName: "Decrypt", Handler: decryptHandler},
		},
	}, srv)
}

func encryptHandler(srv any, ctx context.Context, dec func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
	req := &EncryptRequest{}
	if err := dec(req); err != nil {
		return nil, err
	}
	if interceptor == nil {
		return srv.(CryptoServiceServer).Encrypt(ctx, req)
	}
	return interceptor(ctx, req,
		&grpc.UnaryServerInfo{Server: srv, FullMethod: "/crypto.CryptoService/Encrypt"},
		func(ctx context.Context, req any) (any, error) {
			return srv.(CryptoServiceServer).Encrypt(ctx, req.(*EncryptRequest))
		})
}

func decryptHandler(srv any, ctx context.Context, dec func(any) error, interceptor grpc.UnaryServerInterceptor) (any, error) {
	req := &DecryptRequest{}
	if err := dec(req); err != nil {
		return nil, err
	}
	if interceptor == nil {
		return srv.(CryptoServiceServer).Decrypt(ctx, req)
	}
	return interceptor(ctx, req,
		&grpc.UnaryServerInfo{Server: srv, FullMethod: "/crypto.CryptoService/Decrypt"},
		func(ctx context.Context, req any) (any, error) {
			return srv.(CryptoServiceServer).Decrypt(ctx, req.(*DecryptRequest))
		})
}
